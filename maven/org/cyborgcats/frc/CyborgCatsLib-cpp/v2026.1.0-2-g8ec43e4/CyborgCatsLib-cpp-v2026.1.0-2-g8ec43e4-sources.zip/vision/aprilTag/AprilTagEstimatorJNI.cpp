#include <jni.h>

#include <iostream>
#include <string>
#include <vector>

#include <opencv2/core.hpp>

#include <frc/apriltag/AprilTagFieldLayout.h>
#include <frc/geometry/Pose3d.h>
#include <frc/geometry/Transform3d.h>
#include <units/angle.h>
#include <units/length.h>
#include <wpi/json.h>

#include "vision/aprilTag/AprilTagEstimator.h"
#include "vision/aprilTag/AprilTagEstimate.h"
#include "vision/aprilTag/AprilTagTarget.h"

// =============================================================================
// JNI bridge. The boundary carries DATA only (primitives, arrays, the handle).
// No C++ objects cross; results are returned as a flat double[] payload that the
// Java side decodes into its own types.
//
// Bound to the Java class
// org.cyborgcats.jni.AprilTagEstimatorJNI, which declares:
//
//   package org.cyborgcats.jni;
//   public final class AprilTagEstimatorJNI {
//     static { System.loadLibrary("vision"); }
//     static native long     nativeCreate(double[] cameraMatrix, double[] distCoeffs,
//                                          int width, int height, String fieldLayoutJson);
//     static native void     nativeDestroy(long handle);
//     static native double[] nativeSolvePnP(long handle, int[] ids, float[] corners, int pointsPerTag);
//     static native double[] nativeSolveTrig(long handle, int[] ids, float[] corners, int pointsPerTag,
//                                            double[] cameraToRobot, double gyroHeadingRadians);
//   }
//
// cameraToRobot is [x, y, z, roll, pitch, yaw] (meters / radians).
//
// Payload layout (double[]), or null when the solve returns no estimate:
//   tagCount, tagArea, error1, error2,
//   pose1 [x y z qw qx qy qz], pose2 [x y z qw qx qy qz],
//   numTargets,
//   per target:
//     id, yaw, pitch, area, skew, bestError, altError,
//     bestCameraToTag [x y z qw qx qy qz], altCameraToTag [x y z qw qx qy qz],
//     numCorners, corners [x0 y0 x1 y1 ...]
// =============================================================================

namespace {

AprilTagEstimator* asEstimator(jlong handle) {
  return reinterpret_cast<AprilTagEstimator*>(handle);
}

cv::Mat matFromDoubleArray(JNIEnv* env, jdoubleArray arr, int rows, int cols) {
  cv::Mat m(rows, cols, CV_64F);
  env->GetDoubleArrayRegion(arr, 0, static_cast<jsize>(rows * cols),
                            reinterpret_cast<jdouble*>(m.data));
  return m;
}

std::vector<int> unpackIds(JNIEnv* env, jintArray idsArray) {
  jsize n = env->GetArrayLength(idsArray);
  std::vector<int> ids(n);
  env->GetIntArrayRegion(idsArray, 0, n, ids.data());
  return ids;
}

std::vector<std::vector<cv::Point2f>> unpackCorners(
    JNIEnv* env, jfloatArray cornersArray, int tagCount, int pointsPerTag) {
  jsize len = env->GetArrayLength(cornersArray);
  std::vector<float> flat(len);
  env->GetFloatArrayRegion(cornersArray, 0, len, flat.data());

  std::vector<std::vector<cv::Point2f>> corners;
  corners.reserve(tagCount);

  int idx = 0;
  for (int i = 0; i < tagCount; ++i) {
    std::vector<cv::Point2f> tag;
    tag.reserve(pointsPerTag);
    for (int j = 0; j < pointsPerTag; ++j) {
      if (idx + 1 >= len) break;
      float x = flat[idx++];
      float y = flat[idx++];
      tag.emplace_back(x, y);
    }
    corners.push_back(std::move(tag));
  }
  return corners;
}

frc::Transform3d transformFromArray(JNIEnv* env, jdoubleArray arr) {
  double v[6] = {0, 0, 0, 0, 0, 0};
  jsize len = env->GetArrayLength(arr);
  env->GetDoubleArrayRegion(arr, 0, std::min<jsize>(len, 6), v);
  return frc::Transform3d(
      frc::Translation3d(units::meter_t{v[0]}, units::meter_t{v[1]}, units::meter_t{v[2]}),
      frc::Rotation3d(units::radian_t{v[3]}, units::radian_t{v[4]}, units::radian_t{v[5]}));
}

void pushPose(std::vector<double>& out, const frc::Pose3d& p) {
  const auto& q = p.Rotation().GetQuaternion();
  out.push_back(p.X().value());
  out.push_back(p.Y().value());
  out.push_back(p.Z().value());
  out.push_back(q.W());
  out.push_back(q.X());
  out.push_back(q.Y());
  out.push_back(q.Z());
}

void pushTransform(std::vector<double>& out, const frc::Transform3d& t) {
  const auto& q = t.Rotation().GetQuaternion();
  out.push_back(t.X().value());
  out.push_back(t.Y().value());
  out.push_back(t.Z().value());
  out.push_back(q.W());
  out.push_back(q.X());
  out.push_back(q.Y());
  out.push_back(q.Z());
}

jdoubleArray encodeEstimate(JNIEnv* env, const AprilTagEstimate& est) {
  std::vector<double> out;

  out.push_back(static_cast<double>(est.tagCount));
  out.push_back(est.tagArea);
  out.push_back(est.error1);
  out.push_back(est.error2);
  pushPose(out, est.pose1);
  pushPose(out, est.pose2);

  out.push_back(static_cast<double>(est.targets.size()));
  for (const auto& t : est.targets) {
    out.push_back(static_cast<double>(t.id));
    out.push_back(t.yaw);
    out.push_back(t.pitch);
    out.push_back(t.area);
    out.push_back(t.skew);
    out.push_back(t.bestError);
    out.push_back(t.altError);
    pushTransform(out, t.bestCameraToTag);
    pushTransform(out, t.altCameraToTag);
    out.push_back(static_cast<double>(t.corners.size()));
    for (const auto& c : t.corners) {
      out.push_back(c.x);
      out.push_back(c.y);
    }
  }

  jdoubleArray arr = env->NewDoubleArray(static_cast<jsize>(out.size()));
  env->SetDoubleArrayRegion(arr, 0, static_cast<jsize>(out.size()), out.data());
  return arr;
}

}  // namespace

extern "C" {

JNIEXPORT jlong JNICALL
Java_org_cyborgcats_jni_AprilTagEstimatorJNI_nativeCreate(
    JNIEnv* env, jclass,
    jdoubleArray cameraMatrix, jdoubleArray distCoeffs,
    jint width, jint height, jstring fieldLayoutJson) {
  try {
    cv::Mat cam = matFromDoubleArray(env, cameraMatrix, 3, 3);
    jsize distLen = env->GetArrayLength(distCoeffs);
    cv::Mat dist = matFromDoubleArray(env, distCoeffs, 1, static_cast<int>(distLen));

    const char* json = env->GetStringUTFChars(fieldLayoutJson, nullptr);
    frc::AprilTagFieldLayout layout =
        wpi::json::parse(json).get<frc::AprilTagFieldLayout>();
    env->ReleaseStringUTFChars(fieldLayoutJson, json);

    auto* est = new AprilTagEstimator(cam, dist, width, height, layout);
    return reinterpret_cast<jlong>(est);
  } catch (const std::exception& e) {
    std::cerr << "nativeCreate failed: " << e.what() << '\n';
    return 0;
  }
}

JNIEXPORT void JNICALL
Java_org_cyborgcats_jni_AprilTagEstimatorJNI_nativeDestroy(
    JNIEnv*, jclass, jlong handle) {
  delete asEstimator(handle);
}

JNIEXPORT jdoubleArray JNICALL
Java_org_cyborgcats_jni_AprilTagEstimatorJNI_nativeSolvePnP(
    JNIEnv* env, jclass, jlong handle,
    jintArray idsArray, jfloatArray cornersArray, jint pointsPerTag) {
  auto* est = asEstimator(handle);
  if (est == nullptr) return nullptr;

  std::vector<int> ids = unpackIds(env, idsArray);
  auto corners = unpackCorners(env, cornersArray, static_cast<int>(ids.size()), pointsPerTag);

  auto res = est->solveEstimatePnP(ids, corners);
  if (!res.has_value()) return nullptr;
  return encodeEstimate(env, *res);
}

JNIEXPORT jdoubleArray JNICALL
Java_org_cyborgcats_jni_AprilTagEstimatorJNI_nativeSolveTrig(
    JNIEnv* env, jclass, jlong handle,
    jintArray idsArray, jfloatArray cornersArray, jint pointsPerTag,
    jdoubleArray cameraToRobot, jdouble gyroHeadingRadians) {
  auto* est = asEstimator(handle);
  if (est == nullptr) return nullptr;

  std::vector<int> ids = unpackIds(env, idsArray);
  auto corners = unpackCorners(env, cornersArray, static_cast<int>(ids.size()), pointsPerTag);
  frc::Transform3d camToRobot = transformFromArray(env, cameraToRobot);

  auto res = est->solveEstimateTrig(ids, corners, camToRobot, gyroHeadingRadians);
  if (!res.has_value()) return nullptr;
  return encodeEstimate(env, *res);
}

}  // extern "C"
