#pragma once
#include <atomic>
#include <opencv2/opencv.hpp>

class TripleBuffer {
public:
    struct Frame {
        cv::Mat img;
        uint64_t timestamp;
    };

    TripleBuffer(int width, int height) {
        for (int i = 0; i < 3; ++i) {
            frames[i].img = cv::Mat::zeros(height, width, CV_8UC1);
        }
    }

    Frame *get_write_ptr() {
        return &frames[producer_idx];
    }

    void submit_write() {
        int old = ready_idx.exchange(producer_idx.load(), std::memory_order_release);
        producer_idx.store(old, std::memory_order_relaxed);
        sequence.fetch_add(1, std::memory_order_release);
    }

    Frame *get_read_ptr(uint64_t &last_sequence) {
        uint64_t seq = sequence.load(std::memory_order_acquire);
        if (seq == last_sequence) return nullptr;

        int old = ready_idx.exchange(consumer_idx.load(), std::memory_order_acquire);
        consumer_idx.store(old, std::memory_order_relaxed);
        last_sequence = seq;
        return &frames[consumer_idx.load()];
        &frames[consumer_idx];
    }

private:
    Frame frames[3];
    std::atomic<int> producer_idx = 0;
    std::atomic<int> consumer_idx = 1;
    std::atomic<int> ready_idx{2};
    std::atomic<uint64_t> sequence{0};
};
