#pragma once                                                                                                                                 
#include <limits>                                                                                                                            
#include <frc/geometry/Transform3d.h>
#include <opencv2/core/types.hpp>

#include "vision/aprilTag/AprilTagArea.h"

struct AprilTagTarget {
  int id;
  std::vector<cv::Point2f> corners;

  double yaw = 0.0; //the yaw of the target in radians (positive left)
  double pitch = 0.0; //the pitch of the target in radians (positive up) 
  double area = 0.0; // how much of the image the april tag corner box takes up scale of 0 - 100   
  double skew = 0.0; // the skew of the target in radians (counter-clockwise positive)

  frc::Transform3d bestCameraToTag;
  frc::Transform3d altCameraToTag;

  double bestError = std::numeric_limits<double>::quiet_NaN();
  double altError  = std::numeric_limits<double>::quiet_NaN();
};