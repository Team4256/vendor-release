#pragma once

#include <vector>
#include <opencv2/core/types.hpp>

/**
 * utility class for methods related to april tag area
 */
class AprilTagArea {
  public:
  /**
   * computes the percentage of the image that is occupied by the tag
   * on a scale of 0 - 100
   * @param corners list of april tag corners
   * @param imageWidth pixel width of the image
   * @param imageHeight pixel height of the image
   */
    static double computeTagArea(
      const std::vector<std::vector<cv::Point2f>> &corners,
      int imageWidth, int imageHeight
    );
};
