#pragma once

#include <optional>
#include <vector>
#include <opencv2/core/mat.hpp>
#include <opencv2/core/types.hpp>
#include <frc/apriltag/AprilTagFieldLayout.h>
#include <frc/geometry/Transform3d.h>

#include "vision/aprilTag/AprilTagEstimate.h"
#include "vision/aprilTag/AprilTagGeometry.h"
#include "vision/aprilTag/AprilTagTarget.h"

/**
 * class defining how to transform april tag ids and corners into a april tag estimate
 * all solvers are implemented in seperate cpp files and desired solver is determined at the java level
 */
class AprilTagEstimator {
public:
  /**
   * class to estimate camera pose, april tag count, april tag area, april tag reprojection errors, 
   * and april tag ambiguity from a list of ids and corners 
   * @param cameraMatrix intrinsic matrix of camera properties
   * @param distCoeffs distortion coeffs related to the camera
   * @param imageWidth pixel width of the image
   * @param imageHeight pixel height of the image
   * @param layout frc::AprilTagFieldLayout containing april tag information
   */
    AprilTagEstimator(
      const cv::Mat &cameraMatrix, 
      const cv::Mat &distCoeffs, 
      int imageWidth, 
      int imageHeight, 
      const frc::AprilTagFieldLayout &layout
    );

    /**
     * solver for an april tag estimate from the given tag ids and corners using cv::solvePnPGeneric
     * @param ids a list of april tag ids
     * @param corners a list of april tag corners
     */
    std::optional<AprilTagEstimate>  solveEstimatePnP(
      const std::vector<int> &ids,
      const std::vector<std::vector<cv::Point2f>> &corners
    ) const;
    
    /**
     * solver for an april tag estimate from the given tag ids using a trigonometry based approach
     * assumes a correct gyro heading
     * assumes the robot is flat on the ground
     * @param ids a list of detected tag ids
     * @param corners a list of april tag corners (used for each tag's yaw/pitch bearing)
     * @param cameraToRobot a transform 3d describing the center of the camera to the center of the robot
     * @param gyroHeadingRadians the current heading of the robots gyro in radians
     */
    std::optional<AprilTagEstimate> solveEstimateTrig(
      const std::vector<int> &ids,
      const std::vector<std::vector<cv::Point2f>> &corners,
      const frc::Transform3d &cameraToRobot,
      double gyroHeadingRadians
    ) const;

private:
    // intrinsic matrix of camera properties 
    cv::Mat cameraMatrix;
    // distortion coeffs related to the camera
    cv::Mat distCoeffs;

    // pixel width of the image
    int imageWidth;
    // pixel height of the image
    int imageHeight;

    // frc::AprilTagFieldLayout containing april tag information
    frc::AprilTagFieldLayout layout;
    // map of april tag ids and corners
    AprilTagGeometry::CornerMap cornerMap;

    /**
     * helper method to solve for the camera to april tag transform
     * @param tvec translational vector in opencv coordinates
     * @param rvec rotational vector in opencv coordinates
     * @return a transform3d representing the vector from the camera to the april tag
     */
    frc::Transform3d cameraToTagTransform(const cv::Mat &tvec, const cv::Mat &rvec) const;

    /**
     * builds target data for each april tag detected for PnP 
     * @param ids a list of april tag ids
     * @param corners a list of april tag corners
     * @return a april tag target representing solved data from an april tag detection using sqpnp
     */
    AprilTagTarget buildAprilTagTargetPnP(int id, const std::vector<cv::Point2f> &corners) const;
};
