#pragma once

#include <opencv2/core.hpp>
#include <opencv2/calib3d.hpp>

/**
 * namespace collecting methods to convert between wpilib and opencv coordinates
 */
namespace CoordinateConversion {

  /**
   * internal helper variables and functions
   * not useful outside of coordinate conversion namespace
   */
  namespace internal {
    /**
     * 3x3 matrix for converting opencv coordinate rotational vectors to wpilib coordinate rotational vectors
     * <p>to convert wpilib to opencv use .t() to get the inverse matrix</p>
     */
    static inline const cv::Mat opencvToWpilib =
      (cv::Mat_<double>(3, 3) <<
      0, 0, 1,
      -1, 0, 0,
      0, -1, 0
      );

    /**
     * converts a cv::Mat into type CV_64F and reshapes it to a 3x1 column vector
     * @param vec cv::Mat (must contain exactly 3 elements)
    */
    inline cv::Mat convertVec64Flat(const cv::Mat &vec) {
      cv::Mat vec64;
      vec.convertTo(vec64, CV_64F);
      return vec64.reshape(1, 3);
    }
  }

  /**
   * utility method for converting an opencv coordinate translational vector to a wpilib coordinate translational vector
   * @param tvecs opencv translational vector
   */
  inline cv::Mat opencvToWpilibTranslation(const cv::Mat &tvecs) {
    cv::Mat flat = internal::convertVec64Flat(tvecs);
    return (cv::Mat_<double>(3, 1) <<
      flat.at<double>(2, 0),
      -flat.at<double>(0, 0),
      -flat.at<double>(1, 0));
  }

  /**
   * utility method for converting an opencv coordinate rotational vector to a wpilib coordinate rotational vector
   */
  inline cv::Mat opencvToWpilibRotation(const cv::Mat &rvecs) {
    cv::Mat flat = internal::convertVec64Flat(rvecs);
    cv::Mat opencvRotMat;
    cv::Rodrigues(flat, opencvRotMat);

    cv::Mat R_wpilib = internal::opencvToWpilib * opencvRotMat * internal::opencvToWpilib.t();

    cv::Mat rvecsWpilib;
    cv::Rodrigues(R_wpilib, rvecsWpilib);
    return rvecsWpilib;
  }

  /**
   * utilty method to convert a wpilib coordinate translational vector to a opencv coordinate translational vector
   * @param tvecs wpilib translational vector
   */
  inline cv::Mat wpilibToOpencvTranslation(const cv::Mat &tvecs) {
    cv::Mat flat = internal::convertVec64Flat(tvecs);
    return (cv::Mat_<double>(3, 1) <<
      -flat.at<double>(1, 0),
      -flat.at<double>(2, 0),
      flat.at<double>(0, 0));
  }

  /**
   * utility method to convert a wpilib coordinate rotational vector to a opencv coordinate rotational vector
   * @param rvecs wpilib rotational vector
   */
  inline cv::Mat wpilibToOpencvRotation(const cv::Mat &rvecs) {
    cv::Mat flat = internal::convertVec64Flat(rvecs);
    cv::Mat wpilibRotMat;
    cv::Rodrigues(flat, wpilibRotMat);

    cv::Mat R_opencv = internal::opencvToWpilib.t() * wpilibRotMat * internal::opencvToWpilib;

    cv::Mat rvecsOpencv;
    cv::Rodrigues(R_opencv, rvecsOpencv);
    return rvecsOpencv;
  }

  /**
   * utilty method to convert a wpilib coordinate translational vector to a opencv coordinate translational vector
   * @param p cv::Point3f in wpilib coordinates
   */
  inline cv::Point3f wpilibToOpencvTranslation(const cv::Point3f &p) {
    return cv::Point3f(-p.y, -p.z, p.x);
  }

   /**
   * utilty method to convert a opencv coordinate translational vector to a wpilib coordinate translational vector
   * @param p cv::Point3f in opencv coordinates
   */
  inline cv::Point3f opencvToWpilibTranslation(const cv::Point3f &p) {
    return cv::Point3f(p.z, -p.x, -p.y);
  }
}
