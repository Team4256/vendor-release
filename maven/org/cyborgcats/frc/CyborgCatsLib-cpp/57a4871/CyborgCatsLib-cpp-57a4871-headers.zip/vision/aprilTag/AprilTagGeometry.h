#pragma once

#include <map>
#include <vector>
#include <opencv2/core/types.hpp>
#include <units/length.h>
#include <frc/apriltag/AprilTagFieldLayout.h>

#include "vision/CoordinateConversion.h"

/**
 * utility class defining world space april tag positions
 */
class AprilTagGeometry {
  public:
    /**
     * type alias for a map of april tag ids and corners
     */
    using CornerMap = std::map<int, std::vector<cv::Point3f>>;

    /**
     * utility method for generating a corner map from an april tag layout
     * @param layout frc::AprilTagFieldLayout defining world space poses of the tags
     */
    static CornerMap generateCornerMap(const frc::AprilTagFieldLayout &layout);

    // user defined april tag size
    static constexpr units::meter_t tagSize = 6.5_in;

    // half of the april tag size used in tag object points
    static constexpr float halfTagSize = tagSize.value() / 2.0f;

    // list of corners in an april tag defined from the center
    static inline const std::vector<cv::Point3f> tagObjectPoints = {
      {0.0f, -halfTagSize, -halfTagSize},
      {0.0f, halfTagSize, -halfTagSize},
      {0.0f, halfTagSize, halfTagSize},
      {0.0f, -halfTagSize, halfTagSize}
    };

    /**
     * transforms tagObjectPoints into a [1, 0, 3, 2] order that the IPPE_SQUARE solver expects
     */
    static inline const std::vector<cv::Point3f> ippeSquareObjectPoints = {
      CoordinateConversion::wpilibToOpencvTranslation(tagObjectPoints[1]),
      CoordinateConversion::wpilibToOpencvTranslation(tagObjectPoints[0]),
      CoordinateConversion::wpilibToOpencvTranslation(tagObjectPoints[3]),
      CoordinateConversion::wpilibToOpencvTranslation(tagObjectPoints[2]),
    };

    /**
     * reorders the corners object from the aruco detector into the permutation [1, 0, 3, 2]
     * @param corners from the aruco detector
     */
    static std::vector<cv::Point2f> reorderIppeSquareImagePoints(const std::vector<cv::Point2f> &corners);
};
