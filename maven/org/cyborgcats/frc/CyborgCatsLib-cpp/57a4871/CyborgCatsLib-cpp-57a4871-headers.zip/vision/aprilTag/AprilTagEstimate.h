#pragma once
#include <limits>
#include <frc/geometry/Pose3d.h>
#include <vector>

#include "vision/aprilTag/AprilTagTarget.h"

/**
 * struct containing all estimate data solved by the april tag estimator
 */
struct AprilTagEstimate {
  frc::Pose3d pose1;  ///< first pose of the estimate
  frc::Pose3d pose2;  ///< second pose of the estimate (single tag only)
  double error1 = std::numeric_limits<double>::quiet_NaN();  ///< reprojection error of the first pose
  double error2 = std::numeric_limits<double>::quiet_NaN();  ///< reprojection error of the second pose

  int tagCount = 0;      ///< number of tags used in the estimate
  double tagArea = 0.0;  ///< percentage of area of tags in the estimate on a scale of 0 - 100

  std::vector<AprilTagTarget> targets;
};
