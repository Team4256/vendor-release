#include "vision/aprilTag/AprilTagEstimator.h"

#include <cmath>
#include <iostream>
#include <frc/geometry/Pose3d.h>
#include <opencv2/calib3d.hpp>

#include "vision/aprilTag/AprilTagArea.h"

// Single-tag IPPE_SQUARE and multi-tag SQPNP pose solving.

std::optional<AprilTagEstimate>  AprilTagEstimator::solveEstimatePnP(const std::vector<int> &ids, const std::vector<std::vector<cv::Point2f>> &corners) const {
    if (ids.empty() || corners.empty() || ids.size() != corners.size()) {
        return std::nullopt;
    }

    int tagCount = ids.size();
    double tagArea = AprilTagArea::computeTagArea(corners, imageWidth, imageHeight);

    std::vector<AprilTagTarget> targets;

    for (int i = 0; i < tagCount; ++i) {
      auto target = buildAprilTagTargetPnP(ids.at(i), corners.at(i));
      targets.push_back(target);
    }

    if (tagCount == 1) {
      auto tagPoseOpt = layout.GetTagPose(ids.at(0));
      const auto &target = targets.at(0); // only one target since there is only one april tag

      if (!tagPoseOpt) {
        return std::nullopt;
      }

      if (std::isnan(target.bestError)) {
        return std::nullopt;
      }

      frc::Pose3d tagPose = tagPoseOpt.value();

      frc::Pose3d cameraPose1 = tagPose.TransformBy(target.bestCameraToTag.Inverse());
      frc::Pose3d cameraPose2 = tagPose.TransformBy(target.altCameraToTag.Inverse());

      AprilTagEstimate estimate;
      estimate.pose1 = cameraPose1;
      estimate.pose2 = cameraPose2;
      estimate.error1 = target.bestError;
      estimate.error2 = target.altError;
      estimate.tagCount = tagCount;
      estimate.tagArea = tagArea;
      estimate.targets = targets;
      return estimate;

    } else {
      std::vector<cv::Mat> rvecs, tvecs;
      std::vector<double> errors;

      std::vector<cv::Point3f> worldPoints;
      std::vector<cv::Point2f> imagePoints;

      for (size_t i = 0; i < ids.size(); ++i) {
        auto it = cornerMap.find(ids.at(i));
        if (it == cornerMap.end()) continue;
        const auto &tagWorld = it->second;
        if (corners.at(i).size() != tagWorld.size()) continue;

        worldPoints.insert(worldPoints.end(), tagWorld.begin(), tagWorld.end());
        imagePoints.insert(imagePoints.end(), corners.at(i).begin(), corners.at(i).end());
      }

      if (worldPoints.size() < 4) return std::nullopt;

      try
      {
        cv::solvePnPGeneric(
            worldPoints,
            imagePoints,
            cameraMatrix,
            distCoeffs,
            rvecs,
            tvecs,
            false,
            cv::SOLVEPNP_SQPNP,
            cv::noArray(),
            cv::noArray(),
            errors
          );
      }
      catch(const std::exception& e)
      {
        std::cerr << e.what() << '\n';
        return std::nullopt;
      }

      if (rvecs.empty() || errors.empty()) return std::nullopt;

      frc::Pose3d cameraPose = frc::Pose3d().TransformBy(cameraToTagTransform(tvecs.at(0), rvecs.at(0)).Inverse());

      AprilTagEstimate estimate;
      estimate.pose1 = cameraPose;
      estimate.error1 = errors.at(0);
      estimate.tagCount = tagCount;
      estimate.tagArea = tagArea;
      estimate.targets = targets;
      return estimate;
    }
}