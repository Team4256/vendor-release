#include "vision/aprilTag/AprilTagArea.h"

#include <opencv2/imgproc.hpp>

double AprilTagArea::computeTagArea(
  const std::vector<std::vector<cv::Point2f>> &corners,
  int imageWidth, int imageHeight
) {
  double totalPixelArea = 0.0;
  for (const auto &tagCorners: corners) {
    if (tagCorners.size() >= 3) {
      totalPixelArea += cv::contourArea(tagCorners);
    }
  }
  const double imageArea = static_cast<double>(imageWidth) * imageHeight;
  if (imageArea <= 0.0) return 0.0;
  return (totalPixelArea / imageArea) * 100.0;
}
