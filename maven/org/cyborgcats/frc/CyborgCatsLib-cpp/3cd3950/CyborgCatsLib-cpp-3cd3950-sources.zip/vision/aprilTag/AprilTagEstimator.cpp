#include "vision/aprilTag/AprilTagEstimator.h"

#include <cmath>
#include <iostream>
#include <frc/EigenCore.h>
#include <frc/geometry/Transform3d.h>
#include <units/length.h>
#include <opencv2/calib3d.hpp>
#include <opencv2/imgproc.hpp>

#include "vision/aprilTag/AprilTagGeometry.h"
#include "vision/aprilTag/AprilTagArea.h"
#include "vision/CoordinateConversion.h"

// cmath is not defined use kPi instead
namespace {
constexpr double kPi = 3.14159265358979323846;
}  // namespace

// Shared estimator setup + camera-frame primitives.
// Individual solvers live in AprilTagEstimator<Strategy>.cpp.

AprilTagEstimator::AprilTagEstimator(
  const cv::Mat &cameraMatrix,
  const cv::Mat &distCoeffs,
  int imageWidth,
  int imageHeight,
  const frc::AprilTagFieldLayout &layout) :
  cameraMatrix(cameraMatrix),
  distCoeffs(distCoeffs),
  imageWidth(imageWidth),
  imageHeight(imageHeight),
  layout(layout) {
    cornerMap = AprilTagGeometry::generateCornerMap(layout);
  }

frc::Transform3d AprilTagEstimator::cameraToTagTransform(const cv::Mat &tvec, const cv::Mat &rvec) const {
  cv::Mat wpilibTvec = CoordinateConversion::opencvToWpilibTranslation(tvec);
  cv::Mat wpilibRvec = CoordinateConversion::opencvToWpilibRotation(rvec);

  frc::Translation3d translation = frc::Translation3d(
      units::meter_t{wpilibTvec.at<double>(0)},
      units::meter_t{wpilibTvec.at<double>(1)},
      units::meter_t{wpilibTvec.at<double>(2)});

  Eigen::Vector3d rotationVector{
      wpilibRvec.at<double>(0),
      wpilibRvec.at<double>(1),
      wpilibRvec.at<double>(2)
  };

  return frc::Transform3d(translation, frc::Rotation3d(rotationVector));
}

AprilTagTarget AprilTagEstimator::buildAprilTagTargetPnP(
  int id,
  const std::vector<cv::Point2f> &corners
) const {
  AprilTagTarget target;

  target.id = id;
  target.corners = corners;

  if (corners.size() != 4) {
    return target;
  }

  try {
    target.area = AprilTagArea::computeTagArea({corners}, imageWidth, imageHeight);
    target.skew = cv::minAreaRect(corners).angle * (kPi / 180.0);

    cv::Point2f center{0.0f, 0.0f};
    for (const auto &corner : corners) {
      center += corner;
    }
    center /= static_cast<float>(corners.size());

    std::vector<cv::Point2f> normalized;
    cv::undistortPoints(std::vector<cv::Point2f>{center}, normalized, cameraMatrix, distCoeffs);
    target.yaw = std::atan2(-normalized.front().x, 1.0);
    target.pitch = std::atan2(-normalized.front().y, 1.0);

    std::vector<cv::Mat> rvecs, tvecs;
    std::vector<double> errors;
    cv::solvePnPGeneric(
        AprilTagGeometry::ippeSquareObjectPoints,
        AprilTagGeometry::reorderIppeSquareImagePoints(corners),
        cameraMatrix,
        distCoeffs,
        rvecs,
        tvecs,
        false,
        cv::SOLVEPNP_IPPE_SQUARE,
        cv::noArray(),
        cv::noArray(),
        errors);

    if (rvecs.size() >= 2 && errors.size() >= 2) {
      const int best = errors.at(0) <= errors.at(1) ? 0 : 1;
      const int alt = best == 0 ? 1 : 0;
      target.bestCameraToTag = cameraToTagTransform(tvecs.at(best), rvecs.at(best));
      target.altCameraToTag = cameraToTagTransform(tvecs.at(alt), rvecs.at(alt));
      target.bestError = errors.at(best);
      target.altError = errors.at(alt);
    }
  } catch (const std::exception &e) {
    std::cerr << e.what() << '\n';
  }

  return target;
}
