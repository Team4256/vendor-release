#include "vision/aprilTag/AprilTagEstimator.h"

#include <cmath>
#include <iostream>
#include <frc/geometry/Pose3d.h>
#include <frc/geometry/Transform3d.h>
#include <units/length.h>
#include <opencv2/calib3d.hpp>
#include <opencv2/imgproc.hpp>

#include "vision/aprilTag/AprilTagArea.h"
//cmath is not avalible on windows without quirks use kPi insetad
namespace {
constexpr double kPi = 3.14159265358979323846;
}  // namespace

// Single-tag trigonometric solve using a known gyro heading and camera mount.
// Assumes the robot is flat on the floor.

std::optional<AprilTagEstimate> AprilTagEstimator::solveEstimateTrig(
  const std::vector<int> &ids,
  const std::vector<std::vector<cv::Point2f>> &corners,
  const frc::Transform3d &cameraToRobot,
  double gyroHeadingRadians
) const {
  if (ids.empty() || corners.empty() || ids.size() != corners.size()) {
    return std::nullopt;
  }

  // camera mount geometry (assumes the robot is flat on the floor)
  const double cameraHeight = cameraToRobot.Z().value();
  const double mountPitch = cameraToRobot.Rotation().Y().value();
  const double mountYaw = cameraToRobot.Rotation().Z().value();

  std::vector<AprilTagTarget> targets;

  for (size_t i = 0; i < ids.size(); ++i) {
    auto tagPoseOpt = layout.GetTagPose(ids.at(i));
    if (!tagPoseOpt) {
      continue;
    }
    const frc::Pose3d tagPose = tagPoseOpt.value();

    if (corners.at(i).size() != 4) {
      continue;
    }

    // build the camera-frame target (yaw/pitch bearings) for this tag
    AprilTagTarget target;
    target.id = ids.at(i);
    target.corners = corners.at(i);

    try {
      target.area = AprilTagArea::computeTagArea({corners.at(i)}, imageWidth, imageHeight);
      target.skew = cv::minAreaRect(corners.at(i)).angle * (kPi / 180.0);

      cv::Point2f center{0.0f, 0.0f};
      for (const auto &corner : corners.at(i)) {
        center += corner;
      }
      center /= static_cast<float>(corners.at(i).size());

      std::vector<cv::Point2f> normalized;
      cv::undistortPoints(std::vector<cv::Point2f>{center}, normalized, cameraMatrix, distCoeffs);
      target.yaw = std::atan2(-normalized.front().x, 1.0);
      target.pitch = std::atan2(-normalized.front().y, 1.0);
    } catch (const std::exception &e) {
      std::cerr << e.what() << '\n';
      continue;
    }

    // elevation angle camera -> tag = mount tilt + the tag's measured pitch bearing
    const double totalPitch = mountPitch + target.pitch;
    if (std::abs(totalPitch) < 1e-3) {
      continue; // too close to horizontal -- distance is unreliable
    }

    const double deltaHeight = tagPose.Z().value() - cameraHeight;
    const double distance = deltaHeight / std::tan(totalPitch);
    if (!std::isfinite(distance) || distance <= 0.0) {
      continue;
    }

    // field bearing camera -> tag = gyro heading + mount yaw + the tag's measured yaw bearing
    const double totalHeading = gyroHeadingRadians + mountYaw + target.yaw;

    // walk backwards from the known tag position to the camera position
    const double cameraX = tagPose.X().value() - distance * std::cos(totalHeading);
    const double cameraY = tagPose.Y().value() - distance * std::sin(totalHeading);
    if (!std::isfinite(cameraX) || !std::isfinite(cameraY)) {
      continue;
    }

    target.bestCameraToTag = frc::Transform3d(
      frc::Translation3d(units::meter_t{cameraX}, units::meter_t{cameraY}, units::meter_t{0.0}),
      frc::Rotation3d(units::radian_t{0.0}, units::radian_t{0.0}, units::radian_t{gyroHeadingRadians}));

    targets.push_back(target);
  }

  // only the tags that survived the loop above contribute to the estimate
  std::vector<std::vector<cv::Point2f>> usedCorners;
  usedCorners.reserve(targets.size());
  for (const auto &target : targets) {
    usedCorners.push_back(target.corners);
  }

  AprilTagEstimate estimate;
  estimate.tagCount = static_cast<int>(targets.size());
  estimate.tagArea = AprilTagArea::computeTagArea(usedCorners, imageWidth, imageHeight);
  estimate.targets = targets;
  return estimate;
}
