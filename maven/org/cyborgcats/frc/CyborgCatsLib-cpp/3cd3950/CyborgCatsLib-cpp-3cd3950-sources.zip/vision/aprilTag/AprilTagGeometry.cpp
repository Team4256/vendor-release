#include "vision/aprilTag/AprilTagGeometry.h"
#include "vision/CoordinateConversion.h"

#include <frc/EigenCore.h>
#include <frc/geometry/Pose3d.h>

AprilTagGeometry::CornerMap AprilTagGeometry::generateCornerMap(const frc::AprilTagFieldLayout &layout) {
  AprilTagGeometry::CornerMap cornerMap;
  for (const auto &tag : layout.GetTags()) {
    int id = tag.ID;
    frc::Pose3d tagPose = tag.pose;

    Eigen::Matrix3d R = tagPose.Rotation().ToMatrix();

    std::vector<cv::Point3f> corners;
    for (const auto &lp : tagObjectPoints) {
      Eigen::Vector3d local(lp.x, lp.y, lp.z);
      Eigen::Vector3d world = R * local;
      world(0) += tagPose.X().value();
      world(1) += tagPose.Y().value();
      world(2) += tagPose.Z().value();

      cv::Point3f worldPt{(float)world(0), (float)world(1), (float)world(2)};
      corners.push_back(CoordinateConversion::wpilibToOpencvTranslation(worldPt));
    }
    cornerMap[id] = corners;
  }
  return cornerMap;
}

std::vector<cv::Point2f> AprilTagGeometry::reorderIppeSquareImagePoints(
    const std::vector<cv::Point2f> &corners) {
  return { corners.at(1), corners.at(0), corners.at(3), corners.at(2) };
}
