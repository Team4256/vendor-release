package org.cyborgcats.component;

import java.util.function.Supplier;

import org.jsi.annotations.Units.m;
import org.jsi.annotations.Units.m_s;

import edu.wpi.first.math.geometry.Pose3d;
import edu.wpi.first.math.kinematics.ChassisSpeeds;

/**
 * Drivetrain state suppliers needed by components (e.g. {@link Turret}) that compensate their
 * aiming for robot motion.
 *
 * @param robotPose            supplier of the robot's current field-relative pose
 * @param fieldRelativeSpeeds  supplier of the robot's current field-relative chassis speeds
 */
public record DriveState(@m Supplier<Pose3d> robotPose, @m_s Supplier<ChassisSpeeds> fieldRelativeSpeeds) {
}
