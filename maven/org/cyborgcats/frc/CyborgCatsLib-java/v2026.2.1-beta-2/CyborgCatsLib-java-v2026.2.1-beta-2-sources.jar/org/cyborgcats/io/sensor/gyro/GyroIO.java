package org.cyborgcats.io.sensor.gyro;

import edu.wpi.first.math.geometry.Rotation3d;
import edu.wpi.first.units.measure.Angle;
import org.littletonrobotics.junction.AutoLog;
import org.jsi.annotations.Units.rad;
import org.jsi.annotations.Units.rad_s;

/**
 * Interface defining how to communicate with a gyro sensor device.
 */
public interface GyroIO {
  /**
   * Resets the heading to the provided angle.
   *
   * @param heading new heading value
   */
  void reset(Angle heading);

  /**
   * Updates the gyro's reported inputs.
   *
   * @param inputs loggable gyro inputs to populate
   */
  void updateInputs(GyroInputs inputs);

  /**
   * AdvantageKit-loggable container of gyro telemetry fields.
   */
  @AutoLog
  class GyroInputs {
    /**
     * Current 3D orientation of the gyro (roll, pitch, yaw) in radians.
     */
    @rad public Rotation3d rotation = new Rotation3d();
    /** Angular velocity about each world axis in radians per second. */
    @rad_s public Rotation3d angularVelocityRadPerSec = new Rotation3d();
    /** Whether the gyro is detected on the bus. */
    public boolean connected = false;
  }
}
