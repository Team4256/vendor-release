package org.cyborgcats.vision;

import org.jsi.annotations.Units.m;
import org.jsi.annotations.Units.s;

import edu.wpi.first.math.Matrix;
import edu.wpi.first.math.geometry.Pose2d;
import edu.wpi.first.math.numbers.N1;
import edu.wpi.first.math.numbers.N3;

/**
 * A single vision-based robot pose measurement, ready to feed into a pose estimator.
 *
 * @param visionRobotPoseMeters    field-relative robot pose measured by vision
 * @param timestampSeconds         capture timestamp of the measurement, in seconds
 * @param visionMeasurementStdDevs standard deviations of the measurement, for weighting against
 *     other pose sources
 */
public record VisionMeasurment(
    @m Pose2d visionRobotPoseMeters,
    @s double timestampSeconds,
    Matrix<N3, N1> visionMeasurementStdDevs) {
}
