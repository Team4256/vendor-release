package org.cyborgcats.io.sensor.gyro;

import com.ctre.phoenix6.BaseStatusSignal;
import com.ctre.phoenix6.StatusSignal;
import com.ctre.phoenix6.hardware.Pigeon2;

import edu.wpi.first.math.geometry.Rotation3d;
import edu.wpi.first.units.Units;
import edu.wpi.first.units.measure.Angle;
import edu.wpi.first.units.measure.AngularVelocity;
import org.jsi.annotations.Units.deg;
import org.jsi.annotations.Units.deg_s;

/**
 * Gyro IO implementation for the CTRE Pigeon 2 IMU.
 */
public class GyroIOPigeon2 implements GyroIO {
  private final Pigeon2 gyro;
  private final @deg StatusSignal<Angle> yaw;
  private final @deg StatusSignal<Angle> pitch;
  private final @deg StatusSignal<Angle> roll;
  private final @deg_s StatusSignal<AngularVelocity> xVelo;
  private final @deg_s StatusSignal<AngularVelocity> yVelo;
  private final @deg_s StatusSignal<AngularVelocity> zVelo;

  /**
   * Constructs a GyroIOPigeon2 and caches all required status signals.
   *
   * @param canID CAN bus ID of the Pigeon 2 IMU
   */
  public GyroIOPigeon2(int canID) {
    gyro = new Pigeon2(canID);
    yaw = gyro.getYaw();
    pitch = gyro.getPitch();
    roll = gyro.getRoll();
    xVelo = gyro.getAngularVelocityXWorld();
    yVelo = gyro.getAngularVelocityYWorld();
    zVelo = gyro.getAngularVelocityZWorld();
  }

  @Override
  public void updateInputs(GyroInputs inputs) {
    BaseStatusSignal.refreshAll(yaw, pitch, roll, xVelo, yVelo, zVelo);
    inputs.rotation = new Rotation3d(
        roll.getValue().in(Units.Radians),
        pitch.getValue().in(Units.Radians),
        yaw.getValue().in(Units.Radians)
    );
    inputs.angularVelocityRadPerSec = new Rotation3d(
        xVelo.getValue().in(Units.RadiansPerSecond),
        yVelo.getValue().in(Units.RadiansPerSecond),
        zVelo.getValue().in(Units.RadiansPerSecond)
    );
    inputs.connected = gyro.isConnected();
  }

  @Override
  public void reset(Angle headingRad) {
    gyro.setYaw(headingRad.in(Units.Degrees));
  }
}
