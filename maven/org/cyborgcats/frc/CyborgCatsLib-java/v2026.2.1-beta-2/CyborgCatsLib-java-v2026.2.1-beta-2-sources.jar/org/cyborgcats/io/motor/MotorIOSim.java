package org.cyborgcats.io.motor;

import edu.wpi.first.math.MathUtil;
import edu.wpi.first.math.trajectory.TrapezoidProfile;
import edu.wpi.first.wpilibj.RobotController;
import org.cyborgcats.component.Setpoint;
import org.cyborgcats.energy.EnergyIO;
import org.cyborgcats.energy.EnergyTracker;
import org.cyborgcats.energy.EnergyTracker.Energy;
import org.jsi.annotations.Units.A;
import org.jsi.annotations.Units.Ohm;
import org.jsi.annotations.Units.V;
import org.jsi.annotations.Units.rot;
import org.jsi.annotations.Units.s;
import org.jsi.annotations.Units.rot_s;
import org.jsi.annotations.Units.rot_s2;

/**
 * Motor IO implementation that simulates a brushless motor with trapezoidal motion profiling.
 */
public class MotorIOSim implements MotorIO, EnergyIO {

  private static final @s double dT = 0.02;
  private static final @A double defaultLimit = 40.0;
  private static final double KV =
    12.0 / 100.0;
  private static final @Ohm double resistance = 0.030;
  private static final @rot double referenceDistance = Math.PI;

  private final @A double currentLimit;
  private final @rot_s2 double maxAcceleration;
  private final TrapezoidProfile profile;
  private final EnergyTracker energyTracker;

  private Setpoint.Mode currentMode = Setpoint.Mode.Neutral;
  private @rot_s double velocityTarget = 0;
  private @rot double positionTarget = 0;
  private @V double voltageTarget = 0;
  private double dutyCycleTarget = 0.0;

  private @rot_s double velocity = 0;
  private @rot double position = 0;
  private @V double voltage = 0;
  private @A double current = 0;

  private final String name;

  /**
   * class constructor for a simulated motor using default current limits
   *
   * @param settlingTime rough time for a motor to reach setpoint
   *                     increasing value means a slower motor
   *                     decreasing value means a faster motor
   * @param name the name of the motor
   */
  public MotorIOSim(@s double settlingTime, String name) {
    this(settlingTime, defaultLimit, name);
  }

  /**
   * class constructor for a simulated motor
   *
   * @param settlingTime rough time for a motor to reach setpoint
   *                     increasing value means a slower motor
   *                     decreasing value means a faster motor
   * @param currentLimit applied current limit to the motor
   *                     increasing values means higher current
   *                     decreasing values means lower current
   * @param name the name of the motor
   */
  public MotorIOSim(@s double settlingTime, @A double currentLimit, String name) {
    @rot_s double maxVelocity = referenceDistance / settlingTime;
    this.maxAcceleration = referenceDistance / (settlingTime * settlingTime);
    this.profile = new TrapezoidProfile(
      new TrapezoidProfile.Constraints(maxVelocity, maxAcceleration)
    );
    this.currentLimit = currentLimit;
    this.name = name;

    energyTracker = new EnergyTracker(this);
  }

  @Override
  public String getName() {
    return name;
  }

  @Override
  public void updateInputs(MotorInputs inputs) {
    step();
    inputs.velocity = velocity;
    inputs.position = position;
    inputs.motorVoltage = voltage;
    inputs.supplyVoltage = RobotController.getBatteryVoltage();
    inputs.statorCurrent = current;
    inputs.connected = true;
    inputs.mode = currentMode;
    inputs.setpoint = targetValue();
    Energy energy = energyTracker.getEnergy();
    inputs.power = energy.power();
    inputs.energy = energy.totalEnergy();
  }

  @Override
  public void setCurrentPosition(@rot double position) {
    this.position = position;
  }

  private void step() {
    @rot_s double v = velocity;
    @rot double p = position;
    @rot_s double vt = velocityTarget;
    @rot double pt = positionTarget;
    @V double vlt;

    switch (currentMode) {
      case Velocity, VelocityMotionProfile, VelocityTorqueCurrent -> {
        v += MathUtil.clamp(
          vt - v,
          -maxAcceleration * dT,
          maxAcceleration * dT
        );
        p += v * dT;
        vlt = v * KV;
      }
      case Position, PositionMotionProfile -> {
        var next = profile.calculate(
          dT,
          new TrapezoidProfile.State(p, v),
          new TrapezoidProfile.State(pt, 0.0)
        );
        p = next.position;
        v = next.velocity;
        vlt = v * KV;
      }
      case Voltage -> {
        vlt = voltageTarget;
        v = vlt / KV;
        p += v * dT;
      }
      case DutyCycle -> {
        vlt = dutyCycleTarget * 12.0;
        v = vlt / KV;
        p += v * dT;
      }
      default -> {
        v = 0.0;
        vlt = 0.0;
      }
    }

    @A double curr = MathUtil.clamp(
      Math.abs(vlt) / resistance,
      0.0,
      currentLimit
    );

    velocity = v;
    position = p;
    voltage = vlt;
    current = curr;
  }

  private double targetValue() {
    return switch (currentMode) {
      case Velocity, VelocityMotionProfile, VelocityTorqueCurrent -> velocityTarget;
      case Position, PositionMotionProfile -> positionTarget;
      case Voltage -> voltageTarget;
      case DutyCycle -> dutyCycleTarget;
      default -> 0.0;
    };
  }

  @Override
  public void applyNetural() {
    currentMode = Setpoint.Mode.Neutral;
  }

  @Override
  public void applyVoltageSetpoint(@V double v) {
    currentMode = Setpoint.Mode.Voltage;
    voltageTarget = v;
  }

  @Override
  public void applyVelocitySetpoint(@rot_s double v) {
    currentMode = Setpoint.Mode.Velocity;
    velocityTarget = v;
  }

  @Override
  public void applyPositionSetpoint(@rot double position) {
    currentMode = Setpoint.Mode.Position;
    positionTarget = position;
  }

  @Override
  public void applyDutyCycleSetpoint(double p) {
    currentMode = Setpoint.Mode.DutyCycle;
    dutyCycleTarget = p;
  }

  @Override
  public void applyPositionMotionProfile(@rot double position) {
    currentMode = Setpoint.Mode.PositionMotionProfile;
    positionTarget = position;
  }

  @Override
  public void applyVelocityTorqueCurrent(@rot_s double velocity) {
    currentMode = Setpoint.Mode.VelocityTorqueCurrent;
    velocityTarget = velocity;
  }
  
  @Override
  public void applyVelocityMotionProfile(@rot_s double velocity) {
    currentMode = Setpoint.Mode.VelocityMotionProfile;
    velocityTarget = velocity;
  }

  @Override
  public @V double getSupplyVoltage() {
    return 12.0;
  }

  @Override
  public @A double getSupplyCurrent() {
    return current;
  }
}
