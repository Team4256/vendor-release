package org.cyborgcats.io.motor;

import org.jsi.annotations.Units.s;

import com.thrifty.core.Motor.MotorType;
import com.thrifty.nova.NovaConfigBatch;

public class MotorIONovaConfiguration implements MotorIOConfiguration {
    private final String name;
    private final int canID;
    private final int busID;
    private final MotorType type;
    private final NovaConfigBatch conf;
    private final @s double simSettlingTime;

    public MotorIONovaConfiguration(String name, int canID, int busID, MotorType type, NovaConfigBatch conf, @s double simSettlingTime) {
        this.name = name;
        this.canID = canID;
        this.busID = busID;
        this.type = type;
        this.conf = conf;
        this.simSettlingTime = simSettlingTime;
    }

    @Override
    public MotorIO buildReal() {
        return new MotorIONova(name, canID, busID, type, conf);
    }

    @Override
    public MotorIO buildSim() {
        return new MotorIOSim(simSettlingTime, name);
    }
}
