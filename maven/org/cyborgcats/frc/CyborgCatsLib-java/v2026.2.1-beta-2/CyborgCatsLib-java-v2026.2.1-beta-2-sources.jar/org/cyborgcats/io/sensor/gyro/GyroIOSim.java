package org.cyborgcats.io.sensor.gyro;

import java.util.function.Supplier;
import edu.wpi.first.math.geometry.Rotation3d;
import edu.wpi.first.math.kinematics.ChassisSpeeds;
import edu.wpi.first.units.Units;
import edu.wpi.first.units.measure.Angle;
import org.jsi.annotations.Units.s;
import org.jsi.annotations.Units.m_s;
import org.jsi.annotations.Units.rad;
import org.jsi.annotations.Units.rad_s;


/**
 * Gyro IO implementation that integrates chassis speeds to simulate heading.
 */
public class GyroIOSim implements GyroIO {
  private static final @s double DT = 0.02;
  private final @m_s Supplier<ChassisSpeeds> speeds;
  private @rad double yawRad = 0.0;

  /**
   * class constructor for a simulated gyro
   *
   * @param speeds robot relative chassis speeds used to update yaw angle
   */
  public GyroIOSim(@m_s Supplier<ChassisSpeeds> speeds) {
    this.speeds = speeds;
  }

  @Override
  public void reset(Angle headingRad) {
    yawRad = headingRad.in(Units.Radian);
  }

  @Override
  public void updateInputs(GyroInputs inputs) {
    @rad_s double omega = speeds.get().omegaRadiansPerSecond;
    yawRad += omega * DT;
    inputs.rotation = new Rotation3d(0.0, 0.0, yawRad);
    inputs.angularVelocityRadPerSec = new Rotation3d(0.0, 0.0, omega);
    inputs.connected = true;
  }
}
