package org.cyborgcats.io.motor;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.StatusSignal;
import com.ctre.phoenix6.StatusSignalCollection;
import com.ctre.phoenix6.configs.TalonFXConfiguration;
import com.ctre.phoenix6.controls.ControlRequest;
import com.ctre.phoenix6.controls.DutyCycleOut;
import com.ctre.phoenix6.controls.Follower;
import com.ctre.phoenix6.controls.MotionMagicVelocityVoltage;
import com.ctre.phoenix6.controls.MotionMagicVoltage;
import com.ctre.phoenix6.controls.NeutralOut;
import com.ctre.phoenix6.controls.PositionVoltage;
import com.ctre.phoenix6.controls.VelocityTorqueCurrentFOC;
import com.ctre.phoenix6.controls.VelocityVoltage;
import com.ctre.phoenix6.controls.VoltageOut;
import com.ctre.phoenix6.hardware.TalonFX;
import com.ctre.phoenix6.signals.MotorAlignmentValue;
import edu.wpi.first.units.measure.Angle;
import edu.wpi.first.units.measure.AngularAcceleration;
import edu.wpi.first.units.measure.AngularVelocity;
import edu.wpi.first.units.measure.Current;
import edu.wpi.first.units.measure.Temperature;
import edu.wpi.first.units.measure.Voltage;
import edu.wpi.first.wpilibj.Alert;
import edu.wpi.first.wpilibj.Alert.AlertType;

import org.cyborgcats.component.Setpoint;
import org.cyborgcats.energy.EnergyIO;
import org.cyborgcats.energy.EnergyTracker;
import org.cyborgcats.energy.EnergyTracker.Energy;
import org.jsi.annotations.Units.A;
import org.jsi.annotations.Units.V;
import org.jsi.annotations.Units.rot;
import org.jsi.annotations.Units.rot_s;
import org.jsi.annotations.Units.rot_s2;

/**
 * Hardware abstraction for a single TalonFX motor controller.
 */
public class MotorIOTalonFX implements MotorIO, EnergyIO {
  private final TalonFX motor;
  private final String name;
  private boolean isFollower;

  private final @V StatusSignal<Voltage> motorVoltage;
  private final @V StatusSignal<Voltage> suppyVoltage;
  private final @A StatusSignal<Current> statorCurrent;
  private final @A StatusSignal<Current> supplyCurrent;
  private final @rot StatusSignal<Angle> position;
  private final @rot_s StatusSignal<AngularVelocity> velocity;
  private final @rot_s2 StatusSignal<AngularAcceleration> acceleration;
  private final StatusSignal<Temperature> temperature;
  private final StatusSignalCollection collection;

  // try changing update frequency of requests
  private final NeutralOut neutralRequest = new NeutralOut();
  private final VoltageOut voltageRequest = new VoltageOut(0);
  private final DutyCycleOut dutyCycleRequest = new DutyCycleOut(0);
  private final PositionVoltage positionRequest = new PositionVoltage(0);
  private final MotionMagicVoltage positionMotionProfileRequest = new MotionMagicVoltage(0);
  private final VelocityVoltage velocityRequest = new VelocityVoltage(0);
  private final VelocityTorqueCurrentFOC torqueRequest = new VelocityTorqueCurrentFOC(0.0);
  private final MotionMagicVelocityVoltage velocityMotionMagic = new MotionMagicVelocityVoltage(0.0);
  private final Follower follower = new Follower(0, MotorAlignmentValue.Aligned);

  private double setpoint = 0;
  private Setpoint.Mode mode = Setpoint.Mode.Neutral;

  private final EnergyTracker energyTracker;

  /**
   * constructor for a talonFX MotorIO
   * SuppressWarnings("removal") for the talon fx constructor using the "rio" canbus
   * @param canID device ID of the motor controller
   * @param cfg configuration for the motor controller
   * @param name name of the motor controller
   */
  @SuppressWarnings("removal")
  public MotorIOTalonFX(int canID, TalonFXConfiguration cfg, String name) {
    this.motor = new TalonFX(canID, "rio");
    this.name = name;
    isFollower = false;
    StatusCode code = motor.getConfigurator().apply(cfg);
    
    if (code.isError()) {
      @SuppressWarnings("resource")
      Alert alert = new Alert(
        "Config Error: " + name, AlertType.kWarning);

      alert.set(true);
    }

    motorVoltage = motor.getMotorVoltage();
    suppyVoltage = motor.getSupplyVoltage();
    statorCurrent = motor.getStatorCurrent();
    supplyCurrent = motor.getSupplyCurrent();
    position = motor.getPosition();
    velocity = motor.getVelocity();
    acceleration = motor.getAcceleration();
    temperature = motor.getDeviceTemp();

    collection = new StatusSignalCollection(
      motorVoltage,
      suppyVoltage,
      statorCurrent,
      supplyCurrent,
      position,
      velocity,
      acceleration,
      temperature
    );

    energyTracker = new EnergyTracker(this);
  }

  /**
   * constructor for a talonFX MotorIO that follows another motor at the vendor level, instead of
   * taking its own setpoints
   * @param canID device ID of the motor controller
   * @param cfg configuration for the motor controller
   * @param name name of the motor controller
   * @param leaderID device ID of the motor this one follows
   * @param alignmentValue whether this motor spins the same or opposite direction as the leader
   */
  public MotorIOTalonFX(int canID, TalonFXConfiguration cfg, String name, int leaderID, MotorAlignmentValue alignmentValue) {
    this(canID, cfg, name);
    applyFollowSetpoint(leaderID, alignmentValue);
  }

  @Override
  public void updateInputs(MotorInputs inputs) {
    collection.refreshAll();
    inputs.motorVoltage = motorVoltage.getValueAsDouble();
    inputs.supplyVoltage = suppyVoltage.getValueAsDouble();
    inputs.statorCurrent = statorCurrent.getValueAsDouble();
    inputs.supplyCurrent = supplyCurrent.getValueAsDouble();
    inputs.position = position.getValueAsDouble();
    inputs.velocity = velocity.getValueAsDouble();
    inputs.acceleration = acceleration.getValueAsDouble();
    inputs.temperature = temperature.getValueAsDouble();
    inputs.connected = motor.isConnected();
    inputs.setpoint = setpoint;
    inputs.mode = mode;
    Energy energy = energyTracker.getEnergy();
    inputs.power = energy.power();
    inputs.energy = energy.totalEnergy();
  }

  @Override
  public void setCurrentPosition(@rot double position) {
    motor.setPosition(position);
  }

  @Override
  public void applyNetural() {
    setpoint = 0;
    mode = Setpoint.Mode.Neutral;
    setControl(neutralRequest);
  }

  @Override
  public void applyVoltageSetpoint(@V double voltage) {
    setpoint = voltage;
    mode = Setpoint.Mode.Voltage;
    setControl(voltageRequest.withOutput(voltage));
  }

  @Override
  public void applyDutyCycleSetpoint(double dutyCycle) {
    setpoint = dutyCycle;
    mode = Setpoint.Mode.DutyCycle;
    setControl(dutyCycleRequest.withOutput(dutyCycle));
  }

  @Override
  public void applyVelocitySetpoint(@rot_s double velocity) {
    setpoint = velocity;
    mode = Setpoint.Mode.Velocity;
    setControl(velocityRequest.withVelocity(velocity));
  }

  @Override
  public void applyPositionSetpoint(@rot double position) {
    setpoint = position;
    mode = Setpoint.Mode.Position;
    setControl(positionRequest.withPosition(position));
  }

  @Override
  public void applyPositionMotionProfile(@rot double position) {
      setpoint = position;
      mode = Setpoint.Mode.PositionMotionProfile;
      setControl(positionMotionProfileRequest.withPosition(position));
  }

  @Override
  public void applyVelocityTorqueCurrent(@rot_s double velocity) {
      setpoint = velocity;
      mode = Setpoint.Mode.VelocityTorqueCurrent;
      setControl(torqueRequest.withVelocity(velocity));
  }

  @Override
  public void applyVelocityMotionProfile(@rot_s double velocity) {
      setpoint = velocity;
      mode = Setpoint.Mode.VelocityMotionProfile;
      setControl(velocityMotionMagic.withVelocity(velocity));
  }

  /**
   * commands the motor to follow another motor at the vendor level via a CTRE {@link Follower}
   * control request. Marks this motor as a follower so {@link
   * org.cyborgcats.component.MotorComponent} stops applying independent setpoints to it.
   * @param leaderID device ID of the motor to follow
   * @param alignmentValue whether this motor spins the same or opposite direction as the leader
   */
  private void applyFollowSetpoint(int leaderID, MotorAlignmentValue alignmentValue) {
    this.setpoint = 0;
    mode = Setpoint.Mode.Follower;
    isFollower = true;
    follower.withLeaderID(leaderID);
    follower.withMotorAlignment(alignmentValue);
    setControl(follower);
  }

  @Override
  public boolean isFollower() {
    return isFollower;
  }

  /**
   * helper function to appyl a control request to the motor
   * @param request the control request to apply
   */
  public void setControl(ControlRequest request) {
    motor.setControl(request);
  }

  @Override
  public String getName() {
    return name;
  }

  @Override
  public @V double getSupplyVoltage() {
    return suppyVoltage.getValueAsDouble();
  }

  @Override
  public @A double getSupplyCurrent() {
    return supplyCurrent.getValueAsDouble();
  }
}
