package org.cyborgcats.vision;

/**
 * Pinhole camera intrinsics: focal lengths and principal point, in pixels. Skew is assumed zero.
 *
 * @param fx focal length in the x direction
 * @param cx focal length in the y direction
 * @param fy principal point x coordinate
 * @param cy principal point y coordinate
 */
public record CameraMatrix(double fx, double cx, double fy, double cy) {
  /**
   * @return the intrinsics as a flat 9-element row-major array: {@code [fx, 0, cx, 0, fy, cy, 0, 0, 1]}
   */
  public double[] toArray() {
    return new double[]{fx, 0, cx, 0, fy, cy, 0, 0, 1};
  }
}
