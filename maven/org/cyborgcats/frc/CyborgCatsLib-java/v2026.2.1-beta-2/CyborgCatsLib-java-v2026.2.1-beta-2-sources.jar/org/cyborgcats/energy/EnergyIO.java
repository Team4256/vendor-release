package org.cyborgcats.energy;

import org.jsi.annotations.Units.A;
import org.jsi.annotations.Units.V;

/**
 * Hardware interface for any device whose electrical draw can be sampled, allowing an
 * {@link EnergyTracker} to integrate its power consumption over time.
 */
public interface EnergyIO {
  /**
   * Returns the voltage currently supplied to the device.
   *
   * @return supply voltage in volts
   */
 @V double getSupplyVoltage();

  /**
   * Returns the current currently drawn by the device from its supply.
   *
   * @return supply current in amps
   */
  @A double getSupplyCurrent();
}
