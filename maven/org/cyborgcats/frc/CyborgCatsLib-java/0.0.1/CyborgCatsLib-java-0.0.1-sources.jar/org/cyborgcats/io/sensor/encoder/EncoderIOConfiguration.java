package org.cyborgcats.io.sensor.encoder;

import org.cyborgcats.io.IOConfiguration;

/**
 * Shared shape for configs that build an {@link EncoderIO}; defaults to {@link EncoderIOSim} in
 * simulation.
 */
public interface EncoderIOConfiguration extends IOConfiguration<EncoderIO> {
    default EncoderIO buildSim() {
        return new EncoderIOSim();
    }
}
