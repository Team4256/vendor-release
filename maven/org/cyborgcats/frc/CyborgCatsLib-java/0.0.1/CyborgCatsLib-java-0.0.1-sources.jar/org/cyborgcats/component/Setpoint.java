package org.cyborgcats.component;

import edu.wpi.first.math.MathUtil;
import java.util.function.UnaryOperator;
import org.cyborgcats.io.motor.MotorIO;

/**
 * Represents a motor control setpoint (neutral, voltage, duty cycle, velocity, or position) and
 * provides factory methods for each mode. Applying a setpoint delegates to the appropriate
 * {@link MotorIO} method.
 */
public class Setpoint {

  private final UnaryOperator<MotorIO> applier;
  private final double baseUnits;
  private final Mode mode;

  /**
   * Constructs a Setpoint with an explicit applier, mode, and base-unit value.
   *
   * @param applier   function that applies this setpoint to a {@link MotorIO} instance
   * @param mode      the control mode this setpoint represents
   * @param baseUnits the setpoint magnitude expressed in the SI base unit for the mode
   */
  public Setpoint(UnaryOperator<MotorIO> applier, Mode mode, double baseUnits) {
    this.baseUnits = baseUnits;
    this.mode = mode;
    this.applier = applier;
  }

  /**
   * Creates a neutral (coast/brake) setpoint that commands the motor to output nothing.
   *
   * @return a new neutral {@link Setpoint}
   */
  public static Setpoint neutral() {
    UnaryOperator<MotorIO> applier = io -> {
      io.applyNetural();
      return io;
    };
    return new Setpoint(applier, Mode.NEUTRAL, 0.0);
  }

  /**
   * Creates a voltage-control setpoint.
   *
   * @param volts desired output voltage
   * @return a new voltage {@link Setpoint}
   */
  public static Setpoint withVoltage(double volts) {
    UnaryOperator<MotorIO> applier = io -> {
      io.applyVoltageSetpoint(volts);
      return io;
    };
    return new Setpoint(applier, Mode.VOLTAGE, volts);
  }

  /**
   * Creates a duty-cycle setpoint, clamping the value between -1.0 and 1.0.
   *
   * @param percent desired duty cycle in the range [-1.0, 1.0]
   * @return a new duty-cycle {@link Setpoint}
   */
  public static Setpoint withDutyCycle(double percent) {
    double clampedPercent = MathUtil.clamp(percent, -1.0, 1.0);
    UnaryOperator<MotorIO> applier = io -> {
      io.applyDutyCycleSetpoint(clampedPercent);
      return io;
    };
    return new Setpoint(applier, Mode.DUTYCYCLE, clampedPercent);
  }

  /**
   * Creates a velocity-control setpoint.
   *
   * @param velocity desired angular velocity
   * @return a new velocity {@link Setpoint}
   */
  public static Setpoint withVelocity(double velocity) {
    UnaryOperator<MotorIO> applier = io -> {
      io.applyVelocitySetpoint(velocity);
      return io;
    };
    return new Setpoint(applier, Mode.VELOCITY, velocity);
  }

  /**
   * Creates a position-control setpoint targeting an angular position.
   *
   * @param position desired angular position
   * @return a new position {@link Setpoint}
   */
  public static Setpoint withPosition(double position) {
    UnaryOperator<MotorIO> applier = io -> {
      io.applyPositionSetpoint(position);
      return io;
    };
    return new Setpoint(applier, Mode.POSITION, position);
  }

  /**
   * Creates a motion-profiled (Motion Magic) position-control setpoint targeting an angular
   * position.
   *
   * @param position desired angular position
   * @return a new motion-profiled position {@link Setpoint}
   */
  public static Setpoint withPositionMotionProfile(double position) {
    UnaryOperator<MotorIO> applier = io -> {
      io.applyPositionMotionProfile(position);
      return io;
    };
    return new Setpoint(applier, Mode.POSITIONMOTIONPROFILE, position);
  }

  /**
   * 
   * @param velocity
   * @return
   */
  public static Setpoint withVelocityTorqueCurrent(double velocity) {
    UnaryOperator<MotorIO> applier = io -> {
      io.applyVelocityTorqueCurrent(velocity);
      return io;
    };
    return new Setpoint(applier, Mode.VelocityTorqueCurrent, velocity);
  }

  /**
   * Returns the setpoint magnitude in the SI base unit for this mode (e.g., radians for position).
   *
   * @return the base-unit setpoint value
   */
  public double getBaseUnits() {
    return baseUnits;
  }

  /**
   * Returns the control mode of this setpoint.
   *
   * @return the {@link Mode}
   */
  public Mode getMode() {
    return mode;
  }

  /**
   * Applies this setpoint to the given motor IO, invoking the appropriate setpoint method.
   *
   * @param io motor hardware interface to apply the setpoint to
   */
  public void apply(MotorIO io) {
    applier.apply(io);
  }

  /**
   * Enumerates the available motor control modes.
   */
  public enum Mode {
    /**
     * Motor is commanded to output nothing (coast or brake).
     */
    NEUTRAL,
    /** Motor is controlled by a direct voltage command. */
    VOLTAGE,
    /** Motor is controlled by a duty-cycle percentage. */
    DUTYCYCLE,
    /** Motor is controlled by a closed-loop velocity target. */
    VELOCITY,
    /** Motor is controlled by a closed-loop position target. */
    POSITION,
    /** Motor is controlled by a motion-profiled (Motion Magic) closed-loop position target. */
    POSITIONMOTIONPROFILE,

    VelocityTorqueCurrent,
  }
}
