package org.cyborgcats.io.sensor.encoder;

import com.ctre.phoenix6.BaseStatusSignal;
import com.ctre.phoenix6.StatusSignal;
import com.ctre.phoenix6.configs.CANcoderConfiguration;
import com.ctre.phoenix6.hardware.CANcoder;

import edu.wpi.first.units.measure.Angle;

/**
 * {@link EncoderIO} implementation backed by a CTRE CANcoder absolute magnetic encoder.
 */
public class EncoderIOCANCoder implements EncoderIO {
  private final CANcoder encoder;
  private final StatusSignal<Angle> position;
  private final StatusSignal<Angle> absPosition;

  /**
   * Constructs an EncoderIOCANCoder and caches the position status signals.
   *
   * @param canID CAN bus ID of the CANcoder
   * @param conf  configuration applied to the CANcoder
   */
  public EncoderIOCANCoder(int canID, CANcoderConfiguration conf) {
    encoder = new CANcoder(canID);
    encoder.getConfigurator().apply(conf);
    position = encoder.getPosition();
    absPosition = encoder.getAbsolutePosition();
  }

  @Override
  public void updateInputs(EncoderInputs inputs) {
    BaseStatusSignal.refreshAll(position, absPosition);
    inputs.position = position.getValueAsDouble();
    inputs.absPosition = absPosition.getValueAsDouble();
    inputs.connected = encoder.isConnected();
  }
}
