package org.cyborgcats.io.sensor.encoder;

/**
 * {@link EncoderIO} implementation for simulation; reports a stationary, connected encoder.
 */
public class EncoderIOSim implements EncoderIO {
  @Override
  public void updateInputs(EncoderInputs inputs) {
    inputs.connected = true;
  }
}
