package org.cyborgcats.io.sensor.encoder;

import com.ctre.phoenix6.configs.CANcoderConfiguration;

/**
 * Configuration for a CANcoder-backed {@link EncoderIO}.
 */
public class EncoderIOCANCoderConfiguration implements EncoderIOConfiguration {
    private final int canID;
    private final CANcoderConfiguration conf;

    /**
     * Constructs an EncoderIOCANCoderConfiguration.
     *
     * @param canID device ID of the CANcoder
     * @param conf  configuration applied to the CANcoder
     */
    public EncoderIOCANCoderConfiguration(int canID, CANcoderConfiguration conf) {
        this.canID = canID;
        this.conf = conf;
    }

    @Override
    public EncoderIO buildReal() {
        return new EncoderIOCANCoder(canID, conf);
    }
}
