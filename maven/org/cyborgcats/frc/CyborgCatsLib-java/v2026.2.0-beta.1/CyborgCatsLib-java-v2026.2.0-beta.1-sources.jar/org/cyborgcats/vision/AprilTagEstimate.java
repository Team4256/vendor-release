package org.cyborgcats.vision;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import edu.wpi.first.math.geometry.Pose3d;

import org.cyborgcats.jni.AprilTagEstimatorJNI;

/**
 * A resolved AprilTag pose estimate from a single native solve: the best (and, when ambiguous,
 * alternate) camera pose candidate, associated reprojection errors, and the tags that
 * contributed to it.
 *
 * @param estimatedPose1 best camera pose candidate
 * @param estimatedPose2 alternate camera pose candidate, present only when the solve was
 *     ambiguous (see {@link #from})
 * @param error1         reprojection error of {@code estimatedPose1}
 * @param error2         reprojection error of {@code estimatedPose2}, present only when
 *     {@code estimatedPose2} is
 * @param tagCount       number of tags that contributed to this estimate
 * @param tagArea        total on-screen area of contributing tags, as a fraction of the image area
 * @param targets        per-tag detail for every tag that contributed to this estimate
 * @param timestamp      capture timestamp of the frame this estimate was solved from
 */
public record AprilTagEstimate(
    Pose3d estimatedPose1,
    Optional<Pose3d> estimatedPose2,
    double error1,
    Optional<Double> error2,
    int tagCount,
    double tagArea,
    List<AprilTagTarget> targets,
    double timestamp
) {
  /**
   * Converts the raw JNI estimate into this higher-level record. {@code pose2}/{@code error2}
   * are only meaningful for single-tag ambiguity, signaled by the JNI side with a NaN
   * {@code error2}; that case becomes an empty {@link Optional} here.
   *
   * @param estimate  the raw JNI estimate to convert
   * @param timestamp capture timestamp of the frame this estimate was solved from, not
   *     produced by the native solve, so it's threaded in separately here
   * @return the converted, higher-level estimate
   */
  public static AprilTagEstimate from(AprilTagEstimatorJNI.AprilTagEstimate estimate, double timestamp) {
    boolean hasAmbiguity = !Double.isNaN(estimate.error2());
    return new AprilTagEstimate(
        estimate.pose1(),
        hasAmbiguity ? Optional.of(estimate.pose2()) : Optional.empty(),
        estimate.error1(),
        hasAmbiguity ? Optional.of(estimate.error2()) : Optional.empty(),
        estimate.tagCount(),
        estimate.tagArea(),
        estimate.targets().stream()
            .flatMap(target -> AprilTagTarget.from(target).stream())
            .collect(Collectors.toList()),
        timestamp
    );
  }

  /**
   * Ratio of {@link #error1} to {@link #error2}, a measure of how confidently
   * {@link #estimatedPose1} was preferred over {@link #estimatedPose2}. Close to 1 means both
   * candidates fit the observation almost equally well (ambiguous); close to 0 means
   * {@code estimatedPose1} fit far better. 0.0 when there was no second solution to compare
   * against, since a single-solution solve is unambiguous.
   *
   * @return the ambiguity ratio, in [0, 1]
   */
  public double ambiguity() {
    return error2.map(altError -> error1 / altError).orElse(0.0);
  }
}
