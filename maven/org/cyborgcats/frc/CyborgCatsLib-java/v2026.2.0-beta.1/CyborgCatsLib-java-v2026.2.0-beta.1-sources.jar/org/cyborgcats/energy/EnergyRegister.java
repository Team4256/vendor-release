package org.cyborgcats.energy;

import java.util.ArrayList;
import org.cyborgcats.energy.EnergyTracker.Energy;
import org.cyborgcats.subsystem.Subsystem;
import org.littletonrobotics.junction.Logger;

/**
 * Global registry that collects {@link EnergyTracker} instances, integrates each of them once per
 * loop iteration, and publishes the robot's combined power and energy draw to AdvantageKit.
 */
public class EnergyRegister extends Subsystem {

  private static final ArrayList<EnergyTracker> energyTrackers = new ArrayList<>();
  private static EnergyRegister instance = null;

  private double totalPower = 0;
  private double totalEnergy = 0;

  private EnergyRegister() {
    super();
  }

  /**
   * Lazily creates the singleton {@link EnergyRegister} instance, if one doesn't already exist,
   * so that it self-registers with {@link Subsystem} and starts receiving {@link #periodic()}
   * calls. Callers never need to construct one themselves.
   */
  private static void initialize() {
    if (instance == null) {
      instance = new EnergyRegister();
    }
  }

  /**
   * Registers an {@link EnergyTracker} to be integrated and logged every loop, initializing the
   * singleton registry instance on first use if necessary.
   *
   * @param energyTracker the tracker to register
   */
  public static void register(EnergyTracker energyTracker) {
    initialize();
    energyTrackers.add(energyTracker);
  }

  /**
   * Returns the combined instantaneous power draw of every registered device, as of the most
   * recent {@link #periodic()} call.
   *
   * @return total power draw in watts
   */
  public double getTotalPower() {
    return totalPower;
  }

  /**
   * Returns the combined energy consumed by every registered device over its lifetime, as of the
   * most recent {@link #periodic()} call.
   *
   * @return total energy consumed in joules
   */
  public double getTotalEnergy() {
    return totalEnergy;
  }

  /**
   * Integrates every registered {@link EnergyTracker}, then sums and logs their power and energy.
   * Called every robot loop iteration via {@link Subsystem#runPeriodic()}.
   */
  @Override
  public void periodic() {
    totalPower = 0;
    totalEnergy = 0;
    for (EnergyTracker tracker : energyTrackers) {
      Energy energy = tracker.update();
      totalPower += energy.power();
      totalEnergy += energy.totalEnergy();
    }
    Logger.recordOutput("Energy/TotalWatts", totalPower);
    Logger.recordOutput("Energy/TotalJoules", totalEnergy);
  }
}
