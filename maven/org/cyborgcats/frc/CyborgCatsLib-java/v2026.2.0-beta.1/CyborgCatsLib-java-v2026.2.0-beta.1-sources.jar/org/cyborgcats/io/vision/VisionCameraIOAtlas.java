package org.cyborgcats.io.vision;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

import org.cyborgcats.vision.AprilTagEstimate;
import org.cyborgcats.vision.AprilTagEstimator;
import org.cyborgcats.vision.AtlasVisionTarget;
import org.cyborgcats.vision.CameraMatrix;
import org.cyborgcats.vision.CameraResolution;
import org.cyborgcats.vision.DistortionCoefficients;
import org.cyborgcats.vision.VisionMeasurment;
import org.cyborgcats.vision.VisionResult;
import org.cyborgcats.vision.VisionStdDevs;
import org.cyborgcats.vision.AtlasVisionTargets;

import edu.wpi.first.math.Matrix;
import edu.wpi.first.math.geometry.Pose3d;
import edu.wpi.first.math.geometry.Transform3d;
import edu.wpi.first.math.numbers.N1;
import edu.wpi.first.math.numbers.N3;
import edu.wpi.first.networktables.NetworkTableInstance;
import edu.wpi.first.networktables.StructSubscriber;


/**
 * Vision camera IO implementation for the Atlas coprocessor. Atlas only detects AprilTag corner
 * quads and streams them over NetworkTables as a {@code VisionTargets} struct (see
 * 4256-2026-Atlas's {@code Camera.cpp}/{@code VisionTargets.h}); pose estimation happens here via
 * {@link AprilTagEstimator}, the same native solve {@link VisionCameraIOSim} uses.
 */
public class VisionCameraIOAtlas implements VisionCameraIO {
  private static final AtlasVisionTargets kNoTargets =
      new AtlasVisionTargets(0.0, 0, new AtlasVisionTarget[0]);

  private final StructSubscriber<AtlasVisionTargets> targetsSubscriber;
  private final AprilTagEstimator estimator;
  private final List<AprilTagEstimate> results = new ArrayList<>();
  private final VisionStdDevs singleTagDevs;
  private final VisionStdDevs multiTagDevs;
  private final Supplier<Transform3d> robotToCamera;
  private final double ambiguityThreshold;

  /**
   * @param name          camera name; must match the table Atlas publishes under (its
   *                      {@code friendlyName})
   * @param matrix        camera intrinsics
   * @param distCoeffs    lens distortion coefficients
   * @param resolution    image resolution
   * @param singleTagDevs standard deviations to use when a single tag contributes to an estimate
   * @param multiTagDevs  standard deviations to use when multiple tags contribute to an estimate
   * @param robotToCamera supplier returning the transform from robot origin to camera lens
   * @param ambiguityThreshold minimum {@link AprilTagEstimate#ambiguity()} at or above which a
   *                           single-tag estimate is discarded as too ambiguous to trust; ignored
   *                           for multi-tag estimates
   */
  public VisionCameraIOAtlas(
      String name,
      CameraMatrix matrix,
      DistortionCoefficients distCoeffs,
      CameraResolution resolution,
      VisionStdDevs singleTagDevs,
      VisionStdDevs multiTagDevs,
      Supplier<Transform3d> robotToCamera,
      double ambiguityThreshold
  ) {
    var table = NetworkTableInstance.getDefault().getTable(name);
    targetsSubscriber =
        table.getStructTopic("VisionTargets", AtlasVisionTargets.struct).subscribe(kNoTargets);

    estimator = new AprilTagEstimator(matrix, distCoeffs, resolution);
    this.singleTagDevs = singleTagDevs;
    this.multiTagDevs = multiTagDevs;
    this.robotToCamera = robotToCamera;
    this.ambiguityThreshold = ambiguityThreshold;
  }

  @Override
  public void updateInputs(VisionCameraInputs inputs) {
    inputs.connected = targetsSubscriber.getTopic().exists();

    AtlasVisionTargets[] frames = targetsSubscriber.readQueueValues();
    if (frames.length == 0) return;

    for (AtlasVisionTargets frame : frames) {
      var detections = frame.detections();
      inputs.ids = detections.ids();
      inputs.corners = detections.corners();
      inputs.timestamp = frame.timestamp();

      estimator.getTagEstimatePNP(detections, frame.timestamp()).ifPresent(estimate -> {
        results.add(estimate);

        inputs.estimate = estimate.estimatedPose1();
        inputs.estimatedRobotPose = estimate.estimatedPose1().transformBy(robotToCamera.get().inverse());
        inputs.reprojectionError = estimate.error1();
        inputs.ambiguity = estimate.ambiguity();
        inputs.tagCount = estimate.tagCount();
        inputs.tagArea = estimate.tagArea();
        inputs.tagTargets = estimate.targets().stream()
            .map(target -> target.aprilTag().tagPose())
            .toArray(Pose3d[]::new);
      });
    }
  }

  @Override
  public AprilTagEstimate[] getAllUnreadVisionEstimates() {
    AprilTagEstimate[] unread = results.toArray(new AprilTagEstimate[0]);
    results.clear();
    return unread;
  }

  @Override
  public VisionResult[] getVisionResults() {
      var estimates = getAllUnreadVisionEstimates();
      List<VisionResult> results = new ArrayList<>();
      for (AprilTagEstimate estimate : estimates) {
        Pose3d robotPose = estimate.estimatedPose1().transformBy(robotToCamera.get().inverse());
        double timestamp = estimate.timestamp();
        double ambiguity = estimate.ambiguity();
        Matrix<N3, N1> stdDevs;
        int tagCount = estimate.tagCount();
        double ta = estimate.tagArea();
        if (tagCount == 1) {
          if (ambiguity >= ambiguityThreshold) {
            continue;
          }
          stdDevs = singleTagDevs.get(ta);
        } else {
          stdDevs = multiTagDevs.get(ta);
        }
        VisionMeasurment measurment = new VisionMeasurment(robotPose.toPose2d(), timestamp, stdDevs);
        VisionResult result = new VisionResult(measurment, tagCount);
        results.add(result);
      }
      return results.toArray(new VisionResult[0]);
  }
}
