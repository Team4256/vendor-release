package org.cyborgcats.ssm;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.cyborgcats.ssm.Step.CheckedRunnable;
import org.cyborgcats.subsystem.ActionSubsystem;

/**
 * Represents a named machine state composed of a single {@link Step}.
 * States are managed by the {@link Scheduler} and may chain to cleanup or finish states upon
 * interruption or natural completion, respectively.
 */
public class State {

  /** the step that runs when the state is active */
  private final Step step;
  /** list of action subsystems the state owns */
  private final ArrayList<ActionSubsystem> requirements = new ArrayList<>();
  /** telemetry to log state data */
  private final Telemetry telemetry;
  /** Whether every step has run to completion. */
  protected boolean isFinished = false;

  /** Whether the first step has begun executing. */
  protected boolean hasStarted = false;

  /** State scheduled when this one is interrupted, if any. */
  protected Optional<State> onCleanup = Optional.empty();

  /** State scheduled when this one finishes naturally, if any. */
  protected Optional<State> onFinish = Optional.empty();

  /** Whether the scheduler may interrupt this state to run another requiring the same subsystems. */
  protected boolean interruptible = true;

  /** Action run when this state is interrupted, if any. */
  protected Optional<Runnable> onInterrupt = Optional.empty();

  /** Action run when this state ends, whether interrupted or finished, if any. */
  protected Optional<Runnable> onEnd = Optional.empty();

  /** Whether this state keeps running while the robot is disabled instead of being ended. */
  protected boolean ignoreDisable = false;

  /** the name of this state, used for telemetry and logging */
  private String name = "Unnamed";

  public State(CheckedRunnable runnable) {
    this.step = Step.run(runnable);
    telemetry = new Telemetry(this);
  }


  /**
   * Sets the state to schedule when this state is interrupted.
   *
   * @param state the cleanup state to run on interruption
   * @return this state for chaining
   */
  public State withCleanup(State state) {
    this.onCleanup = Optional.of(state);
    return this;
  }

  /**
   * Sets the state to schedule when this state finishes naturally.
   *
   * @param state the finish state to run on natural completion
   * @return this state for chaining
   */
  public State withFinish(State state) {
    this.onFinish = Optional.of(state);
    return this;
  }

  /**
   * Controls whether this state can be interrupted by the scheduler when a conflicting state
   * is scheduled.
   *
   * @param interruptible {@code true} to allow interruption, {@code false} to block it
   * @return this state for chaining
   */
  public State isInterruptible(boolean interruptible) {
    this.interruptible = interruptible;
    return this;
  }

  /**
   * Assigns a human-readable name to this state used in telemetry logging.
   *
   * @param name the state name
   * @return this state for chaining
   */
  public State withName(String name) {
    this.name = name;
    return this;
  }

  /**
   * Declares the subsystems this state requires, enabling the scheduler to detect conflicts with
   * other states. May be called more than once to accumulate requirements.
   *
   * @param requirements the subsystems to claim
   * @return this state for chaining
   */
  public State withRequirements(ActionSubsystem... requirements) {
    this.requirements.addAll(List.of(requirements));
    return this;
  }

  /**
   * Sets whether this state keeps running while the robot is disabled.
   *
   * <p>By default a state is ended by the {@link Scheduler} as soon as the robot is disabled,
   * exactly as if it had been interrupted. Setting this to {@code true} exempts the state, so it
   * continues to advance every loop regardless of enable status.
   *
   * @param ignoreDisable {@code true} to keep running while disabled, {@code false} to be ended
   * @return this state for chaining
   */
  public State withIgnoreDisable(boolean ignoreDisable) {
    this.ignoreDisable = ignoreDisable;
    return this;
  }

  /**
   * Registers a callback to invoke when this state is interrupted.
   *
   * @param callback the runnable to invoke on interruption
   */
  public void onInterrupt(Runnable callback) {
    this.onInterrupt = Optional.of(callback);
  }

  /**
   * Returns the optional interrupt callback.
   *
   * @return an {@link Optional} containing the interrupt callback, or empty if none was set
   */
  public Optional<Runnable> getInterrupt() {
    return onInterrupt;
  }

  /**
   * Registers a callback to invoke when this state's step completes on its own.
   * This callback does <em>not</em> run when the state is interrupted by a conflicting state, nor
   * when it is ended explicitly via {@link Scheduler#end(State)} or {@link Scheduler#endAll()}.
   * To react to interruption, use {@link #onInterrupt(Runnable)}.
   *
   * @param callback the runnable to invoke on natural completion
   */
  public void onEnd(Runnable callback) {
    this.onEnd = Optional.of(callback);
  }

  /**
   * Returns the optional natural-completion callback.
   *
   * @return an {@link Optional} containing the callback, or empty if none was set
   */
  public Optional<Runnable> getOnEnd() {
    return onEnd;
  }

  /**
   * Returns whether this state keeps running while the robot is disabled.
   *
   * @return {@code true} if the state is exempt from being ended on disable
   */
  public boolean getIgnoreDisable() {
    return ignoreDisable;
  }

  /**
   * Advances this state by one loop iteration, starting or resuming its step.
   * Starts telemetry on the first call and marks the state finished once the step completes.
   */
  public void run() {
    if (!hasStarted) {
      telemetry.start();
      hasStarted = true;
    }

    if (isFinished) {
      return;
    }

    if (!step.isStarted()) {
      step.start();
    } else {
      step.resume();
    }

    // logged after advancing so duration and requirements reflect this loop, not the previous one
    telemetry.log();

    if (step.isFinished()) {
      isFinished = true;
    }
  }

  /**
   * Returns whether this state's step has completed.
   *
   * @return {@code true} if the state has finished
   */
  public boolean isFinished() {
    return isFinished;
  }

  /**
   * Returns whether this state may be interrupted by a conflicting state.
   *
   * @return {@code true} if the state is interruptible
   */
  public boolean isInterruptible() {
    return interruptible;
  }

  /**
   * Returns the human-readable name of this state.
   *
   * @return the state name
   */
  public String getName() {
    return name;
  }

  /**
   * Ends the currently executing step and stops telemetry.
   */
  public void end() {
    telemetry.stop();
    step.end();
  }

  /**
   * Returns the optional cleanup state scheduled when this state is interrupted.
   *
   * @return an {@link Optional} containing the cleanup state, or empty if none was set
   */
  public Optional<State> getCleanup() {
    return onCleanup;
  }

  /**
   * Returns the optional finish state scheduled when this state completes naturally.
   *
   * @return an {@link Optional} containing the finish state, or empty if none was set
   */
  public Optional<State> getFinish() {
    return onFinish;
  }

  /**
   * Resets this state so it can be scheduled and run again from the beginning.
   */
  public void reset() {
    isFinished = false;
    hasStarted = false;
    step.reset();
  }

  /**
   * Returns the list of subsystems required by this state.
   *
   * @return the requirement list declared via {@link #withRequirements}
   */
  public ArrayList<ActionSubsystem> getRequirements() {
    return requirements;
  }
}
