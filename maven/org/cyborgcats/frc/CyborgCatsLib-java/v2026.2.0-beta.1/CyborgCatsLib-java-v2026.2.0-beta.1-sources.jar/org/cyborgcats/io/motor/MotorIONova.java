// package org.cyborgcats.io.motor;

// import org.cyborgcats.component.Setpoint;

// import com.thrifty.core.ThriftyStatusCode;
// import com.thrifty.core.Motor.MotorType;
// import com.thrifty.nova.Nova;
// import com.thrifty.nova.NovaConfigBatch;
// import com.thrifty.nova.NovaControl;
// import com.thrifty.nova.NovaStatusView;

// import edu.wpi.first.wpilibj.Alert;
// import edu.wpi.first.wpilibj.Alert.AlertType;
// import edu.wpi.first.wpilibj.DriverStation;

// public class MotorIONova implements MotorIO {
//     private final Nova motor;
//     private final String name;

//     private double setpoint = 0;
//     private Setpoint.Mode mode = Setpoint.Mode.Neutral;

//     public MotorIONova(String name, int canID, int busID, MotorType type, NovaConfigBatch conf) {
//         this.name = name;
//         motor = new Nova(busID, canID, type);
//         ThriftyStatusCode code = motor.configure(conf);
//         if (!code.isOk()) {
//             @SuppressWarnings("resource")
//             Alert alert = new Alert(
//                 "Config Error: " + name + code.name(), AlertType.kWarning);
//             alert.set(true);
//         }
//     }

//     @Override
//     public void applyNetural() {
//         DriverStation.reportError("Netural Not Supported On Nova", false);
//     }

//     @Override
//     public void applyVoltageSetpoint(double voltage) {
//         setpoint = voltage;
//         mode = Setpoint.Mode.Voltage;
//         motor.control(NovaControl.voltage(voltage));
//     }

//     @Override
//     public void applyDutyCycleSetpoint(double dutyCycle) {
//         setpoint = dutyCycle;
//         mode = Setpoint.Mode.DutyCycle;
//         motor.control(NovaControl.percent(dutyCycle));
//     }

//     @Override
//     public void applyVelocitySetpoint(double velocity) {
//         setpoint = velocity;
//         mode = Setpoint.Mode.Velocity;
//         motor.control(NovaControl.voltageVelocity(velocity));
//     }

//     @Override
//     public void applyPositionSetpoint(double position) {
//         setpoint = position;
//         mode = Setpoint.Mode.Position;
//         motor.control(NovaControl.voltagePosition(position));
//     }

//     @Override
//     public void applyPositionMotionProfile(double position) {
//         DriverStation.reportError("Position Motion Profile Not Supported On Nova", false);
//     }

//     @Override
//     public void applyVelocityTorqueCurrent(double velocity) {
//         DriverStation.reportError("Velocity Torque Current Not Supported On Nova", false);
//     }

//     @Override
//     public void applyVelocityMotionProfile(double velocity) {
//         DriverStation.reportError("Velocity Motion Profile Not Supported On Nova", false);
//     }

//     @Override
//     public void setCurrentPosition(double position) {
//        DriverStation.reportError("Position Setting Not Supported On Nova", false);
//     }

//     @Override
//     public void updateInputs(MotorInputs inputs) {
//         NovaStatusView statusView = motor.status();
//         inputs.motorVoltage = statusView.getVoltage();
//         inputs.supplyVoltage = statusView.getAppliedVoltage();
//         inputs.statorCurrent = statusView.getCurrentStator();
//         inputs.supplyCurrent = statusView.getCurrentSupply();
//         inputs.position = statusView.getPositionInternal();
//         inputs.velocity = statusView.getVelocityInternal();
//         inputs.temperature = statusView.getTemperature();
//         inputs.connected = statusView.getDeviceStatus().isOk();
//         inputs.setpoint = setpoint;
//         inputs.mode = mode;
//     }

//     @Override
//     public String getName() {
//         return name;
//     }
    
// }
