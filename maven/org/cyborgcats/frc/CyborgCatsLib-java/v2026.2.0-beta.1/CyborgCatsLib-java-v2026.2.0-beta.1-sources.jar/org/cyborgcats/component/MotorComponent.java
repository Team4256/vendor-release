package org.cyborgcats.component;

import org.cyborgcats.io.motor.MotorIO;
import org.cyborgcats.io.motor.MotorIOConfiguration;
import org.cyborgcats.io.motor.MotorInputsAutoLogged;
import org.cyborgcats.ssm.State;
import org.littletonrobotics.junction.Logger;

/**
 * Base component for any mechanism driven by a motor, providing setpoint application and input
 * logging for a leader motor and any number of followers.
 *
 * <p>A follower whose {@link MotorIO#isFollower()} reports true is already following the leader
 * at the vendor level, so {@link #applySetpoint(Setpoint)} leaves it alone; any other follower is
 * instead driven by applying the same control request as the leader.
 */
public class MotorComponent implements Component {

  /** Unique name used as the AdvantageKit logging key under "mechanisms/". */
  protected final String name;

  /** Hardware interface for the leader motor. */
  protected final MotorIO leader;

  /** Hardware interfaces driven with the same control request as the leader; may be empty. */
  protected final MotorIO[] followers;

  /** Most recently logged inputs read from the leader. */
  protected final MotorInputsAutoLogged leaderInputs;

  /** Most recently logged inputs read from each follower, parallel to {@link #followers}. */
  protected final MotorInputsAutoLogged[] followerInputs;

  /** Setpoint most recently passed to {@link #applySetpoint(Setpoint)}. */
  protected Setpoint setpoint = Setpoint.neutral();

  /**
   * Constructs a MotorComponent.
   *
   * @param name      unique name used as the AdvantageKit logging key under "mechanisms/"
   * @param leader    configuration used to build the hardware interface for this motor
   * @param followers configurations for hardware interfaces driven with the same control request as
   *                  the leader; may be omitted for a single-motor mechanism
   */
  public MotorComponent(
    String name,
    MotorIOConfiguration leader,
    MotorIOConfiguration... followers
  ) {
    this.name = name;

    this.leader = leader.build();
    this.followers = new MotorIO[followers.length];

    leaderInputs = new MotorInputsAutoLogged();
    followerInputs = new MotorInputsAutoLogged[followers.length];
    for (int i = 0; i < followers.length; ++i) {
      this.followers[i] = followers[i].build();
      followerInputs[i] = new MotorInputsAutoLogged();
    }
  }

  /**
   * Stores and immediately applies a new setpoint to the leader and to every follower that isn't
   * already following it at the vendor level (see {@link MotorIO#isFollower()}).
   *
   * @param setpoint the setpoint to apply
   */
  public void applySetpoint(Setpoint setpoint) {
    this.setpoint = setpoint;
    setpoint.apply(leader);
    for (int i = 0; i < followers.length; ++i) {
      if (!followers[i].isFollower()) {
        setpoint.apply(followers[i]);
      }
    }
  }


  /**
   * Creates a one-shot {@link org.cyborgcats.ssm.State} that applies the given setpoint when scheduled.
   *
   * @param setpoint the setpoint to apply when the state runs
   * @return the newly created state
   */
  public State applySetpointState(Setpoint setpoint) {
    return new State(() -> applySetpoint(setpoint))
      .withName("Apply Setpoint" + name)
      .isInterruptible(true);
  }

  /**
   * Refreshes and returns the leader's inputs, logging the leader and every follower as a side
   * effect.
   *
   * @return the logged motor inputs object
   */
  public MotorIO.MotorInputs getInputs() {
    updateInputs();
    return leaderInputs;
  }

  /**
   * Reads the latest inputs from the leader and every follower, then publishes each of them to
   * AdvantageKit under that motor's {@link MotorIO#getName()}.
   */
  public void updateInputs() {
    leader.updateInputs(leaderInputs);
    for (int i = 0; i < followers.length; ++i) {
      followers[i].updateInputs(followerInputs[i]);
    }
    Logger.processInputs(
      "Components/" + name + "/" + leader.getName(),
      leaderInputs
    );
    for (int i = 0; i < followers.length; ++i) {
      Logger.processInputs(
        "Components/" + name + "/" + followers[i].getName(),
        followerInputs[i]
      );
    }
  }

  /**
   * resets the leader motor and all the followers position to a new one
   * @param position new position to set the motors to
   */
  public void setCurrentPosition(double position) {
    leader.setCurrentPosition(position);
    for (int i = 0; i < followers.length; ++i) {
      followers[i].setCurrentPosition(position);
    }
    updateInputs();
  }

  /**
   * returns the current setpoint applied to the motor component
   * @return the curretn setpoint
   */
  public Setpoint getCurrentSetpoint() {
    return setpoint;
  }
}
