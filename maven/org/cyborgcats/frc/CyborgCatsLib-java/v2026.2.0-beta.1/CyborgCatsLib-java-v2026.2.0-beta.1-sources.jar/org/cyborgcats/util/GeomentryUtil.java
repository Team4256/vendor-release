package org.cyborgcats.util;

import edu.wpi.first.math.geometry.Pose2d;
import edu.wpi.first.math.geometry.Pose3d;
import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.math.geometry.Transform2d;
import edu.wpi.first.math.geometry.Transform3d;

/**
 * Utility methods for converting between WPILib geometry types
 * (rotations, poses, and transforms).
 */
public class GeomentryUtil {
  /**
   * variable representing the degrees per one rotation
   */
  private final static double degreesPerRotation = 360.0;

  /**
   * variable representing the radians per one rotation
   */
  private final static double radiansPerRotation = 2 * Math.PI;

  /**
   * returns the rotations in a rotation2d using {@link GeomentryUtil#degreesPerRotation}
   * @param rotation a rotation2d
   * @return returns a rotation between 0 and 1
   */
  public static double toRotations(Rotation2d rotation) {
    return rotation.getDegrees() / degreesPerRotation;
  }

  /**
   * returns the rotations in a double in the units of degrees using {@link GeomentryUtil#degreesPerRotation}
   * @param degrees degrees
   * @return returns a rotation between 0 and 1
   */
  public static double degreesToRotations(double degrees) {
    return degrees / degreesPerRotation;
  }

  /**
   * returns the rotations in a double in the units of radians using {@link GeomentryUtil#radiansPerRotation}
   * @param radians radians
   * @return returns a rotation between 0 and 1
   */
  public static double radiansToRotaions(double radians) {
    return radians /  radiansPerRotation;
  }

  /**
   * converts a transform2d into a pose2d with the same translation and rotation
   * @param transform a transform2d
   * @return the equivalent pose2d
   */
  public static Pose2d toPose2d(Transform2d transform) {
    return new Pose2d(transform.getTranslation(), transform.getRotation());
  }

  /**
   * converts a transform3d into a pose3d with the same translation and rotation
   * @param transform a transform3d
   * @return the equivalent pose3d
   */
  public static Pose3d toPose3d(Transform3d transform) {
    return new Pose3d(transform.getTranslation(), transform.getRotation());
  }

  /**
   * converts a pose2d into a transform2d with the same translation and rotation
   * @param pose a pose2d
   * @return the equivalent transform2d
   */
  public static Transform2d toTransform2d(Pose2d pose) {
    return new Transform2d(pose.getTranslation(), pose.getRotation());
  }

  /**
   * converts a pose3d into a transform3d with the same translation and rotation
   * @param pose a pose3d
   * @return the equivalent transform3d
   */
  public static Transform3d toTransform3d(Pose3d pose) {
    return new Transform3d(pose.getTranslation(), pose.getRotation());
  }
}
