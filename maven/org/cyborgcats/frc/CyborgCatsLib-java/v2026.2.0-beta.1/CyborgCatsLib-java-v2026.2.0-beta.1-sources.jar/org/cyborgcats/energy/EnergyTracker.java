package org.cyborgcats.energy;

import edu.wpi.first.wpilibj.Timer;

/**
 * Integrates a single {@link EnergyIO} device's power draw over time to track the total energy
 * it has consumed.
 *
 * <p>Constructing a tracker registers it with {@link EnergyRegister}, which calls
 * {@link #update()} once per loop iteration. Consumers should read the most recent sample with
 * {@link #getEnergy()} rather than calling {@link #update()} themselves, so that the device is
 * integrated exactly once per loop.
 */
public class EnergyTracker {

  private final EnergyIO io;
  private double totalEnergy;
  private double currentPower;
  private double lastTime = 0;
  private boolean hasSample = false;

  /**
   * A single energy sample for one device.
   *
   * @param power       instantaneous power draw at the time of the sample, in watts
   * @param totalEnergy energy consumed over the device's whole lifetime, in joules
   */
  public record Energy(double power, double totalEnergy) {
  }

  /**
   * Constructs an EnergyTracker for a device and registers it with {@link EnergyRegister} so it
   * is integrated every loop iteration.
   *
   * <p>Because registration hands this tracker to a global registry that immediately begins
   * sampling {@code io}, callers must not construct a tracker until the device it wraps is fully
   * initialized.
   *
   * @param io the device whose energy consumption should be tracked
   */
  public EnergyTracker(EnergyIO io) {
    this.io = io;
    lastTime = Timer.getFPGATimestamp();
    EnergyRegister.register(this);
  }

  /**
   * Samples the device's present power draw and integrates it over the time elapsed since the
   * previous call, adding the result to the running total.
   *
   * <p>Integration is trapezoidal, averaging this sample's power with the previous one, which is
   * considerably more accurate than holding one sample across the whole interval when current
   * swings within a loop iteration. The very first call only establishes the baseline power and
   * timestamp: with no previous sample to average against, and an arbitrary gap between
   * construction and the first loop iteration, there is no interval it could integrate.
   *
   * @return the sample just taken
   */
  public Energy update() {
    double now = Timer.getFPGATimestamp();
    double dt = now - lastTime;
    double previousPower = currentPower;
    currentPower = io.getSupplyCurrent() * io.getSupplyVoltage();

    if (hasSample) {
      totalEnergy += (currentPower + previousPower) / 2.0 * dt;
    } else {
      hasSample = true;
    }

    lastTime = now;
    return new Energy(currentPower, totalEnergy);
  }

  /**
   * Returns the most recent sample without re-reading the device or advancing the integration.
   *
   * @return the sample taken by the last {@link #update()} call
   */
  public Energy getEnergy() {
    return new Energy(currentPower, totalEnergy);
  }
}
