package org.cyborgcats.io.vision;

import java.util.function.Supplier;

import org.cyborgcats.vision.CameraMatrix;
import org.cyborgcats.vision.CameraResolution;
import org.cyborgcats.vision.DistortionCoefficients;
import org.cyborgcats.vision.VisionStdDevs;

import edu.wpi.first.math.geometry.Pose3d;
import edu.wpi.first.math.geometry.Transform3d;

/**
 * {@link VisionCameraIOConfiguration} for an Atlas-based vision camera. Builds either a real
 * {@link VisionCameraIOAtlas} or, in simulation, a {@link VisionCameraIOSim} using the same
 * physical camera parameters.
 */
public class VisionCameraIOAtlasConfiguration implements VisionCameraIOConfiguration{

    private final String name;
    private final CameraMatrix matrix;
    private final DistortionCoefficients distCoeffs;
    private final CameraResolution resolution;
    private final VisionStdDevs singleTagDevs;
    private final VisionStdDevs multiTagDevs;
    private final Supplier<Transform3d> robotToCamera;
    private final Supplier<Pose3d> simRobotPose;
    private final double ambiguityThreshold;

    /**
     * @param name          camera name; must match the table Atlas publishes under (its
     *                      {@code friendlyName}) and the PhotonVision sim camera name
     * @param matrix        camera intrinsics
     * @param distCoeffs    lens distortion coefficients
     * @param resolution    image resolution
     * @param singleTagDevs standard deviations to use when a single tag contributes to an estimate
     * @param multiTagDevs  standard deviations to use when multiple tags contribute to an estimate
     * @param robotToCamera supplier returning the transform from robot origin to camera lens
     * @param simRobotPose  supplier returning the current simulated robot pose
     * @param ambiguityThreshold minimum {@link org.cyborgcats.vision.AprilTagEstimate#ambiguity()}
     *                           at or above which a single-tag estimate is discarded as too
     *                           ambiguous to trust; ignored for multi-tag estimates
     */
    public VisionCameraIOAtlasConfiguration(
        String name,
        CameraMatrix matrix,
        DistortionCoefficients distCoeffs,
        CameraResolution resolution,
        VisionStdDevs singleTagDevs,
        VisionStdDevs multiTagDevs,
        Supplier<Transform3d> robotToCamera,
        Supplier<Pose3d> simRobotPose,
        double ambiguityThreshold
    ) {
        this.name = name;
        this.matrix = matrix;
        this.distCoeffs = distCoeffs;
        this.resolution = resolution;
        this.singleTagDevs = singleTagDevs;
        this.multiTagDevs = multiTagDevs;
        this.robotToCamera = robotToCamera;
        this.simRobotPose = simRobotPose;
        this.ambiguityThreshold = ambiguityThreshold;
    }

    @Override
    public VisionCameraIO buildReal() {
        return new VisionCameraIOAtlas(name, matrix, distCoeffs, resolution, singleTagDevs, multiTagDevs, robotToCamera, ambiguityThreshold);
    }

    @Override
    public VisionCameraIO buildSim() {
        return new VisionCameraIOSim(name, matrix, distCoeffs, resolution, singleTagDevs, multiTagDevs, robotToCamera, simRobotPose, ambiguityThreshold);
    }
    
}
