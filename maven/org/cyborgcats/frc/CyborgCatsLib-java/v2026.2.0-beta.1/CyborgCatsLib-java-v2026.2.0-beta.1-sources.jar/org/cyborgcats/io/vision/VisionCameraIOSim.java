package org.cyborgcats.io.vision;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

import org.cyborgcats.vision.AprilTagDetection;
import org.cyborgcats.vision.AprilTagDetections;
import org.cyborgcats.vision.AprilTagEstimate;
import org.cyborgcats.vision.AprilTagEstimator;
import org.cyborgcats.vision.AprilTagField;
import org.cyborgcats.vision.CameraMatrix;
import org.cyborgcats.vision.CameraResolution;
import org.cyborgcats.vision.DistortionCoefficients;
import org.cyborgcats.vision.VisionMeasurment;
import org.cyborgcats.vision.VisionResult;
import org.cyborgcats.vision.VisionStdDevs;
import org.opencv.core.Point;
import org.photonvision.PhotonCamera;
import org.photonvision.simulation.PhotonCameraSim;
import org.photonvision.simulation.SimCameraProperties;
import org.photonvision.simulation.VisionSystemSim;
import org.photonvision.targeting.PhotonTrackedTarget;
import org.photonvision.targeting.TargetCorner;

import edu.wpi.first.math.MatBuilder;
import edu.wpi.first.math.Matrix;
import edu.wpi.first.math.Nat;
import edu.wpi.first.math.geometry.Pose3d;
import edu.wpi.first.math.geometry.Transform3d;
import edu.wpi.first.math.numbers.N1;
import edu.wpi.first.math.numbers.N3;

/**
 * Vision camera IO implementation using PhotonVision simulation.
 */
public class VisionCameraIOSim implements VisionCameraIO {
  private static final VisionSystemSim visionSim = new VisionSystemSim("main");
  private static boolean tagsLoaded = false;
  private final PhotonCamera photonCamera;
  private final VisionStdDevs singleTagDevs;
  private final VisionStdDevs multiTagDevs;
  private final Supplier<Transform3d> robotToCamera;
  private final Supplier<Pose3d> robotPose;
  private final AprilTagEstimator estimator;
  private final List<AprilTagEstimate> results = new ArrayList<>();
  private final double ambiguityThreshold;

  /**
   * Constructs a VisionCameraIOSim, setting up a PhotonVision simulation camera with the
   * provided intrinsics and attaching it to the shared {@link VisionSystemSim}.
   *
   * @param name          unique camera name (must match the PhotonVision camera name)
   * @param matrix        camera intrinsics
   * @param distCoeffs    lens distortion coefficients
   * @param resolution    image resolution
   * @param singleTagDevs standard deviations to use when a single tag contributes to an estimate
   * @param multiTagDevs  standard deviations to use when multiple tags contribute to an estimate
   * @param robotToCamera supplier returning the transform from robot origin to camera lens
   * @param robotPose     supplier returning the current simulated robot pose
   * @param ambiguityThreshold minimum {@link AprilTagEstimate#ambiguity()} at or above which a
   *                           single-tag estimate is discarded as too ambiguous to trust; ignored
   *                           for multi-tag estimates
   */
  public VisionCameraIOSim(
    String name,
    CameraMatrix matrix,
    DistortionCoefficients distCoeffs,
    CameraResolution resolution,
    VisionStdDevs singleTagDevs,
    VisionStdDevs multiTagDevs,
    Supplier<Transform3d> robotToCamera,
    Supplier<Pose3d> robotPose,
    double ambiguityThreshold
  ) {
    this.robotToCamera = robotToCamera;
    this.robotPose = robotPose;
    this.singleTagDevs = singleTagDevs;
    this.multiTagDevs = multiTagDevs;
    this.ambiguityThreshold = ambiguityThreshold;

    photonCamera = new PhotonCamera(name);

    var camProps = new SimCameraProperties();
    camProps.setCalibration(
        resolution.width(), resolution.height(),
        MatBuilder.fill(Nat.N3(), Nat.N3(), matrix.toArray()),
        MatBuilder.fill(Nat.N8(), Nat.N1(), distCoeffs.toArray())
    );
    camProps.setCalibError(0.0, 0.0);
    camProps.setFPS(60.0);
    camProps.setAvgLatencyMs(0.0);
    camProps.setLatencyStdDevMs(0.0);

    var cameraSim = new PhotonCameraSim(photonCamera, camProps);
    cameraSim.enableRawStream(true);
    cameraSim.enableProcessedStream(true);
    cameraSim.enableDrawWireframe(true);

    visionSim.addCamera(cameraSim, robotToCamera.get());

    if (!tagsLoaded) {
      var layout = AprilTagField.getInstance().getLayout();
      visionSim.addAprilTags(layout);
      tagsLoaded = true;
    }

    estimator = new AprilTagEstimator(matrix, distCoeffs, resolution);
  }

  @Override
  public void updateInputs(VisionCameraInputs inputs) {
    inputs.connected = photonCamera.isConnected();
    visionSim.update(robotPose.get().toPose2d());

    var photonResults = photonCamera.getAllUnreadResults();
    if (photonResults.isEmpty()) return;

    for (var result : photonResults) {
      if (!result.hasTargets()) continue;
      List<AprilTagDetection> detectionList = new ArrayList<>();
      for (PhotonTrackedTarget target : result.getTargets()) {
        List<Point> corners = new ArrayList<>(AprilTagDetection.pointsPerTag);
        for (TargetCorner corner : target.getDetectedCorners()) {
          corners.add(new Point(corner.x, corner.y));
        }
        detectionList.add(new AprilTagDetection(target.getFiducialId(), corners));
      }

      var detections = new AprilTagDetections(detectionList);
      inputs.ids = detections.ids();
      inputs.corners = detections.corners();
      inputs.timestamp = result.getTimestampSeconds();

      estimator.getTagEstimatePNP(detections, result.getTimestampSeconds()).ifPresent(estimate -> {
        results.add(estimate);

        inputs.estimate = estimate.estimatedPose1();
        inputs.estimatedRobotPose = estimate.estimatedPose1().transformBy(robotToCamera.get().inverse());
        inputs.reprojectionError = estimate.error1();
        inputs.ambiguity = estimate.ambiguity();
        inputs.tagCount = estimate.tagCount();
        inputs.tagArea = estimate.tagArea();
        inputs.tagTargets = estimate.targets().stream()
            .map(target -> target.aprilTag().tagPose())
            .toArray(Pose3d[]::new);
      });
    }
  }

  @Override
  public AprilTagEstimate[] getAllUnreadVisionEstimates() {
    AprilTagEstimate[] unread = results.toArray(new AprilTagEstimate[0]);
    results.clear();
    return unread;
  }

  @Override
  public VisionResult[] getVisionResults() {
      var estimates = getAllUnreadVisionEstimates();
      List<VisionResult> results = new ArrayList<>();
      for (AprilTagEstimate estimate : estimates) {
        Pose3d robotPose = estimate.estimatedPose1().transformBy(robotToCamera.get().inverse());
        double timestamp = estimate.timestamp();
        Matrix<N3, N1> stdDevs;
        int tagCount = estimate.tagCount();
        double ta = estimate.tagArea();
        double ambiguity = estimate.ambiguity();
        if (tagCount == 1) {
          if (ambiguity >= ambiguityThreshold) {
            continue;
          }
          stdDevs = singleTagDevs.get(ta);
        } else {
          stdDevs = multiTagDevs.get(ta);
        }
        VisionMeasurment measurment = new VisionMeasurment(robotPose.toPose2d(), timestamp, stdDevs);
        VisionResult result = new VisionResult(measurment, tagCount);
        results.add(result);
      }
      return results.toArray(new VisionResult[0]);
  }
}
