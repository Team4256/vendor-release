package org.cyborgcats.vision;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import edu.wpi.first.apriltag.AprilTagFieldLayout;
import edu.wpi.first.apriltag.AprilTagFields;

/**
 * Global holder for the game's {@link AprilTagFieldLayout}. Robot code must call
 * {@link #initialize(AprilTagFieldLayout)} once, early in startup (e.g. from {@code RobotContainer}'s
 * constructor), before constructing anything that reads the field layout &mdash; in particular
 * {@link AprilTagEstimator} and {@link AprilTagTarget#from}, both of which call {@link #getInstance()}.
 */
public class AprilTagField {
    private AprilTagFieldLayout layout;

    private static volatile AprilTagField instance;

    private AprilTagField(AprilTagFieldLayout layout) {
        this.layout = layout;
    }

    /**
     * Sets the field layout for the rest of the program. Must be called exactly once, before any
     * call to {@link #getInstance()}.
     *
     * @param layout field layout to use for the rest of the program
     * @throws IllegalStateException if called more than once
     */
    public static synchronized void initialize(AprilTagFieldLayout layout) {
        if (instance != null) {
            throw new IllegalStateException("april tag field has already been initilized");
        }

        instance = new AprilTagField(layout);
    }

    /**
     * Sets the field layout for the rest of the program using a standard game field. Must be
     * called exactly once, before any call to {@link #getInstance()}.
     *
     * @param field standard field to load
     * @throws IllegalStateException if called more than once
     */
    public static synchronized void initialize(AprilTagFields field) {
        initialize(AprilTagFieldLayout.loadField(field));
    }

    /**
     * @return the singleton instance
     * @throws IllegalStateException if {@link #initialize(AprilTagFieldLayout)} has not been called yet
     */
    public static AprilTagField getInstance() {
        if (instance == null) {
            throw new IllegalStateException("must call initialize before calling get intstance");
        }

        return instance;
    }

    /**
     * @param tagID fiducial ID to look up
     * @return the tag, or empty if no tag with that ID exists on the field
     */
    public Optional<AprilTag> getAprilTag(int tagID) {
        return layout.getTagPose(tagID).map(tagPose -> new AprilTag(tagID, tagPose));
    }

    /** @return the field width, in meters */
    public double getWidthMeters() {
        return layout.getFieldWidth();
    }

    /** @return the field length, in meters */
    public double getLengthMeters() {
        return layout.getFieldLength();
    }

    /** @return the underlying field layout */
    public AprilTagFieldLayout getLayout() {
        return layout;
    }

    /** @return every AprilTag defined on the field */
    public List<AprilTag> getTags() {
        List<AprilTag> aprilTags = new ArrayList<>();
        for (var aprilTag: layout.getTags()) {
            aprilTags.add(new AprilTag(aprilTag));
        }
        return aprilTags;
    }
}
