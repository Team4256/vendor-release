package org.cyborgcats.io.motor;

import org.cyborgcats.component.Setpoint;
import org.littletonrobotics.junction.AutoLog;

/**
 * Hardware abstraction for a single motor. Implementations drive one motor and report its
 * telemetry. An implementation that supports following another motor at the vendor level (e.g.
 * {@link MotorIOTalonFX}) reports that via {@link #isFollower()}; {@link
 * org.cyborgcats.component.MotorComponent} uses that to avoid re-applying independent setpoints
 * to it.
 */
public interface MotorIO {
  /** Releases the motor's output so it coasts or brakes according to its configuration. */
  public void applyNetural();

  /**
   * Commands the motor to hold an open-loop output voltage.
   *
   * @param voltage output voltage to apply
   */
  public void applyVoltageSetpoint(double voltage);

  /**
   * Commands the motor to hold an open-loop duty cycle.
   *
   * @param dutyCycle fraction of available bus voltage to apply, from -1.0 to 1.0
   */
  public void applyDutyCycleSetpoint(double dutyCycle);

  /**
   * Commands the motor to closed-loop control to an angular velocity.
   *
   * @param velocity target angular velocity
   */
  public void applyVelocitySetpoint(double velocity);

  /**
   * Commands the motor to closed-loop control to an angular position.
   *
   * @param position target angular position
   */
  public void applyPositionSetpoint(double position);

  /**
   * Commands the motor to a motion-profiled (Motion Magic) closed-loop position.
   *
   * @param position target angular position
   */
  public void applyPositionMotionProfile(double position);

  /**
   * Commands the motor to closed-loop control to an angular velocity using torque-current
   * (FOC) control.
   *
   * @param velocity target angular velocity
   */
  public void applyVelocityTorqueCurrent(double velocity);

  /**
   * Commands the motor to a motion-profiled (Motion Magic) closed-loop angular velocity.
   *
   * @param velocity target angular velocity
   */
  public void applyVelocityMotionProfile(double velocity);


  /**
   * resets the current motor position to the new position
   * @param position new position to set the motor to
   */
  public void setCurrentPosition(double position);


  /**
   * Reads the motor's current telemetry into the given inputs object.
   *
   * @param inputs inputs object populated in place with the latest hardware readings
   */
  public void updateInputs(MotorInputs inputs);

  /**
   * Whether this motor is currently following another motor at the vendor level, and so should
   * not be given independent setpoints.
   *
   * @return true if this motor is a vendor-level follower; false by default
   */
  default boolean isFollower() {
    return false;
  }

  /**
   * Returns the name identifying this motor, used as its AdvantageKit logging key.
   *
   * @return this motor's logging name
   */
  public String getName();

  /** Telemetry snapshot for one motor, logged by AdvantageKit each cycle. */
  @AutoLog
  public class MotorInputs {

    /** Voltage applied to the motor windings. */
    public double motorVoltage = 0.0;

    /** Bus voltage supplied to the motor controller. */
    public double supplyVoltage = 0.0;

    /** Current drawn from the bus by the motor controller. */
    public double supplyCurrent = 0.0;

    /** Current through the motor windings. */
    public double statorCurrent = 0.0;

    /** Measured rotor position. */
    public double position = 0.0;

    /** Measured rotor velocity. */
    public double velocity = 0.0;

    /** Measured rotor acceleration. */
    public double acceleration = 0.0;

    /** Motor controller temperature. */
    public double temperature = 0.0;

    /** Active setpoint in the base units of the current {@link #mode}. */
    public double setpoint = 0.0;

    /** Control mode the motor is currently running in. */
    public Setpoint.Mode mode = Setpoint.Mode.Neutral;

    /** Whether the motor controller is currently responding on the bus. */
    public boolean connected = true;
  }
}
