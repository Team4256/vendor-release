package org.cyborgcats.io.motor;

import com.ctre.phoenix6.configs.TalonFXConfiguration;
import com.ctre.phoenix6.signals.InvertedValue;
import com.ctre.phoenix6.signals.MotorAlignmentValue;

/**
 * Configuration for a TalonFX-backed {@link MotorIO}.
 */
public class MotorIOTalonFXConfiguration implements MotorIOConfiguration {
    private final String name;
    private final int canID;
    private final TalonFXConfiguration conf;
    private final double settlingTime;
    private boolean isFollower = false;
    private int leaderID;
    private MotorAlignmentValue alignmentValue;

    /**
     * Constructs a MotorIOTalonFXConfiguration.
     *
     * @param name             name of the motor controller
     * @param canID            device ID of the TalonFX
     * @param conf             configuration applied to the TalonFX
     * @param simSettlingTime  time constant used by the simulated motor to settle at a commanded
     *                         setpoint
     */
    public MotorIOTalonFXConfiguration(String name, int canID, TalonFXConfiguration conf, double simSettlingTime) {
        this.name = name;
        this.canID = canID;
        this.conf = conf;
        this.settlingTime = simSettlingTime;
    }

    /**
     * Constructs a MotorIOTalonFXConfiguration for a motor that follows {@code leaderID} at the
     * vendor level, instead of taking its own setpoints.
     *
     * @param name            name of the motor controller
     * @param canID           device ID of the TalonFX
     * @param conf             configuration applied to the TalonFX
     * @param leaderID        device ID of the motor this one follows
     * @param alignmentValue  whether this motor spins the same or opposite direction as the leader
     * @param simSettlingTime time constant used by the simulated motor to settle at a commanded
     *                        setpoint
     */
    public MotorIOTalonFXConfiguration(String name, int canID, TalonFXConfiguration conf, int leaderID, MotorAlignmentValue alignmentValue, double simSettlingTime) {
      this(name, canID, conf, simSettlingTime);
      this.leaderID = leaderID;
      this.alignmentValue = alignmentValue;
      this.isFollower = true;
    }

    /**
     * Returns a copy of this configuration with {@code MotorOutput.Inverted} flipped, leaving
     * everything else (including follower state, if this configuration was built with the
     * follower constructor) untouched. Useful for a motor mounted opposite another one it's
     * meant to mirror, e.g. {@code new MotorIOTalonFXConfiguration("Front", canID,
     * LauncherConstants.flywheelConf, 0.1).inverted()}.
     *
     * @return a new configuration identical to this one with inversion flipped
     */
    public MotorIOTalonFXConfiguration inverted() {
        TalonFXConfiguration flipped = conf.clone();
        flipped.MotorOutput.Inverted = flipped.MotorOutput.Inverted == InvertedValue.Clockwise_Positive
            ? InvertedValue.CounterClockwise_Positive
            : InvertedValue.Clockwise_Positive;
        return isFollower
            ? new MotorIOTalonFXConfiguration(name, canID, flipped, leaderID, alignmentValue, settlingTime)
            : new MotorIOTalonFXConfiguration(name, canID, flipped, settlingTime);
    }

    @Override
    public MotorIO buildReal() {
      if (isFollower) {
        return new MotorIOTalonFX(canID, conf, name, leaderID, alignmentValue);
      } else {
        return new MotorIOTalonFX(canID, conf, name);
      }
    }

    @Override
    public MotorIO buildSim() {
        return new MotorIOSim(settlingTime, name);
    }
}
