package org.cyborgcats.subsystem;

import java.util.ArrayList;
import java.util.List;

import org.cyborgcats.component.VisionCamera;
import org.cyborgcats.io.vision.VisionCameraIOConfiguration;
import org.cyborgcats.vision.VisionMeasurment;
import org.cyborgcats.vision.VisionResult;

/**
 * Subsystem that owns one or more {@link VisionCamera} components and calls
 * {@link VisionCamera#updateInputs()} on each every loop iteration.
 */
public abstract class VisionSubsystem extends Subsystem {
  private final ArrayList<VisionCamera> cameras = new ArrayList<>();

  /** Constructs an empty {@code VisionSubsystem} with no cameras registered. */
  public VisionSubsystem() {
  }

  /**
   * Registers cameras to be updated every {@link #periodic()} call.
   *
   * @param cameras cameras to add
   */
  public void addCameras(VisionCamera... cameras) {
    this.cameras.addAll(List.of(cameras));
  }

  /**
   * Builds a {@link VisionCamera} from the given configuration and registers it to be updated
   * every {@link #periodic()} call.
   *
   * @param name unique name used as the AdvantageKit logging key under "Vision/"
   * @param conf configuration used to build the underlying {@link VisionCameraIOConfiguration}
   * @return the newly built and registered camera
   */
  public VisionCamera visionCamera(
    String name,
    VisionCameraIOConfiguration conf
  ) {
    VisionCamera camera = new VisionCamera(name, conf);
    addCameras(camera);
    return camera;
  }

  /**
   * Reads and logs inputs from all registered vision cameras.
   */
  @Override
  public void periodic() {
    for (VisionCamera camera: cameras) {
      camera.updateInputs();
      VisionResult[] results = camera.getUnreadResults();

      for (VisionResult result: results) {
        int tagCount = result.tagCount();
        VisionMeasurment measurment = result.measurment();

        if (tagCount == 1) {
          processSingleTagMesurment(measurment);
        } else {
          processMultiTagMesurment(measurment);
        }
      }
    }
  }

  /**
   * Called for each measurement that came from a single AprilTag.
   *
   * @param measurment the vision pose measurement to process
   */
  protected abstract void processSingleTagMesurment(VisionMeasurment measurment);

  /**
   * Called for each measurement that came from multiple AprilTags.
   *
   * @param measurment the vision pose measurement to process
   */
  protected abstract void processMultiTagMesurment(VisionMeasurment measurment);
}
