package org.cyborgcats.vision;

/**
 * Camera image resolution, in pixels.
 *
 * @param width  image width, in pixels
 * @param height image height, in pixels
 */
public record CameraResolution(int width, int height) {
}