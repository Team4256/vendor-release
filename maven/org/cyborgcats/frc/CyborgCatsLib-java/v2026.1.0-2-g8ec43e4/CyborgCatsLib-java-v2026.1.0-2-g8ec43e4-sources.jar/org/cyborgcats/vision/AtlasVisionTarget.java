package org.cyborgcats.vision;

import edu.wpi.first.util.struct.Struct;
import java.nio.ByteBuffer;

/**
 * Raw wire-format mirror of Atlas's {@code VisionTarget} struct (one AprilTag detection: a
 * fiducial id and its four image-space corners, flattened to 8 floats). Field-for-field match of
 * {@code wpi::Struct<VisionTarget>}'s schema {@code "int32 id;float corners[8]"} in
 * 4256-2026-Atlas's {@code VisionTarget.h}, so it decodes the same bytes Atlas publishes.
 *
 * @param id      fiducial ID of the detected tag
 * @param corners detected image-space corners, flattened as [x0, y0, x1, y1, ...]
 */
public record AtlasVisionTarget(int id, float[] corners) {
  /** WPILib struct serializer/deserializer for this type, for use with {@code StructTopic}s. */
  public static final Struct<AtlasVisionTarget> struct = new AtlasVisionTargetStruct();

  private static final class AtlasVisionTargetStruct
    implements Struct<AtlasVisionTarget>
  {

    @Override
    public Class<AtlasVisionTarget> getTypeClass() {
      return AtlasVisionTarget.class;
    }

    @Override
    public String getTypeName() {
      return "VisionTarget";
    }

    @Override
    public int getSize() {
      return kSizeInt32 + 8 * kSizeFloat;
    }

    @Override
    public String getSchema() {
      return "int32 id;float corners[8]";
    }

    @Override
    public AtlasVisionTarget unpack(ByteBuffer bb) {
      int id = bb.getInt();
      float[] corners = new float[8];
      for (int i = 0; i < corners.length; i++) {
        corners[i] = bb.getFloat();
      }
      return new AtlasVisionTarget(id, corners);
    }

    @Override
    public void pack(ByteBuffer bb, AtlasVisionTarget value) {
      bb.putInt(value.id());
      for (float corner : value.corners()) {
        bb.putFloat(corner);
      }
    }
  }
}
