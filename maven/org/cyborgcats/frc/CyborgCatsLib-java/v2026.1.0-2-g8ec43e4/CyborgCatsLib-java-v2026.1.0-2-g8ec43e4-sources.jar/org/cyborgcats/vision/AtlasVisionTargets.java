package org.cyborgcats.vision;

import edu.wpi.first.util.struct.Struct;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import org.opencv.core.Point;

/**
 * Raw wire-format mirror of Atlas's {@code VisionTargets} struct (one camera frame's worth of
 * detections): a capture timestamp and up to {@link #kMaxTargets} {@link AtlasVisionTarget}
 * slots, with {@code count} recording how many are actually populated. Field-for-field match of
 * {@code wpi::Struct<VisionTargets>}'s schema
 * {@code "double timestamp;int32 count;VisionTarget targets[16]"} in 4256-2026-Atlas's
 * {@code VisionTargets.h} -- the fixed-size array (rather than just {@code count} entries) is
 * required to keep this a flat, constant-size struct that NT's raw struct encoding accepts.
 *
 * @param timestamp capture timestamp of the frame, in seconds
 * @param count     number of populated entries in {@code targets}
 * @param targets   fixed-size array of detection slots; only the first {@code count} are valid
 */
public record AtlasVisionTargets(
  double timestamp,
  int count,
  AtlasVisionTarget[] targets
) {
  static final int kMaxTargets = 16;

  /** WPILib struct serializer/deserializer for this type, for use with {@code StructTopic}s. */
  public static final Struct<AtlasVisionTargets> struct =
    new AtlasVisionTargetsStruct();

  /**
   * Unpacks this frame's populated slots into the JNI-facing detection type.
   *
   * @return this frame's detections, one per populated slot
   */
  public AprilTagDetections detections() {
    List<AprilTagDetection> detectionList = new ArrayList<>(count);
    for (int i = 0; i < count; i++) {
      AtlasVisionTarget target = targets[i];
      List<Point> corners = new ArrayList<>(AprilTagDetection.pointsPerTag);
      for (int c = 0; c < AprilTagDetection.pointsPerTag; c++) {
        corners.add(
          new Point(target.corners()[c * 2], target.corners()[c * 2 + 1])
        );
      }
      detectionList.add(new AprilTagDetection(target.id(), corners));
    }
    return new AprilTagDetections(detectionList);
  }

  private static final class AtlasVisionTargetsStruct
    implements Struct<AtlasVisionTargets>
  {

    @Override
    public Class<AtlasVisionTargets> getTypeClass() {
      return AtlasVisionTargets.class;
    }

    @Override
    public String getTypeName() {
      return "VisionTargets";
    }

    @Override
    public int getSize() {
      return (
        kSizeDouble +
        kSizeInt32 +
        kMaxTargets * AtlasVisionTarget.struct.getSize()
      );
    }

    @Override
    public String getSchema() {
      return "double timestamp;int32 count;VisionTarget targets[16]";
    }

    @Override
    public Struct<?>[] getNested() {
      return new Struct<?>[] { AtlasVisionTarget.struct };
    }

    @Override
    public AtlasVisionTargets unpack(ByteBuffer bb) {
      double timestamp = bb.getDouble();
      int count = bb.getInt();
      AtlasVisionTarget[] targets = Struct.unpackArray(
        bb,
        kMaxTargets,
        AtlasVisionTarget.struct
      );
      return new AtlasVisionTargets(timestamp, count, targets);
    }

    @Override
    public void pack(ByteBuffer bb, AtlasVisionTargets value) {
      bb.putDouble(value.timestamp());
      bb.putInt(value.count());
      Struct.packArray(bb, value.targets(), AtlasVisionTarget.struct);
    }
  }
}
