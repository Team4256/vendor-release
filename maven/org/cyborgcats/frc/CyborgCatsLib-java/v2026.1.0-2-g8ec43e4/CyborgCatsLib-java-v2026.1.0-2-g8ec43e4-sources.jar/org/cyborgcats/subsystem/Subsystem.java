package org.cyborgcats.subsystem;

import java.util.ArrayList;

/**
 * Base subsystem class that auto-registers instances for periodic updates.
 */
public class Subsystem {

  private static final ArrayList<Subsystem> subsystems = new ArrayList<>();

  /**
   * Creates a Subsystem and registers it for periodic updates.
   */
  public Subsystem() {
    subsystems.add(this);
  }

  /**
   * Runs {@link #periodic()} on all registered subsystems.
   */
  public static void runPeriodic() {
    new ArrayList<>(subsystems).forEach(Subsystem::periodic);
  }

  /**
   * Runs {@link #simulationPeriodic()} on all registered subsystems.
   */
  public static void runSimPeriodic() {
    new ArrayList<>(subsystems).forEach(Subsystem::simulationPeriodic);
  }

  /**
   * Runs {@link #periodicAfterScheduler()} on all registered subsystems.
   */
  public static void runPeriodicAfterScheduler() {
    new ArrayList<>(subsystems).forEach(Subsystem::periodicAfterScheduler);
  }

  /**
   * Runs {@link #disable()} on all registered subsystems.
   */
  public static void runDisable() {
    new ArrayList<>(subsystems).forEach(Subsystem::disable);
  }

  /**
   * Called every 20 ms before {@link org.cyborgcats.ssm.Scheduler#run()}.
   */
  public void periodic() {}

  /**
   * Called every 20 ms during simulation.
   */
  public void simulationPeriodic() {}

  /**
   * Called when the robot is disabled.
   */
  public void disable() {}

  /**
   * Called every 20 ms after {@link org.cyborgcats.ssm.Scheduler#run()}.
   */
  public void periodicAfterScheduler() {}
}
