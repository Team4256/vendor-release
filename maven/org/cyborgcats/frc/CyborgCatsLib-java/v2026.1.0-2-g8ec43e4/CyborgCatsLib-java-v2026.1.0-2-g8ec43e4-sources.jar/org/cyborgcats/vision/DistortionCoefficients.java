package org.cyborgcats.vision;

/**
 * OpenCV rational-model lens distortion coefficients: {@code k1}-{@code k6} are radial
 * distortion terms and {@code p1}/{@code p2} are tangential distortion terms.
 *
 * @param k1 first radial distortion coefficient
 * @param k2 second radial distortion coefficient
 * @param p1 first tangential distortion coefficient
 * @param p2 second tangential distortion coefficient
 * @param k3 third radial distortion coefficient
 * @param k4 fourth radial distortion coefficient
 * @param k5 fifth radial distortion coefficient
 * @param k6 sixth radial distortion coefficient
 */
public record DistortionCoefficients(
    double k1, double k2, double p1, double p2, double k3, double k4, double k5, double k6
) {
  /**
   * @return the coefficients as a flat 8-element array, in OpenCV's
   *     {@code (k1, k2, p1, p2, k3, k4, k5, k6)} order
   */
  public double[] toArray() {
    return new double[]{k1, k2, p1, p2, k3, k4, k5, k6};
  }
}
