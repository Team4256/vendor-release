package org.cyborgcats.jni;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import edu.wpi.first.apriltag.AprilTagFieldLayout;
import edu.wpi.first.math.geometry.Pose3d;
import edu.wpi.first.math.geometry.Quaternion;
import edu.wpi.first.math.geometry.Rotation3d;
import edu.wpi.first.math.geometry.Transform3d;
import edu.wpi.first.math.geometry.Translation3d;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Java handle to the native {@code vision} AprilTag estimator.
 *
 * <p>This is the Java half of the JNI bridge defined in
 * {@code AprilTagEstimatorJNI.cpp}. No C++ objects cross the boundary: detections go out as flat
 * primitive arrays and estimates come back as a flat {@code double[]} payload that this class
 * decodes into WPILib geometry types.
 *
 * <p>The instance owns a native estimator and must be released with {@link #close()} (it implements
 * {@link AutoCloseable}, so a try-with-resources block or a single long-lived field both work).
 */
public final class AprilTagEstimatorJNI implements AutoCloseable {
  static {
    System.loadLibrary("vision");
  }

  /** Opaque pointer to the native estimator; 0 once closed. */
  private long handle;

  /**
   * Builds a native estimator for one camera.
   *
   * @param cameraMatrix    3x3 intrinsic matrix as a flat 9-element row-major array
   * @param distCoeffs      lens distortion coefficients, in any length OpenCV accepts
   *                        (0, 4, 5, 8, 12, or 14)
   * @param width           image width in pixels
   * @param height          image height in pixels
   * @param layout          AprilTag field layout used to look up tag poses
   */
  public AprilTagEstimatorJNI(
      double[] cameraMatrix,
      double[] distCoeffs,
      int width,
      int height,
      AprilTagFieldLayout layout) {
    String layoutJson;
    try {
      layoutJson = new ObjectMapper().writeValueAsString(layout);
    } catch (JsonProcessingException e) {
      throw new IllegalArgumentException("failed to serialize AprilTagFieldLayout", e);
    }

    handle = nativeCreate(cameraMatrix, distCoeffs, width, height, layoutJson);
    if (handle == 0) {
      throw new IllegalStateException("native AprilTagEstimator creation failed");
    }
  }

  /**
   * Solves a pose estimate from tag detections using OpenCV PnP (IPPE_SQUARE for a single tag,
   * SQPNP for multiple).
   *
   * @param ids           fiducial IDs of detected tags
   * @param corners       detected corners for all tags, interleaved as [x0, y0, x1, y1, ...]
   * @param pointsPerTag  number of corner points per tag (typically 4)
   * @return the decoded estimate, or empty when the solve produced no result
   */
  public Optional<AprilTagEstimate> solvePnP(int[] ids, float[] corners, int pointsPerTag) {
    ensureOpen();
    return decode(nativeSolvePnP(handle, ids, corners, pointsPerTag));
  }

  /**
   * Solves a pose estimate trigonometrically from a known gyro heading and camera mount. Assumes
   * the robot is flat on the floor.
   *
   * @param ids                 fiducial IDs of detected tags
   * @param corners             detected corners for all tags, interleaved as [x0, y0, x1, y1, ...]
   * @param pointsPerTag        number of corner points per tag (typically 4)
   * @param cameraToRobot       transform from the camera lens to the robot origin
   * @param gyroHeadingRadians  current robot heading from the gyro, in radians
   * @return the decoded estimate, or empty when the solve produced no result
   */
  public Optional<AprilTagEstimate> solveTrig(
      int[] ids,
      float[] corners,
      int pointsPerTag,
      Transform3d cameraToRobot,
      double gyroHeadingRadians) {
    ensureOpen();
    double[] camToRobot = {
      cameraToRobot.getX(),
      cameraToRobot.getY(),
      cameraToRobot.getZ(),
      cameraToRobot.getRotation().getX(),
      cameraToRobot.getRotation().getY(),
      cameraToRobot.getRotation().getZ()
    };
    return decode(
        nativeSolveTrig(handle, ids, corners, pointsPerTag, camToRobot, gyroHeadingRadians));
  }

  /** Releases the native estimator. Safe to call more than once. */
  @Override
  public void close() {
    if (handle != 0) {
      nativeDestroy(handle);
      handle = 0;
    }
  }

  private void ensureOpen() {
    if (handle == 0) {
      throw new IllegalStateException("AprilTagEstimator has been closed");
    }
  }

  // Payload decode. Mirrors the layout documented in AprilTagEstimatorJNI.cpp:
  //   tagCount, tagArea, error1, error2,
  //   pose1 [x y z qw qx qy qz], pose2 [x y z qw qx qy qz],
  //   numTargets,
  //   per target:
  //     id, yaw, pitch, area, skew, bestError, altError,
  //     bestCameraToTag [x y z qw qx qy qz], altCameraToTag [x y z qw qx qy qz],
  //     numCorners, corners [x0 y0 x1 y1 ...]

  private static Optional<AprilTagEstimate> decode(double[] payload) {
    if (payload == null || payload.length == 0) {
      return Optional.empty();
    }

    Cursor c = new Cursor(payload);

    int tagCount = (int) c.next();
    double tagArea = c.next();
    double error1 = c.next();
    double error2 = c.next();
    Pose3d pose1 = c.readPose();
    Pose3d pose2 = c.readPose();

    int numTargets = (int) c.next();
    List<Target> targets = new ArrayList<>(numTargets);
    for (int t = 0; t < numTargets; ++t) {
      int id = (int) c.next();
      double yaw = c.next();
      double pitch = c.next();
      double area = c.next();
      double skew = c.next();
      double bestError = c.next();
      double altError = c.next();
      Transform3d bestCameraToTag = c.readTransform();
      Transform3d altCameraToTag = c.readTransform();

      int numCorners = (int) c.next();
      double[] corners = new double[numCorners * 2];
      for (int k = 0; k < corners.length; ++k) {
        corners[k] = c.next();
      }

      targets.add(
          new Target(
              id, yaw, pitch, area, skew, bestError, altError,
              bestCameraToTag, altCameraToTag, corners));
    }

    return Optional.of(
        new AprilTagEstimate(tagCount, tagArea, error1, error2, pose1, pose2, targets));
  }

  /** Sequential reader over the flat payload. */
  private static final class Cursor {
    private final double[] data;
    private int i;

    Cursor(double[] data) {
      this.data = data;
    }

    double next() {
      return data[i++];
    }

    Pose3d readPose() {
      Translation3d translation = new Translation3d(next(), next(), next());
      Rotation3d rotation = new Rotation3d(new Quaternion(next(), next(), next(), next()));
      return new Pose3d(translation, rotation);
    }

    Transform3d readTransform() {
      Translation3d translation = new Translation3d(next(), next(), next());
      Rotation3d rotation = new Rotation3d(new Quaternion(next(), next(), next(), next()));
      return new Transform3d(translation, rotation);
    }
  }

  /**
   * Decoded AprilTag pose estimate.
   *
   * @param tagCount number of tags used in the estimate
   * @param tagArea  on-screen area of the tags, on a 0-100 scale
   * @param error1   reprojection error of {@code pose1}
   * @param error2   reprojection error of {@code pose2} (single-tag only; NaN otherwise)
   * @param pose1    primary camera-space pose estimate
   * @param pose2    alternate camera-space pose estimate (single-tag ambiguity)
   * @param targets  per-tag detection data
   */
  public record AprilTagEstimate(
      int tagCount,
      double tagArea,
      double error1,
      double error2,
      Pose3d pose1,
      Pose3d pose2,
      List<Target> targets) {}

  /**
   * Per-tag detection data carried within an {@link AprilTagEstimate}.
   *
   * @param id               fiducial ID
   * @param yaw              yaw bearing to the tag, in radians (positive left)
   * @param pitch            pitch bearing to the tag, in radians (positive up)
   * @param area             on-screen area of the tag, on a 0-100 scale
   * @param skew             skew of the tag, in radians (counter-clockwise positive)
   * @param bestError        reprojection error of {@code bestCameraToTag}
   * @param altError         reprojection error of {@code altCameraToTag}
   * @param bestCameraToTag  best camera-to-tag transform
   * @param altCameraToTag   alternate camera-to-tag transform
   * @param corners          detected corner pixels, interleaved as [x0, y0, x1, y1, ...]
   */
  public record Target(
      int id,
      double yaw,
      double pitch,
      double area,
      double skew,
      double bestError,
      double altError,
      Transform3d bestCameraToTag,
      Transform3d altCameraToTag,
      double[] corners) {}

  // Native methods, implemented in AprilTagEstimatorJNI.cpp.

  private static native long nativeCreate(
      double[] cameraMatrix, double[] distCoeffs, int width, int height, String fieldLayoutJson);

  private static native void nativeDestroy(long handle);

  private static native double[] nativeSolvePnP(
      long handle, int[] ids, float[] corners, int pointsPerTag);

  private static native double[] nativeSolveTrig(
      long handle,
      int[] ids,
      float[] corners,
      int pointsPerTag,
      double[] cameraToRobot,
      double gyroHeadingRadians);
}
