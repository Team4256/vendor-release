package org.cyborgcats.vision;

import edu.wpi.first.math.geometry.Pose3d;

/**
 * A single AprilTag's fiducial ID and its known field-relative pose, as defined by the current
 * {@link AprilTagField} layout.
 *
 * @param tagID   fiducial ID of the tag
 * @param tagPose field-relative pose of the tag
 */
public record AprilTag(int tagID, Pose3d tagPose) {
    /**
     * Converts a WPILib {@link edu.wpi.first.apriltag.AprilTag} into this record.
     *
     * @param aprilTag the WPILib AprilTag to convert
     */
    public AprilTag(edu.wpi.first.apriltag.AprilTag aprilTag) {
        this(aprilTag.ID, aprilTag.pose);
    }
}
