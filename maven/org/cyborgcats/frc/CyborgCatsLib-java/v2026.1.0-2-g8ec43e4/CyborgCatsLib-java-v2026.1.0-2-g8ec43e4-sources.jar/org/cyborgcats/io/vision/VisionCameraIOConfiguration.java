package org.cyborgcats.io.vision;

import org.cyborgcats.io.IOConfiguration;

/**
 * Shared shape for vision camera configs that can build either a real or simulated
 * {@link VisionCameraIO} implementation.
 */
public interface VisionCameraIOConfiguration extends IOConfiguration<VisionCameraIO> {

}
