package org.cyborgcats.subsystem;

import edu.wpi.first.math.geometry.Pose3d;
import edu.wpi.first.wpilibj.Timer;
import java.util.ArrayList;
import java.util.Arrays;
import org.cyborgcats.component.Component;
import org.cyborgcats.component.DriveState;
import org.cyborgcats.component.Encoder;
import org.cyborgcats.component.Flywheel;
import org.cyborgcats.component.MotorComponent;
import org.cyborgcats.component.PositionComponent;
import org.cyborgcats.component.Setpoint;
import org.cyborgcats.component.Turret;
import org.cyborgcats.component.VelocityComponent;
import org.cyborgcats.io.motor.MotorIOConfiguration;
import org.cyborgcats.io.sensor.encoder.EncoderIOConfiguration;
import org.cyborgcats.ssm.State;
import org.cyborgcats.util.Range;
import org.littletonrobotics.junction.Logger;

/**
 * Subsystem class for systems needing action control.
 */
public class ActionSubsystem extends Subsystem {

  /**
   * The disabled action, which does nothing.
   */
  private final Action defualtAction = new Action("DEFAULT", this, () -> {});

  private Action disabledAction = defualtAction;

  /**
   * The list of mechanisms managed by this subsystem.
   */
  private final ArrayList<Component> components = new ArrayList<>();

  /**
   * The timer used to track action duration.
   */
  private final Timer timer = new Timer();

  /**
   * The current action being executed.
   */
  private Action action = defualtAction;

  /**
   * Creates an ActionSubsystem with no mechanisms; register components via {@link #addComponents}
   * or one of the {@code *Component}/{@code encoder} factory methods.
   */
  public ActionSubsystem() {
    super();
  }

  /**
   *
   * Updates the current action and resets the action timer.
   *
   * @param action new action to apply
   */
  protected void applyAction(Action action) {
    timer.stop();
    timer.reset();
    timer.start();
    this.action = action;
  }

  /**
   * Returns the current action.
   *
   * @return the active {@link Action}
   */
  public Action getAction() {
    return action;
  }

  /**
   * Updates all mechanism inputs.
   */
  @Override
  public void periodic() {
    components.forEach(Component::updateInputs);
  }

  /**
   * Records the current action to telemetry and executes it.
   */
  @Override
  public void periodicAfterScheduler() {
    Logger.recordOutput(
      "Subsystems/" + this.getClass().getSimpleName() + "/action",
      action.getName()
    );
    Logger.recordOutput(
      "Subsystems/" + this.getClass().getSimpleName() + "/action duration",
      timer.get()
    );
    action.runAction();
  }

  /**
   * Disables the action subsystem, applying the disabled action.
   */
  @Override
  public void disable() {
    applyAction(disabledAction);
  }

  /**
   * sets a new action to be the disabled action that runs on {@link Subsystem#disable()}
   * @param action new action to be set
   */
  public void setDisabledAction(Action action) {
    this.disabledAction = action;
  }

  /**
   * gets the current disabled action
   * @return the current disabled action
   */
  public Action getDisabledAction() {
    return disabledAction;
  }

  /**
   * Registers one or more already-constructed components so they're updated by {@link #periodic()}.
   *
   * @param components the components to register
   */
  public void addComponents(Component... components) {
    this.components.addAll(Arrays.asList(components));
  }

  /**
   * Registers a newly built component so it's updated by {@link #periodic()}, then returns it.
   *
   * @param component the component to register
   * @return the same component, for assignment in one line
   */
  private <T extends Component> T register(T component) {
    addComponents(component);
    return component;
  }

  /**
   * Creates an {@link Action} bound to this subsystem.
   *
   * @param name   name used for AdvantageKit logging
   * @param action runnable executed when the action runs
   * @return the newly created action
   */
  public Action action(String name, Runnable action) {
    return new Action(name, this, action);
  }

  /**
   * Builds a {@link MotorComponent} and registers it with this subsystem.
   *
   * @param name      unique name used as the AdvantageKit logging key under "mechanisms/"
   * @param leader    configuration used to build the hardware interface for this motor
   * @param followers configurations for hardware interfaces driven with the same control request as
   *                  the leader; may be omitted for a single-motor mechanism
   * @return the newly created and registered {@link MotorComponent}
   */
  public MotorComponent motorComponent(
     String name,
    MotorIOConfiguration leader,
    MotorIOConfiguration... followers
  ) {
    return register(new MotorComponent(name, leader, followers));
  }

  /**
   * Builds a {@link PositionComponent} and registers it with this subsystem.
   *
   * @param name         unique name used as the AdvantageKit logging key under "mechanisms/"
   * @param threshold    angular tolerance used to determine whether the component is at a target
   *                     position
   * @param debounceTime how long (in seconds) the component must continuously be within threshold
   *                     before the at-position check returns {@code true}
   * @param leader       configuration used to build the hardware interface for this motor
   * @param followers    configurations for hardware interfaces driven with the same control request as
   *                     the leader; may be omitted for a single-motor mechanism
   * @return the newly created and registered {@link PositionComponent}
   */
  public PositionComponent positionComponent(
    String name,
    double threshold,
    double debounceTime,
    MotorIOConfiguration leader,
    MotorIOConfiguration... followers
  ) {
    return register(
      new PositionComponent(name, threshold, debounceTime, leader, followers)
    );
  }

  /**
   * Builds a {@link VelocityComponent} and registers it with this subsystem.
   *
   * @param name         unique name used as the AdvantageKit logging key under "mechanisms/"
   * @param threshold    velocity tolerance used to determine whether the component is at a target
   *                     speed
   * @param debounceTime how long (in seconds) the component must continuously be within threshold
   *                     before the at-velocity check returns {@code true}
   * @param leader       configuration used to build the hardware interface for this motor
   * @param followers    configurations for hardware interfaces driven with the same control request as
   *                     the leader; may be omitted for a single-motor mechanism
   * @return the newly created and registered {@link VelocityComponent}
   */
  public VelocityComponent velocityComponent(
    String name,
    double threshold,
    double debounceTime,
    MotorIOConfiguration leader,
    MotorIOConfiguration... followers
  ) {
    return register(
      new VelocityComponent(name, threshold, debounceTime, leader, followers)
    );
  }

  /**
   * Builds a {@link Turret} and registers it with this subsystem.
   *
   * @param name         unique name used as the AdvantageKit logging key under "mechanisms/"
   * @param threshold    angular tolerance used to determine whether the turret is at a target
   *                     position
   * @param debounceTime how long (in seconds) the turret must continuously be within threshold
   *                     before the at-position check returns {@code true}
   * @param encoderOneConf   configuration for the encoder on the first reduction gear; its sim
   *                         implementation is driven off the turret's own rotation automatically
   * @param encoderTwoConf   configuration for the encoder on the second reduction gear; must have
   *                         a different tooth count than encoder one for the CRT solve to be unique
   * @param range            minimum and maximum angle the turret can rotate to
   * @param tolerance        how close (in rotations) a CRT candidate must be to encoder two's
   *                         reading to be accepted; size to the encoders' combined noise
   * @param turretToothCount tooth count of the gear fixed to the turret that both encoder gears
   *                         mesh with
   * @param driveState       suppliers of the robot's field-relative chassis speeds and pose
   * @param turretOffset     pose of the turret's rotation axis relative to the robot origin
   * @param leader           configuration used to build the hardware interface for the turret motor
   * @return the newly created and registered {@link Turret}
   */
  public Turret turret(
    String name,
    double threshold,
    double debounceTime,
    EncoderIOConfiguration encoderOneConf,
    EncoderIOConfiguration encoderTwoConf,
    Range range,
    double tolerance,
    int turretToothCount,
    double k,
    DriveState driveState,
    Pose3d turretOffset,
    MotorIOConfiguration leader
  ) {
    return register(
      new Turret(
        name,
        threshold,
        debounceTime,
        encoderOneConf,
        encoderTwoConf,
        range,
        tolerance,
        turretToothCount,
        k,
        driveState,
        turretOffset,
        leader
      )
    );
  }

  /**
   * Builds a {@link Flywheel} and registers it with this subsystem.
   *
   * @param name              unique name used as the AdvantageKit logging key under "mechanisms/"
   * @param threshold         velocity tolerance used to determine whether the shooter is at a target speed
   * @param bangbangThreshold velocity tolerance used to decide when to switch from open-loop
   *                          spin-up to closed-loop velocity holding
   * @param debounceTime      how long (in seconds) the shooter must continuously be within threshold
   *                          before the at-velocity check returns {@code true}
   * @param mode              control mode used to hold velocity once the wheel is at speed
   * @param leader            configuration used to build the hardware interface for this motor
   * @param followers         configurations for hardware interfaces driven with the same control request as
   *                          the leader; may be omitted for a single-motor shooter
   * @return the newly created and registered {@link Flywheel}
   */
  public Flywheel flywheel(
    String name,
    double threshold,
    double bangbangThreshold,
    double debounceTime,
    Setpoint.Mode mode,
    MotorIOConfiguration leader,
    MotorIOConfiguration... followers
  ) {
    return register(new Flywheel(name, threshold, bangbangThreshold, debounceTime, mode, leader, followers));
  }

  /**
   * Builds an {@link Encoder} and registers it with this subsystem.
   *
   * @param name       unique name used as the AdvantageKit logging key under "Sensors/"
   * @param conf       configuration used to build this encoder's hardware interface
   * @return the newly created and registered {@link Encoder}
   */
  public Encoder encoder(String name, EncoderIOConfiguration conf) {
    return register(new Encoder(name, conf));
  }

  /**
   * Named, executable action for use with {@link ActionSubsystem}.
   */
  public static class Action {

    private final String name;
    private final ActionSubsystem subsystem;
    private final Runnable action;

    /**
     * Creates an Action with the given name and runnable.
     *
     * @param name       name used for AdvantageKit logging
     * @param subsystem  the ActionSubsystem this action is registered with
     * @param action     runnable executed in {@link ActionSubsystem#periodicAfterScheduler()}
     */
    public Action(String name, ActionSubsystem subsystem, Runnable action) {
      this.name = name;
      this.subsystem = subsystem;
      this.action = action;
    }

    /**
     * Executes the underlying runnable.
     */
    protected void runAction() {
      action.run();
    }

    /**
     * Makes this action the subsystem's current action.
     */
    public void run() {
      subsystem.applyAction(this);
    }

    /**
     * Returns the name of this action used for AdvantageKit logging.
     *
     * @return the action name
     */
    public String getName() {
      return name;
    }

    /**
     * Wraps this action in a {@link State} that applies it once when scheduled, requiring the
     * owning subsystem and interruptible by default. Lets an {@link Action} be scheduled directly
     * by a {@link org.cyborgcats.ssm.Scheduler} or {@link org.cyborgcats.ssm.StateTrigger}.
     *
     * @return a new state that runs this action
     */
    public State toState() {
      return State.withStep(() -> this.run())
        .withName(name)
        .withRequirements(this.subsystem)
        .isInterruptible(true)
        .withIgnoreDisable(false);
    }
  }
}
