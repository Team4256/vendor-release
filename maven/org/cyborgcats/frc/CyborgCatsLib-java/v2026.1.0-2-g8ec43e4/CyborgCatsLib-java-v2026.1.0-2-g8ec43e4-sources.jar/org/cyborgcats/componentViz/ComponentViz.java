package org.cyborgcats.componentViz;

import edu.wpi.first.math.geometry.Pose3d;
import edu.wpi.first.math.geometry.Transform3d;
import java.util.Optional;
import java.util.function.Supplier;

/**
 * Represents a single visualizable robot component, encapsulating its name, 3D pose supplier,
 * optional parent component (for kinematic chaining), and rendering order.
 */
public class ComponentViz {

  private final String name;
  private final Supplier<Pose3d> pose;
  private final Optional<ComponentViz> parent;
  private final int order;

  /**
   * Constructs a ComponentViz with a parent for kinematic chaining, and registers it with
   * {@link ComponentVizRegistry} for inclusion in the next pose build.
   *
   * @param name   unique display name
   * @param pose   supplier returning the component's local-space pose
   * @param parent the parent component this pose is expressed relative to
   * @param order  rendering order index used to sort components before logging
   */
  public ComponentViz(
    String name,
    Supplier<Pose3d> pose,
    ComponentViz parent,
    int order
  ) {
    this.name = name;
    this.pose = pose;
    this.parent = Optional.ofNullable(parent);
    this.order = order;
    ComponentVizRegistry.register(this);
  }

  /**
   * Constructs a root ComponentViz with no parent, and registers it with
   * {@link ComponentVizRegistry} for inclusion in the next pose build.
   *
   * @param name  unique display name
   * @param pose  supplier returning the component's world-space pose
   * @param order rendering order index used to sort components before logging
   */
  public ComponentViz(
    String name,
    Supplier<Pose3d> pose,
    int order
  ) {
    this(name, pose, null, order);
  }

  /**
   * Returns the unique display name of this component.
   *
   * @return the component name
   */
  public String getName() {
    return name;
  }

  /**
   * Returns a supplier that evaluates this component's world-space {@link Pose3d}.
   * If a parent component is set, the returned pose is expressed relative to the parent's pose.
   *
   * @return supplier of this component's world-space pose
   */
  public Supplier<Pose3d> getPose() {
    if (parent.isEmpty()) {
      return pose;
    }
    return () -> {
      Pose3d local = pose.get();
      return parent
        .get()
        .getPose()
        .get()
        .transformBy(
          new Transform3d(local.getTranslation(), local.getRotation())
        );
    };
  }

  /**
   * Returns the optional parent component whose pose this component's pose is relative to.
   *
   * @return an {@link Optional} containing the parent, or empty if this is a root component
   */
  public Optional<ComponentViz> getParent() {
    return parent;
  }

  /**
   * Returns the rendering order index; lower values are logged first in the pose array.
   *
   * @return the rendering order
   */
  public int getOrder() {
    return order;
  }
}
