package org.cyborgcats.field;

import edu.wpi.first.apriltag.AprilTagFieldLayout;
import edu.wpi.first.apriltag.AprilTagFields;
import edu.wpi.first.math.geometry.Pose2d;
import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.math.geometry.Translation2d;
import org.cyborgcats.field.AllianceSelector.AllianceType;

/**
 * Utility class for alliance-aware coordinate transformations.
 * When the active alliance is {@link AllianceType#RED}, coordinates are mirrored about the
 * centre of the field so that game pieces and field elements can be defined once from the
 * blue-alliance perspective.
 */
public class AllianceUtil {
  
  /**
   * The current season's AprilTag field layout, used for field dimension lookups.
   */
  public static AprilTagFieldLayout layout = AprilTagFieldLayout.loadField(AprilTagFields.kDefaultField);

  /**
   * Flips an X coordinate to the red-alliance side when {@link #shouldFlip()} is {@code true}.
   *
   * @param x blue-alliance X coordinate in meters
   * @return the coordinate after alliance flipping
   */
  public static double flipX(double x) {
    return shouldFlip() ? layout.getFieldLength() - x : x;
  }


  /**
   * Flips a Y coordinate to the red-alliance side when {@link #shouldFlip()} is {@code true}.
   *
   * @param y blue-alliance Y coordinate in meters
   * @return the coordinate after alliance flipping
   */
  public static double flipY(double y) {
    return shouldFlip() ? layout.getFieldWidth() - y : y;
  }

  /**
   * Applies the current alliance flip to a 2D translation.
   *
   * @param translation blue-alliance translation
   * @return the translation after alliance flipping
   */
  public static Translation2d apply(Translation2d translation) {
    return new Translation2d(flipX(translation.getX()), flipY(translation.getY()));
  }

  /**
   * Applies the current alliance flip to a rotation (180° rotation for red alliance).
   *
   * @param rotation blue-alliance rotation
   * @return the rotation after alliance flipping
   */
  public static Rotation2d apply(Rotation2d rotation) {
    return shouldFlip() ? rotation.rotateBy(Rotation2d.kPi) : rotation;
  }

  /**
   * Applies the current alliance flip to a 2D pose.
   *
   * @param pose blue-alliance pose
   * @return the pose after alliance flipping
   */
  public static Pose2d apply(Pose2d pose) {
    return shouldFlip() ? new Pose2d(apply(pose.getTranslation()), apply(pose.getRotation())) : pose;
  }

  /**
   * Applies the current alliance flip to a {@link Bounds} region.
   *
   * @param bounds blue-alliance bounding region
   * @return the bounds after alliance flipping
   */
  public static Bounds apply(Bounds bounds) {
    if (shouldFlip()) {
      return new Bounds(
          flipX(bounds.maxX()),
          flipX(bounds.minX()),
          flipY(bounds.maxY()),
          flipY(bounds.minY()));
    } else {
      return bounds;
    }
  }

  /**
   * Returns {@code true} when coordinates should be mirrored for the red alliance.
   *
   * @return {@code true} if the active alliance is {@link AllianceType#RED}
   */
  public static boolean shouldFlip() {
    return AllianceSelector.getAllianceType() == AllianceType.RED;
  }
}
