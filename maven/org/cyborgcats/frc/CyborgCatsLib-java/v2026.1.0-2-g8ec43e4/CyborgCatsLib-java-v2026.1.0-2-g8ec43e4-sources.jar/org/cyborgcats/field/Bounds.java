package org.cyborgcats.field;

import org.littletonrobotics.junction.Logger;

import edu.wpi.first.math.MathUtil;
import edu.wpi.first.math.geometry.Pose2d;
import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.math.geometry.Translation2d;

/**
 * An axis-aligned 2D bounding rectangle defined by minimum and maximum X and Y distances.
 *
 * @param minX left boundary
 * @param maxX right boundary
 * @param minY bottom boundary
 * @param maxY top boundary
 */
public record Bounds(double minX, double maxX, double minY, double maxY) {
  /**
   * Returns {@code true} if the given translation falls within this bounding region (inclusive).
   *
   * @param translation the 2D point to test
   * @return {@code true} if the point is inside the bounds
   */
  public boolean contains(Translation2d translation) {
    return translation.getX() >= minX()
        && translation.getX() <= maxX()
        && translation.getY() >= minY()
        && translation.getY() <= maxY();
  }

  /**
   * Returns {@code true} if the translation component of the given pose falls within this
   * bounding region (inclusive).
   *
   * @param pose the pose whose translation is tested
   * @return {@code true} if the pose's translation is inside the bounds
   */
  public boolean contains(Pose2d pose) {
    return pose.getTranslation().getX() >= minX()
        && pose.getTranslation().getX() <= maxX()
        && pose.getTranslation().getY() >= minY()
        && pose.getTranslation().getY() <= maxY();
  }

  /**
   * Clamps the given translation to the nearest point inside this bounding region.
   *
   * @param translation the point to clamp
   * @return a new translation clamped to the bounds
   */
  public Translation2d clamp(Translation2d translation) {
    return new Translation2d(
        MathUtil.clamp(translation.getX(), minX(), maxX()),
        MathUtil.clamp(translation.getY(), minY(), maxY()));
  }

  /**
   * Returns the four corners of this bounding region as a closed polygon (first point repeated
   * at the end for rendering purposes).
   *
   * @return array of five {@link Translation2d} points forming the rectangle outline
   */
  public Translation2d[] sides() {
    return new Translation2d[]{
        new Translation2d(minX(), minY()),
        new Translation2d(minX(), maxY()),
        new Translation2d(maxX(), maxY()),
        new Translation2d(maxX(), minY()),
        new Translation2d(minX(), minY())
    };
  }

  /**
   * Logs the bounding region outline as an array of {@link edu.wpi.first.math.geometry.Pose2d}
   * values to AdvantageKit under the given key.
   *
   * @param key the AdvantageKit logging key
   */
  public void log(String key) {
    Translation2d[] corners = sides();
    Pose2d[] poses = new Pose2d[corners.length];
    for (int i = 0; i < corners.length; i++) {
      poses[i] = new Pose2d(corners[i], new Rotation2d());
    }
    Logger.recordOutput(key, poses);
  }
}
