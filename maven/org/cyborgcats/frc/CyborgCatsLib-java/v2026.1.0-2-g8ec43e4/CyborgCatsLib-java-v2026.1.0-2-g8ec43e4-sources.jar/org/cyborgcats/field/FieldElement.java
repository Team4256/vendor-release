package org.cyborgcats.field;

import org.littletonrobotics.junction.Logger;

import edu.wpi.first.math.geometry.Pose2d;
import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.math.geometry.Translation2d;

/**
 * A field constant defined once from the blue-alliance perspective that transparently mirrors
 * itself to the red side via {@link AllianceUtil} on every read, and self-registers with
 * {@link FieldElementRegistry} so it can be logged automatically each loop.
 *
 * @param <T> the underlying value type, e.g. {@link Translation2d}, {@link Pose2d}, or
 *            {@link Bounds}
 */
public class FieldElement<T> {
    /** The value as defined from the blue-alliance perspective, never flipped. */
    protected final T blueValue;
    /** The AdvantageKit logging key this element is published under. */
    protected final String key;

    /**
     * Creates a field element and registers it with {@link FieldElementRegistry}. Private —
     * use one of the {@code ofX} factory methods instead, which supply the correct alliance-flip
     * and logging behavior for {@code T}.
     *
     * @param key       the AdvantageKit logging key
     * @param blueValue the value as defined from the blue-alliance perspective
     */
    private FieldElement (String key, T blueValue) {
        this.blueValue = blueValue;
        this.key = key;
        FieldElementRegistry.register(this);
    }

    /**
     * Returns the original blue-alliance value, ignoring the current alliance.
     *
     * @return the un-flipped, blue-perspective value
     */
    public T getBlueValue() {
        return blueValue;
    }

    /**
     * Returns the value as seen from the current alliance's perspective. Overridden by each
     * {@code ofX} factory to apply the correct {@link AllianceUtil} flip for {@code T}; the base
     * implementation just returns the un-flipped blue value.
     *
     * @return the alliance-corrected value
     */
    public T get() {
        return blueValue;
    }

    /**
     * Logs the current alliance-corrected value to AdvantageKit under {@link #key}. Overridden by
     * each {@code ofX} factory; called by {@link FieldElementRegistry} every loop, not normally
     * invoked directly. No-op in the base implementation.
     */
    public void log() {
    }

    /**
     * constructs a pose2d from a translation2d using a new Rotation2d()
     * @param translation2d supplied translation2d
     * @return the constructed pose2d
     */
    public static Pose2d toPose2d(FieldElement<Translation2d> translation2d) {
        return new Pose2d(translation2d.get(), new Rotation2d());
    }

    /**
     * Creates a {@code FieldElement<Translation2d>} that mirrors about the field center for red
     * alliance.
     * 
     * Translations are logged as poses with a defualt rotation2d object to be easily viewed in advantage scope 
     *
     * @param key the AdvantageKit logging key
     * @param x   the blue-alliance X coordinate, in meters
     * @param y   the blue-alliance Y coordinate, in meters
     * @return the newly created field element
     */
    public static FieldElement<Translation2d> ofTranslation2d(String key, double x, double y) {
        Translation2d translation2d = new Translation2d(x, y);
        return new FieldElement<Translation2d>(key, translation2d) {
            @Override
            public Translation2d get() {
                return AllianceUtil.apply(translation2d);
            }

            @Override
            public void log() {
                Logger.recordOutput("FieldElements/" + key, new Pose2d(get(), new Rotation2d()));
            }
        };
    }

    /**
     * Creates a {@code FieldElement<Translation2d>} that does not mirror about the field center for red
     * alliance.
     * Translations are logged as poses with a defualt rotation2d object to be easily viewed in advantage scope 
     *
     * @param key the AdvantageKit logging key
     * @param x   the blue-alliance X coordinate, in meters
     * @param y   the blue-alliance Y coordinate, in meters
     * @return the newly created field element
     */
    public static FieldElement<Translation2d> ofStaticTranslation2d(String key, double x, double y) {
        Translation2d translation2d = new Translation2d(x, y);
        return new FieldElement<Translation2d>(key, translation2d) {
            @Override
            public Translation2d get() {
                return translation2d;
            }

            @Override
            public void log() {
                Logger.recordOutput("FieldElements/" + key, new Pose2d(get(), new Rotation2d()));
            }
        };
    }

    /**
     * Creates a {@code FieldElement<Pose2d>} that mirrors about the field center for red
     * alliance.
     *
     * @param key the AdvantageKit logging key
     * @param x   the blue-alliance X coordinate, in meters
     * @param y   the blue-alliance Y coordinate, in meters
     * @param rot the blue-alliance heading
     * @return the newly created field element
     */
    public static FieldElement<Pose2d> ofPose2d(String key, double x, double y, Rotation2d rot) {
        Pose2d pose2d = new Pose2d(x, y, rot);
        return new FieldElement<Pose2d>(key, pose2d) {
            @Override
            public Pose2d get() {
                return AllianceUtil.apply(pose2d);
            }

            @Override
            public void log() {
                Logger.recordOutput("FieldElements/" + key, get());
            }
        };
    }

    /**
     * Creates a {@code FieldElement<Pose2d>} that does not mirror about the field center for red
     * alliance.
     *
     * @param key the AdvantageKit logging key
     * @param x   the blue-alliance X coordinate, in meters
     * @param y   the blue-alliance Y coordinate, in meters
     * @param rot the blue-alliance heading
     * @return the newly created field element
     */
    public static FieldElement<Pose2d> ofStaticPose2d(String key, double x, double y, Rotation2d rot) {
        Pose2d pose2d = new Pose2d(x, y, rot);
        return new FieldElement<Pose2d>(key, pose2d) {
            @Override
            public Pose2d get() {
                return pose2d;
            }

            @Override
            public void log() {
                Logger.recordOutput("FieldElements/" + key, get());
            }
        };
    }

    /**
     * Creates a {@code FieldElement<Bounds>} that mirrors about the field center for red
     * alliance.
     *
     * @param key  the AdvantageKit logging key
     * @param minX the blue-alliance left boundary, in meters
     * @param maxX the blue-alliance right boundary, in meters
     * @param minY the blue-alliance bottom boundary, in meters
     * @param maxY the blue-alliance top boundary, in meters
     * @return the newly created field element
     */
    public static FieldElement<Bounds> ofBounds(String key, double minX, double maxX, double minY, double maxY) {
        Bounds bounds = new Bounds(minX, maxX, minY, maxY);
        return new FieldElement<Bounds>(key, bounds) {
            @Override
            public Bounds get() {
                return AllianceUtil.apply(bounds);
            }

            @Override
            public void log() {
                get().log("FieldElements/" + key);
            }
        };
    }

    /**
     * Creates a {@code FieldElement<Bounds>} that does not mirror across the field
     *
     * @param key  the AdvantageKit logging key
     * @param minX the blue-alliance left boundary, in meters
     * @param maxX the blue-alliance right boundary, in meters
     * @param minY the blue-alliance bottom boundary, in meters
     * @param maxY the blue-alliance top boundary, in meters
     * @return the newly created field element
     */
    public static FieldElement<Bounds> ofStaticBounds(String key, double minX, double maxX, double minY, double maxY) {
        Bounds bounds = new Bounds(minX, maxX, minY, maxY);
        return new FieldElement<Bounds>(key, bounds) {
            @Override
            public Bounds get() {
                return bounds;
            }

            @Override
            public void log() {
                get().log("FieldElements/" + key);
            }
        };
    }
    
}
