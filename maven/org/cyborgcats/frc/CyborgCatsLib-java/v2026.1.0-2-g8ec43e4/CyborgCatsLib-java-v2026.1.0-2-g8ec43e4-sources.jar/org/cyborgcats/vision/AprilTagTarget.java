package org.cyborgcats.vision;

import java.util.ArrayList;
import java.util.Optional;

import org.opencv.core.Point;

import edu.wpi.first.math.geometry.Transform3d;

import org.cyborgcats.jni.AprilTagEstimatorJNI;

/**
 * Per-tag detail for a single AprilTag that contributed to an {@link AprilTagEstimate}: its
 * known field pose, detected image corners, angular offsets, and both pose-solve candidates for
 * this tag alone.
 *
 * @param aprilTag        the detected tag's known field ID and pose
 * @param corners         detected image-space corners of this tag
 * @param yaw             horizontal angle from the camera to the tag, in degrees
 * @param pitch           vertical angle from the camera to the tag, in degrees
 * @param area            on-screen area of this tag, as a fraction of the image area
 * @param skew            skew of the detected tag quad
 * @param bestCameraToTag transform from camera to tag for the best pose candidate
 * @param altCameraToTag  transform from camera to tag for the alternate pose candidate
 * @param bestError       reprojection error of the best pose candidate
 * @param altError        reprojection error of the alternate pose candidate
 */
public record AprilTagTarget(
    AprilTag aprilTag,
    ArrayList<Point> corners,
    double yaw,
    double pitch,
    double area,
    double skew,
    Transform3d bestCameraToTag,
    Transform3d altCameraToTag,
    double bestError,
    double altError
) {
    /**
     * Converts a raw JNI target into this higher-level type, resolving its fiducial ID against
     * the field layout and unpacking its flat corner array into {@link Point}s.
     *
     * @param target the raw JNI target to convert
     * @return empty if {@code target}'s ID isn't in the field layout (the native solve may still
     *     include such a target even when it didn't contribute to the pose estimate)
     */
    public static Optional<AprilTagTarget> from(AprilTagEstimatorJNI.Target target) {
        Optional<AprilTag> aprilTag = AprilTagField.getInstance().getAprilTag(target.id());
        if (aprilTag.isEmpty()) {
            return Optional.empty();
        }

        double[] flatCorners = target.corners();
        ArrayList<Point> corners = new ArrayList<>(flatCorners.length / 2);
        for (int i = 0; i < flatCorners.length; i += 2) {
            corners.add(new Point(flatCorners[i], flatCorners[i + 1]));
        }

        return Optional.of(new AprilTagTarget(
            aprilTag.get(),
            corners,
            target.yaw(),
            target.pitch(),
            target.area(),
            target.skew(),
            target.bestCameraToTag(),
            target.altCameraToTag(),
            target.bestError(),
            target.altError()
        ));
    }
}
