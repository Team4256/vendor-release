package org.cyborgcats.field;

import org.cyborgcats.util.Tunable;

public class AllianceSelector {
  /**
   * Enumeration of FRC alliance colors.
   */
  public enum AllianceType {
    /** Red alliance — field coordinates are mirrored. */
    RED,
    /** Blue alliance — field coordinates are used as-is. */
    BLUE,
  }

  private static final Tunable<Boolean> isRed = Tunable.ofBoolean("AllianceUtil/IsRed", true);
  private static AllianceType cachedType = null;
  private static int version = 0;

  /**
   * Re-reads the tunable alliance flag and bumps {@link #version} if it disagrees with the
   * cached type. Called internally by every read so the version stays current no matter which
   * method a caller happens to poll through.
   */
  private static void poll() {
    AllianceType current = isRed.getValue() ? AllianceType.RED : AllianceType.BLUE;
    if (current != cachedType) {
      cachedType = current;
      version++;
    }
  }

  /**
   * Returns the currently configured alliance type.
   *
   * @return {@link AllianceType#RED} or {@link AllianceType#BLUE}
   */
  public static AllianceType getAllianceType() {
    poll();
    return cachedType;
  }

  /**
   * Returns a counter that increments every time the alliance actually changes. Unlike a
   * consuming {@code hasChanged()} check, this never resets on read, so any number of callers can
   * independently detect a change by comparing this against their own private "last seen"
   * field — nobody's read steals the change event from anyone else.
   *
   * @return the current alliance-change generation number
   */
  public static int getVersion() {
    poll();
    return version;
  }
}
