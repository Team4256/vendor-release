package org.cyborgcats.vision;

import java.util.List;

import org.opencv.core.Point;

/**
 * A single AprilTag detection: fiducial ID and its four corner points in image space, ordered as
 * PhotonVision/AprilTag reports them (starting at the corner nearest the tag's bottom-left,
 * counter-clockwise).
 *
 * @param id      fiducial ID of the detected tag
 * @param corners detected image-space corners, in PhotonVision/AprilTag order
 */
public record AprilTagDetection(int id, List<Point> corners) {
  /** Number of corner points per tag detection. */
  public static final int pointsPerTag = 4;

  /**
   * @param id      fiducial ID of the detected tag
   * @param corners detected image-space corners, in PhotonVision/AprilTag order
   * @throws IllegalArgumentException if {@code corners} doesn't have exactly {@link #pointsPerTag} entries
   */
  public AprilTagDetection {
    if (corners.size() != pointsPerTag) {
      throw new IllegalArgumentException("expected " + pointsPerTag + " corners, got " + corners.size());
    }
  }
}
