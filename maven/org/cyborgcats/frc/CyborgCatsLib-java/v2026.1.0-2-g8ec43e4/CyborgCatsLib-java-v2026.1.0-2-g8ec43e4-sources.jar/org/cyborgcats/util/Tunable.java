package org.cyborgcats.util;

import edu.wpi.first.math.geometry.Pose3d;
import edu.wpi.first.math.geometry.Rotation3d;
import edu.wpi.first.math.geometry.Translation3d;
import edu.wpi.first.networktables.BooleanPublisher;
import edu.wpi.first.networktables.BooleanSubscriber;
import edu.wpi.first.networktables.BooleanTopic;
import edu.wpi.first.networktables.DoublePublisher;
import edu.wpi.first.networktables.DoubleSubscriber;
import edu.wpi.first.networktables.DoubleTopic;
import edu.wpi.first.networktables.FloatPublisher;
import edu.wpi.first.networktables.FloatSubscriber;
import edu.wpi.first.networktables.FloatTopic;
import edu.wpi.first.networktables.IntegerPublisher;
import edu.wpi.first.networktables.IntegerSubscriber;
import edu.wpi.first.networktables.IntegerTopic;
import edu.wpi.first.networktables.NetworkTable;
import edu.wpi.first.networktables.NetworkTableEvent;
import edu.wpi.first.networktables.NetworkTableInstance;
import edu.wpi.first.networktables.StringPublisher;
import edu.wpi.first.networktables.StringSubscriber;
import edu.wpi.first.networktables.StringTopic;
import edu.wpi.first.math.util.Units;

import java.util.EnumSet;
import java.util.function.Consumer;

/**
 * A value that is published to and continuously updated from NetworkTables, allowing live
 * adjustment without redeploying robot code.
 *
 * @param <T> the value type, e.g. {@link Double} or {@link Boolean}
 */
public class Tunable<T> {

  protected T value;
  protected T lastValue;
  protected String name;
  protected int valueListenerHandle;
  protected Consumer<T> networkPublisher;

  protected static final NetworkTableInstance inst =
    NetworkTableInstance.getDefault();

  protected static final NetworkTable table =
    NetworkTableInstance.getDefault().getTable("Tunable");

  /**
   * Creates a tunable with the given default value. Subclasses/factories are responsible for
   * wiring up the NetworkTables topic, subscriber, publisher, and listener for {@code T}.
   *
   * @param name         NetworkTable entry key (under the "Tunable" table)
   * @param defaultValue initial default value
   */
  protected Tunable (String name, T defaultValue) {
    this.name = name;
    this.value = defaultValue;
  }

  /**
   * Returns the current value, reflecting any updates received from NetworkTables.
   *
   * @return the current value
   */
  public T getValue() {
    return value;
  }

  /**
   * Sets the current value and republishes it to NetworkTables so other clients
   * (e.g. a dashboard) see the update.
   *
   * @param value the new value
   */
  public void setValue(T value) {
    this.value = value;
    if (networkPublisher != null) {
      networkPublisher.accept(value);
    }
  }

  /**
   * Returns {@code true} if the value has changed since the last call to this method.
   * Useful for detecting when to re-apply tuned gains or limits to hardware.
   *
   * @return {@code true} if the value changed since the previous call
   */
  public boolean hasChanged() {
    boolean hasChanged = !value.equals(lastValue);
    updateLastValue();
    return hasChanged;
  }

  /**
   * Records the current value as the baseline for the next {@link #hasChanged()} check.
   */
  private void updateLastValue() {
    lastValue = value;
  }

  /**
   * Creates a {@code Tunable<Double>} that publishes to and subscribes from the
   * {@code Tunable} NetworkTable.
   *
   * @param name         NetworkTable entry key (under the "Tunable" table)
   * @param defaultValue initial default value
   * @return the newly created tunable double
   */
  public static Tunable<Double> ofDouble(String name, double defaultValue) {
    Tunable<Double> tunable = new Tunable<>(name, defaultValue);

    DoubleTopic topic = table.getDoubleTopic(name);
    DoubleSubscriber sub = topic.subscribe(defaultValue);
    DoublePublisher pub = topic.publish();
    pub.set(defaultValue);
    tunable.networkPublisher = pub::set;

    tunable.valueListenerHandle = inst.addListener(
      sub,
      EnumSet.of(NetworkTableEvent.Kind.kValueAll),
      event -> tunable.value = event.valueData.value.getDouble()
    );

    return tunable;
  }

  /**
   * Creates a {@code Tunable<Boolean>} that publishes to and subscribes from the
   * {@code Tunable} NetworkTable.
   *
   * @param name         NetworkTable entry key (under the "Tunable" table)
   * @param defaultValue initial default value
   * @return the newly created tunable boolean
   */
  public static Tunable<Boolean> ofBoolean(String name, boolean defaultValue) {
    Tunable<Boolean> tunable = new Tunable<>(name, defaultValue);

    BooleanTopic topic = table.getBooleanTopic(name);
    BooleanSubscriber sub = topic.subscribe(defaultValue);
    BooleanPublisher pub = topic.publish();
    pub.set(defaultValue);
    tunable.networkPublisher = pub::set;

    tunable.valueListenerHandle = inst.addListener(
      sub,
      EnumSet.of(NetworkTableEvent.Kind.kValueAll),
      event -> tunable.value = event.valueData.value.getBoolean()
    );

    return tunable;
  }

  /**
   * Creates a {@code Tunable<Long>} that publishes to and subscribes from the
   * {@code Tunable} NetworkTable.
   *
   * @param name         NetworkTable entry key (under the "Tunable" table)
   * @param defaultValue initial default value
   * @return the newly created tunable long
   */
  public static Tunable<Long> ofLong(String name, long defaultValue) {
    Tunable<Long> tunable = new Tunable<>(name, defaultValue);

    IntegerTopic topic = table.getIntegerTopic(name);
    IntegerSubscriber sub = topic.subscribe(defaultValue);
    IntegerPublisher pub = topic.publish();
    pub.set(defaultValue);
    tunable.networkPublisher = pub::set;

    tunable.valueListenerHandle = inst.addListener(
      sub,
      EnumSet.of(NetworkTableEvent.Kind.kValueAll),
      event -> tunable.value = event.valueData.value.getInteger()
    );

    return tunable;
  }

  /**
   * Creates a {@code Tunable<Float>} that publishes to and subscribes from the
   * {@code Tunable} NetworkTable.
   *
   * @param name         NetworkTable entry key (under the "Tunable" table)
   * @param defaultValue initial default value
   * @return the newly created tunable float
   */
  public static Tunable<Float> ofFloat(String name, Float defaultValue) {
    Tunable<Float> tunable = new Tunable<Float>(name, defaultValue);

    FloatTopic topic = table.getFloatTopic(name);
    FloatSubscriber sub = topic.subscribe(defaultValue);
    FloatPublisher pub = topic.publish();
    pub.set(defaultValue);
    tunable.networkPublisher = pub::set;

    tunable.valueListenerHandle = inst.addListener(
      sub,
      EnumSet.of(NetworkTableEvent.Kind.kValueAll),
      event -> tunable.value = event.valueData.value.getFloat()
    );

    return tunable;
  }

  /**
   * Creates a {@code Tunable<String>} that publishes to and subscribes from the
   * {@code Tunable} NetworkTable.
   *
   * @param name         NetworkTable entry key (under the "Tunable" table)
   * @param defaultValue initial default value
   * @return the newly created tunable string
   */
  public static Tunable<String> ofString(String name, String defaultValue) {
    Tunable<String> tunable = new Tunable<String>(name, defaultValue);

    StringTopic topic = table.getStringTopic(name);
    StringSubscriber sub = topic.subscribe(defaultValue);
    StringPublisher pub = topic.publish();
    pub.set(defaultValue);
    tunable.networkPublisher = pub::set;

    tunable.valueListenerHandle = inst.addListener(
      sub,
      EnumSet.of(NetworkTableEvent.Kind.kValueAll),
      event -> tunable.value = event.valueData.value.getString()
    );

    return tunable;
  }

  /**
   * Creates a {@code Tunable<Pose3d>} by composing six underlying {@code Tunable<Double>}
   * values (x/y/z/roll/pitch/yaw), each published under its own NetworkTables entry
   * nested beneath {@code name}.
   *
   * @param name         NetworkTable entry key prefix (under the "Tunable" table)
   * @param defualtValue initial default value
   * @return the newly created tunable pose
   */
  public static Tunable<Pose3d> ofPose3d(String name, Pose3d defualtValue) {
    Tunable<Double> x = ofDouble(name + "/x", defualtValue.getX());
    Tunable<Double> y = ofDouble(name + "/y", defualtValue.getY());
    Tunable<Double> z = ofDouble(name + "/z", defualtValue.getZ());
    Tunable<Double> roll = ofDouble(name + "/roll", Units.radiansToDegrees(defualtValue.getRotation().getX()));
    Tunable<Double> yaw = ofDouble(name + "/yaw", Units.radiansToDegrees(defualtValue.getRotation().getZ()));
    Tunable<Double> pitch = ofDouble(name + "/pitch", Units.radiansToDegrees(defualtValue.getRotation().getY()));


    return new Tunable<Pose3d>(name, defualtValue) {
      @Override
      public Pose3d getValue() {
        value = new Pose3d(
          new Translation3d(x.getValue(), y.getValue(), z.getValue()),
          new Rotation3d(
            Units.degreesToRadians(roll.getValue()),
            Units.degreesToRadians(pitch.getValue()),
            Units.degreesToRadians(yaw.getValue())
          )
        );
        return value;
      }

      @Override
      public void setValue(Pose3d newValue) {
        Translation3d newTranslation = newValue.getTranslation();
        Rotation3d newRotation = newValue.getRotation();
        x.setValue(newTranslation.getX());
        y.setValue(newTranslation.getY());
        z.setValue(newTranslation.getZ());
        roll.setValue(Units.radiansToDegrees(newRotation.getX()));
        pitch.setValue(Units.radiansToDegrees(newRotation.getY()));
        yaw.setValue(Units.radiansToDegrees(newRotation.getZ()));
        value = newValue;
      }
      
      @Override
      public boolean hasChanged() {
        getValue();
        return super.hasChanged();
      }
    };
  }
}
