package org.cyborgcats.component;

import edu.wpi.first.math.MathUtil;
import edu.wpi.first.math.geometry.Pose2d;
import edu.wpi.first.math.geometry.Pose3d;
import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.math.geometry.Transform2d;
import edu.wpi.first.math.geometry.Transform3d;
import edu.wpi.first.math.geometry.Translation2d;
import edu.wpi.first.math.kinematics.ChassisSpeeds;
import edu.wpi.first.wpilibj.Alert;
import edu.wpi.first.wpilibj.Alert.AlertType;
import java.util.Optional;
import java.util.function.DoubleSupplier;
import java.util.function.Supplier;
import org.cyborgcats.io.motor.MotorIOConfiguration;
import org.cyborgcats.io.sensor.encoder.EncoderIOConfiguration;
import org.cyborgcats.util.LowPassFilter;
import org.cyborgcats.util.Range;
import org.littletonrobotics.junction.AutoLog;
import org.littletonrobotics.junction.Logger;

/**
 * Position component for a turret, adding absolute-position resolution from a pair of encoders and
 * aiming helpers that compensate for robot motion.
 *
 * <p>The turret's absolute angle cannot be recovered from either encoder alone, since each wraps
 * well before the turret completes a revolution. The two encoder gears have different tooth counts,
 * so their combined readings identify a unique turret angle over the full travel range; this is
 * resolved once at construction with a Chinese Remainder Theorem search. If no solution is found an
 * {@link Alert} is raised and the turret keeps its power-on position.
 *
 * <p>The aiming helpers assume the turret's rotation axis is vertical, which holds while the robot
 * is on flat ground; the tilted-chassis case is not yet implemented.
 *
 * <p>Commanded angles are wrapped into the range bounded by {@code minAngle} and {@code maxAngle},
 * so a target behind the turret is reached by continuing around rather than by reversing.
 */
public class Turret extends PositionComponent {

  /** Encoder on the first reduction gear, used as one CRT residue. */
  private final Encoder encoderOne;

  /** Encoder on the second reduction gear, whose differing tooth count disambiguates the first. */
  private final Encoder encoderTwo;

  /** Supplies the robot's current field-relative chassis speeds, used for motion compensation. */
  private final Supplier<ChassisSpeeds> speeds;

  /** Supplies the robot's current field-relative pose. */
  private final Supplier<Pose3d> robotPose;

  /** Pose of the turret's rotation axis relative to the robot origin. */
  private final Transform3d turretOffset;

  /** Minimum angle the turret can rotate to. */
  private final double minAngle;

  /** Maximum angle the turret can rotate to. */
  private final double maxAngle;

  private final double tolerance;
  
  private final int turretToothCount;

  private final LowPassFilter lowPassFilter;

  private final TurretInputsAutoLogged turretInputs = new TurretInputsAutoLogged();

  /**
   * Aiming solution for a single target, pairing the turret setpoint with the shot distance that
   * downstream mechanisms (hood angle, flywheel speed) interpolate against.
   *
   * @param virtualTarget field position aimed at, compensated for robot motion
   * @param distance      range from the turret to the motion-compensated virtual target
   */
  public record TurretOutput(Pose2d virtualTarget, double distance) {}

  /** Pre-filter turret setpoint, logged alongside the motor inputs rather than as an output. */
  @AutoLog
  public static class TurretInputs {
    public double wrappedSetpoint = 0.0;
  }

  /**
   * Constructs a Turret component and resolves its absolute starting position from both encoders.
   *
   * @param name                unique name used as the AdvantageKit logging key under "mechanisms/"
   * @param threshold           angular tolerance used to determine whether the turret is at a
   *                            target position
   * @param debounceTime        how long (in seconds) the turret must continuously be within threshold
   *                            before the at-position check returns {@code true}
   * @param encoderOneConf      configuration for the encoder on the first reduction gear; its sim
   *                            implementation is driven off the turret's own rotation automatically
   * @param encoderTwoConf      configuration for the encoder on the second reduction gear; must
   *                            have a different tooth count than encoder one for the CRT solve to
   *                            be unique
   * @param range               minimum and maximum angle the turret can rotate to
   * @param tolerance           how close (in rotations) a CRT candidate must be to encoder two's
   *                            reading to be accepted; size to the encoders' combined noise
   * @param turretToothCount    tooth count of the gear fixed to the turret that both encoder
   *                            gears mesh with
   * @param driveState          suppliers of the robot's field-relative chassis speeds and pose
   * @param turretOffset        pose of the turret's rotation axis relative to the robot origin
   * @param leader              configuration used to build the hardware interface for the turret motor
   */
  public Turret(
    String name,
    double threshold,
    double debounceTime,
    EncoderIOConfiguration encoderOneConf,
    EncoderIOConfiguration encoderTwoConf,
    Range range,
    double tolerance,
    int turretToothCount,
    double k,
    DriveState driveState,
    Pose3d turretOffset,
    MotorIOConfiguration leader
  ) {
    super(name, threshold, debounceTime, leader);

    DoubleSupplier turretRotations = () -> leaderInputs.position * turretToothCount;
    this.encoderOne = new Encoder(name + " Encoder One", encoderOneConf.withRotations(turretRotations));
    this.encoderTwo = new Encoder(name + " Encoder Two", encoderTwoConf.withRotations(turretRotations));

    this.speeds = driveState.fieldRelativeSpeeds();
    this.robotPose = driveState.robotPose();
    this.turretOffset = new Transform3d(
      turretOffset.getTranslation(),
      turretOffset.getRotation()
    );

    this.minAngle = range.min();
    this.maxAngle = range.max();
    this.tolerance = tolerance;
    this.turretToothCount = turretToothCount;

    lowPassFilter = new LowPassFilter(k);

    applyPositionOffset();
  }

  /**
   * Reads and logs the turret motor inputs along with both encoders.
   */
  @Override
  public void updateInputs() {
    super.updateInputs();
    encoderOne.updateInputs();
    encoderTwo.updateInputs();
  }

  /**
   * Returns both the turret setpoint and the shot distance for the given target, so callers that
   * also drive a hood or flywheel do not have to recompute the aiming solution.
   *
   * <p>The reported distance is measured from the turret's rotation axis to the motion-compensated
   * virtual target, not to the target's true position, so it stays consistent with the angle the
   * turret is being sent to. Carries the class-level flat-ground assumption and wraps the angle into
   * the turret's range identically.
   *
   * @param targetPose the actual target pose on the field
   * @param tof        expected projectile time-of-flight in seconds
   * @return the turret setpoint and the range it was solved for
   */
  public TurretOutput aimForTarget2D(Pose2d targetPose, double tof) {
    Pose2d turretPose = getTurretPose().toPose2d();

    Translation2d virtualTarget = getVirtualTarget2D(
      targetPose,
      speeds.get(),
      tof
    );

    Rotation2d targetAngle = virtualTarget
      .minus(turretPose.getTranslation())
      .getAngle();

    Rotation2d deltaAngle = targetAngle.minus(turretPose.getRotation());

    double wrappedAngle = MathUtil.inputModulus(
      (deltaAngle.getDegrees() / 360.0),
      minAngle,
      maxAngle
    );

    turretInputs.wrappedSetpoint = wrappedAngle;
    Logger.processInputs("Components/" + name + "/Turret", turretInputs);

    double filteredAngle = lowPassFilter.calculate(wrappedAngle);

    Setpoint turretSetpoint = Setpoint.withPosition(filteredAngle);

    double distance = virtualTarget.getDistance(turretPose.getTranslation());

    applySetpoint(turretSetpoint);

    return new TurretOutput(
      new Pose2d(virtualTarget, new Rotation2d()),
      distance
    );
  }

  /**
   * Returns the field-relative pose of the turret's rotation axis, composing the robot's current
   * pose with the turret's mounting offset.
   *
   * @return the turret's rotation axis in field coordinates
   */
  public Pose3d getTurretPose() {
    return robotPose.get().transformBy(turretOffset);
  }
  
  public void setLowPassFilterK(double k) {
    lowPassFilter.setK(k);
  }

  public void applyPositionOffset() {
    Optional<Double> positionOffset = solveChineaseRemainderTherom(
      encoderTwo.getInputs().absPosition,
      encoderOne.getInputs().absPosition,
      encoderTwo.getToothCount(),
      encoderOne.getToothCount(),
      tolerance,
      turretToothCount
    );

    if (!positionOffset.isPresent()) {
      @SuppressWarnings("resource")
      Alert turretOffsetAlert = new Alert(
        "Turret offset could not be resolved",
        AlertType.kError
      );
      turretOffsetAlert.set(true);
    } else {
      setCurrentPosition(positionOffset.get());
    }
  }

  /**
   * Returns the field position to aim at so that a projectile still reaches the target despite the
   * robot's own motion.
   *
   * <p>The target is shifted against the robot's velocity multiplied by the time-of-flight,
   * producing a "virtual target"; aiming at the virtual target cancels the velocity the projectile
   * inherits from the robot. Because {@code tof} is supplied rather than derived, the caller is
   * responsible for keeping it consistent with the resulting shot distance.
   *
   * <p>The result is a field position, not a displacement, so it does not depend on where the robot
   * sits; subtract the aiming origin from it to get the bearing and range. With a {@code tof} of
   * zero it is exactly {@code targetPose}'s translation.
   *
   * @param targetPose the actual target pose on the field
   * @param speeds     current field-relative chassis speeds of the robot
   * @param tof        expected projectile time-of-flight in seconds
   * @return the field position of the motion-compensated virtual target
   */
  public static Translation2d getVirtualTarget2D(
    Pose2d targetPose,
    ChassisSpeeds speeds,
    double tof
  ) {
    double xVector = speeds.vxMetersPerSecond * tof;
    double yVector = speeds.vyMetersPerSecond * tof;

    Translation2d xy = new Translation2d(xVector, yVector).times(-1);

    Transform2d transformVector = new Transform2d(xy, new Rotation2d());

    Pose2d virtualTarget = targetPose.transformBy(transformVector);
    return virtualTarget.getTranslation();
  }

  /**
   * Attempts to find the unique absolute turret position (in rotations) that satisfies the
   * readings from two encoders with different tooth counts relative to the turret gear.
   *
   * <p>The two encoder gear tooth counts must be coprime for the solution to be unique; the
   * unambiguous range this can resolve over is {@code lcm(e1ToothCount, e2ToothCount) /
   * turretToothCount} rotations, centered on zero.
   *
   * @param a                normalised position reading from encoder 1 (range [0, 1))
   * @param b                normalised position reading from encoder 2 (range [0, 1))
   * @param e1ToothCount     tooth count of the first encoder gear
   * @param e2ToothCount     tooth count of the second encoder gear
   * @param tolerance        how close the CRT candidate must be to encoder 2's effective reading
   *                         (in rotations) to be accepted as a solution
   * @param turretToothCount tooth count of the gear fixed to the turret that both encoder gears
   *                         mesh with
   * @return an {@link Optional} containing the resolved position in rotations, or empty if no
   * solution was found within the search range
   */
  public static Optional<Double> solveChineaseRemainderTherom(
    double a,
    double b,
    int e1ToothCount,
    int e2ToothCount,
    double tolerance,
    int turretToothCount
  ) {
    double m1 = (double) e1ToothCount / turretToothCount;
    double m2 = (double) e2ToothCount / turretToothCount;
    double r1 = a * m1;
    double r2 = b * m2;

    int lcm = e1ToothCount / gcd(e1ToothCount, e2ToothCount) * e2ToothCount;
    double range = (double) lcm / turretToothCount;
    int iterations = (int) Math.round(range / m1);

    double bestAngle = 0.0;
    double bestError = Double.POSITIVE_INFINITY;

    for (int i = 0; i < iterations; ++i) {
      double angle = r1 + (i * m1);
      double d = Math.abs((angle % m2) - r2);
      d = Math.min(d, m2 - d);
      if (d < bestError) {
        bestError = d;
        bestAngle = angle;
      }
    }

    if (bestError < tolerance) {
      if (bestAngle >= range / 2.0) {
        bestAngle -= range;
      }
      return Optional.of(bestAngle);
    }

    return Optional.empty();
  }

  /**
   * Returns the greatest common divisor of two positive integers via the Euclidean algorithm.
   */
  private static int gcd(int a, int b) {
    return b == 0 ? a : gcd(b, a % b);
  }
}
