package org.cyborgcats.vision;

import java.util.Optional;

import org.cyborgcats.jni.AprilTagEstimatorJNI;

import edu.wpi.first.math.geometry.Transform3d;

/**
 * Wraps the native AprilTag pose-solve JNI bindings, translating between this package's Java
 * types and {@link AprilTagEstimatorJNI}.
 */
public class AprilTagEstimator implements AutoCloseable {

  private final AprilTagEstimatorJNI estimator;

  /**
   * @param matrix     camera intrinsics
   * @param distCoeffs lens distortion coefficients
   * @param resolution image resolution
   * @throws IllegalStateException if {@link AprilTagField#initialize} has not been called yet
   */
  public AprilTagEstimator(
    CameraMatrix matrix,
    DistortionCoefficients distCoeffs,
    CameraResolution resolution
  ) {
    estimator = new AprilTagEstimatorJNI(
        matrix.toArray(),
        distCoeffs.toArray(),
        resolution.width(),
        resolution.height(),
        AprilTagField.getInstance().getLayout()
    );
  }

  /**
   * Solves for camera pose via PnP using the detected tag corners.
   *
   * @param detections detected AprilTag corners for the frame to solve
   * @param timestamp  capture timestamp of the frame {@code detections} came from
   * @return the resolved pose estimate, or empty if the solve failed
   */
  public Optional<AprilTagEstimate> getTagEstimatePNP(AprilTagDetections detections, double timestamp) {
    return estimator.solvePnP(detections.ids(), detections.corners(), AprilTagDetection.pointsPerTag)
        .map(estimate -> AprilTagEstimate.from(estimate, timestamp));
  }

  /**
   * Solves for camera pose using the trigonometric (single-tag, gyro-assisted) solve.
   *
   * @param detections         detected AprilTag corners for the frame to solve
   * @param cameraToRobot      transform from camera to robot origin
   * @param gyroHeadingRadians current robot heading from the gyro, in radians
   * @param timestamp          capture timestamp of the frame {@code detections} came from
   * @return the resolved pose estimate, or empty if the solve failed
   */
  public Optional<AprilTagEstimate> getTagEstimateTrig(
      AprilTagDetections detections, Transform3d cameraToRobot, double gyroHeadingRadians,
      double timestamp) {
    return estimator.solveTrig(
        detections.ids(), detections.corners(), AprilTagDetection.pointsPerTag,
        cameraToRobot, gyroHeadingRadians)
        .map(estimate -> AprilTagEstimate.from(estimate, timestamp));
  }

  /** Releases native resources held by the underlying JNI estimator. */
  @Override
  public void close() {
    estimator.close();
  }

}
