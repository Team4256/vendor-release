package org.cyborgcats.component;



import org.littletonrobotics.junction.Logger;

import org.cyborgcats.io.vision.VisionCameraIO;
import org.cyborgcats.io.vision.VisionCameraIOConfiguration;
import org.cyborgcats.io.vision.VisionCameraInputsAutoLogged;
import org.cyborgcats.vision.VisionResult;

/**
 * Component wrapper for a vision camera hardware interface, handling input updates and
 * AdvantageKit logging.
 */
public class VisionCamera {
  private final VisionCameraIO io;
  private final String name;
  private final VisionCameraInputsAutoLogged inputs = new VisionCameraInputsAutoLogged();

  /**
   * Constructs a VisionCamera component.
   *
   * @param name unique name used as the AdvantageKit logging key under "Vision/"
   * @param conf configuration used to build the underlying {@link VisionCameraIO} implementation
   */
  public VisionCamera(String name, VisionCameraIOConfiguration conf) {
    this.name = name;
    this.io = conf.build();
  }

  /**
   * Reads and logs vision camera data via AdvantageKit.
   * Inputs are logged under {@code "Vision/<name>"}.
   */
  public void updateInputs() {
    io.updateInputs(inputs);
    Logger.processInputs("Vision/" + name, inputs);
  }

  /**
   * @return all vision pose measurements accumulated since the last call, in capture order
   */
  public VisionResult[] getUnreadResults() {
    return io.getVisionResults();
  }

  /**
   * Refreshes and returns this camera's inputs, logging them as a side effect.
   *
   * @return the logged vision camera inputs object
   */
  public VisionCameraIO.VisionCameraInputs getInputs() {
    updateInputs();
    return inputs;
  }
}
