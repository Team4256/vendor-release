package org.cyborgcats.field;

import java.util.ArrayList;

import org.cyborgcats.subsystem.Subsystem;

/**
 * Global registry that collects {@link FieldElement} instances and publishes their current
 * alliance-corrected values to AdvantageKit every loop iteration.
 */
public class FieldElementRegistry extends Subsystem {

  private static final ArrayList<FieldElement<?>> elements = new ArrayList<>();
  private static FieldElementRegistry instance = null;
  private boolean hasLoggedOnceFlag = false;
  private int lastSeenAllianceVersion = -1;

  private FieldElementRegistry() {
    super();
  }

  /**
   * Lazily creates the singleton {@link FieldElementRegistry} instance, if one doesn't already
   * exist, so that it self-registers with {@link Subsystem} and starts receiving
   * {@link #periodic()} calls. Callers never need to construct one themselves.
   */
  private static void initialize() {
    if (instance == null) {
      instance = new FieldElementRegistry();
    }
  }

  /**
   * Registers a {@link FieldElement} to be logged every loop, initializing the singleton
   * registry instance on first use if necessary.
   *
   * @param element the field element to register
   */
  static void register(FieldElement<?> element) {
    initialize();
    elements.add(element);
  }

  /**
   * Logs every registered {@link FieldElement}'s current alliance-corrected value. Called every
   * robot loop iteration via {@link Subsystem#runPeriodic()}.
   */
  @Override
  public void periodic() {
    int currentAllianceVersion = AllianceSelector.getVersion();
    boolean allianceChanged = currentAllianceVersion != lastSeenAllianceVersion;
    lastSeenAllianceVersion = currentAllianceVersion;

    if (!hasLoggedOnceFlag || allianceChanged) {
      elements.forEach(FieldElement::log);
      hasLoggedOnceFlag = true;
    }
  }
}
