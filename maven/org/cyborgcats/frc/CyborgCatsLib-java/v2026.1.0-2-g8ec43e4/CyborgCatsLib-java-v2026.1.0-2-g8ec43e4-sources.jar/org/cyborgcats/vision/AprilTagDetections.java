package org.cyborgcats.vision;

import java.util.List;

import org.opencv.core.Point;

/**
 * A batch of {@link AprilTagDetection}s from a single camera frame, with the ability to flatten
 * itself into the raw {@code int[]}/{@code float[]} arrays the native {@code solvePnP}/{@code
 * solveTrig} JNI calls expect.
 */
public record AprilTagDetections(List<AprilTagDetection> detections) {
  /** @return fiducial IDs, one per detection, in list order */
  public int[] ids() {
    int[] ids = new int[detections.size()];
    for (int i = 0; i < detections.size(); i++) {
      ids[i] = detections.get(i).id();
    }
    return ids;
  }

  /** @return corners for all detections, interleaved as [x0, y0, x1, y1, ...] */
  public float[] corners() {
    float[] corners = new float[detections.size() * AprilTagDetection.pointsPerTag * 2];
    int i = 0;
    for (AprilTagDetection detection : detections) {
      for (Point corner : detection.corners()) {
        corners[i++] = (float) corner.x;
        corners[i++] = (float) corner.y;
      }
    }
    return corners;
  }
}
