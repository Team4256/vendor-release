package org.cyborgcats.vision;

/**
 * A vision measurement paired with the number of tags that contributed to it.
 *
 * @param measurment the vision pose measurement
 * @param tagCount   number of AprilTags that contributed to the measurement
 */
public record VisionResult (
    VisionMeasurment measurment,
    int tagCount
) {

}
