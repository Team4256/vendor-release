package org.cyborgcats.vision;

import edu.wpi.first.math.Matrix;
import edu.wpi.first.math.VecBuilder;
import edu.wpi.first.math.interpolation.InterpolatingDoubleTreeMap;
import edu.wpi.first.math.numbers.N1;
import edu.wpi.first.math.numbers.N3;

/**
 * Interpolated vision measurement standard deviations, keyed by total tag area. Populate with
 * {@link #add} at a handful of tag-area breakpoints, then call {@link #get} to interpolate
 * standard deviations for an arbitrary tag area.
 */
public class VisionStdDevs {
    private final InterpolatingDoubleTreeMap xMap = new InterpolatingDoubleTreeMap();
    private final InterpolatingDoubleTreeMap yMap = new InterpolatingDoubleTreeMap();
    private final InterpolatingDoubleTreeMap rotMap = new InterpolatingDoubleTreeMap();

    /** Constructs an empty {@code VisionStdDevs} with no breakpoints registered. */
    public VisionStdDevs() {

    }

    /**
     * Registers a standard deviation breakpoint at the given tag area.
     *
     * @param tagArea total on-screen tag area, as a fraction of the image area
     * @param x       standard deviation of the x measurement, in meters
     * @param y       standard deviation of the y measurement, in meters
     * @param rot     standard deviation of the rotation measurement, in radians
     * @return this, for chaining
     */
    public VisionStdDevs add(double tagArea, double x, double y, double rot) {
        xMap.put(tagArea, x);
        yMap.put(tagArea, y);
        rotMap.put(tagArea, rot);
        return this;
    }

    /**
     * @param tagArea total on-screen tag area, as a fraction of the image area
     * @return interpolated (x, y, rot) standard deviations for the given tag area
     */
    public Matrix<N3, N1> get(double tagArea) {
        return VecBuilder.fill(xMap.get(tagArea), yMap.get(tagArea), rotMap.get(tagArea));
    }
}
