package org.cyborgcats.util;

/**
 * A simple discrete PID controller that accepts a pre-computed error value and returns
 * the combined proportional, integral, and derivative output.
 */
public class PIDErrorController {
  private final double dt;
  private double kp;
  private double kd;
  private double ki;
  private double integrated_error = 0;
  private double lastError = 0;

  /**
   * Constructs a PIDErrorController with the given gains and time step.
   *
   * @param kp proportional gain
   * @param kd derivative gain
   * @param ki integral gain
   * @param dt loop period in seconds used for derivative and integral calculations
   */
  public PIDErrorController(double kp, double kd, double ki, double dt) {
    this.kp = kp;
    this.kd = kd;
    this.ki = ki;
    this.dt = dt;
  }

  /**
   * Sets the proportional gain.
   *
   * @param kp new proportional gain
   */
  public void setKp(double kp) {
    this.kp = kp;
  }

  /**
   * Sets the derivative gain.
   *
   * @param kd new derivative gain
   */
  public void setKd(double kd) {
    this.kd = kd;
  }

  /**
   * Sets the integral gain.
   *
   * @param ki new integral gain
   */
  public void setKi(double ki) {
    this.ki = ki;
  }

  /**
   * Resets the accumulated integral error to zero.
   */
  public void reset() {
    integrated_error = 0;
  }

  /**
   * Calculates and returns the PID output for the given error.
   *
   * @param error the current control error (setpoint − measurement)
   * @return the combined PID output
   */
  public double calculate(double error) {
    var derivative = (error - lastError) / dt;
    integrated_error += error * dt;
    lastError = error;
    return kp * error + kd * derivative + integrated_error * ki;
  }
}
