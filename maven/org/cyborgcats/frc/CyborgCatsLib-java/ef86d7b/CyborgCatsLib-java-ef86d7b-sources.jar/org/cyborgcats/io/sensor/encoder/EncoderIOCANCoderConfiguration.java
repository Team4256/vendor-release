package org.cyborgcats.io.sensor.encoder;

import java.util.function.DoubleSupplier;

import com.ctre.phoenix6.configs.CANcoderConfiguration;

/**
 * Configuration for a CANcoder-backed {@link EncoderIO}.
 */
public class EncoderIOCANCoderConfiguration implements EncoderIOConfiguration {
    private final int canID;
    private final CANcoderConfiguration conf;
    private final int toothCount;
    private final DoubleSupplier rotations;

    /**
     * Constructs an EncoderIOCANCoderConfiguration.
     *
     * @param canID      device ID of the CANcoder
     * @param conf       configuration applied to the CANcoder
     * @param toothCount tooth count of the gear this encoder rides on
     */
    public EncoderIOCANCoderConfiguration(int canID, CANcoderConfiguration conf, int toothCount) {
        this(canID, conf, toothCount, () -> 0.0);
    }

    public EncoderIOCANCoderConfiguration(int canID, CANcoderConfiguration conf, int toothCount, DoubleSupplier rotations) {
        this.canID = canID;
        this.conf = conf;
        this.toothCount = toothCount;
        this.rotations = rotations;
    }

    @Override
    public EncoderIOConfiguration withRotations(DoubleSupplier rotations) {
        return new EncoderIOCANCoderConfiguration(canID, conf, toothCount, rotations);
    }

    @Override
    public EncoderIO buildReal() {
        return new EncoderIOCANCoder(canID, toothCount, conf);
    }

    @Override
    public EncoderIO buildSim() {
        return new EncoderIOSim(rotations, toothCount);
    }
}
