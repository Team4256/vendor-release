package org.cyborgcats.component;


import org.littletonrobotics.junction.Logger;

import org.cyborgcats.io.sensor.encoder.EncoderIO;
import org.cyborgcats.io.sensor.encoder.EncoderIOConfiguration;
import org.cyborgcats.io.sensor.encoder.EncoderInputsAutoLogged;
/**
 * Component wrapper for an encoder hardware interface, handling input updates and AdvantageKit logging.
 */
public class Encoder implements Component {
  private final EncoderIO io;
  private final String name;
  private final EncoderInputsAutoLogged inputs = new EncoderInputsAutoLogged();

  /**
   * Constructs an Encoder component.
   *
   * @param name       unique name used as the AdvantageKit logging key under "Sensors/"
   * @param conf       configuration used to build this encoder's hardware interface
   */
  public Encoder(String name, EncoderIOConfiguration conf) {
    this.name = name;
    this.io = conf.build();
  }

  /**
   * Reads and logs encoder data via AdvantageKit.
   * Inputs are logged under {@code "Sensors/<name>"}.
   */
  @Override
  public void updateInputs() {
    io.updateInputs(inputs);
    Logger.processInputs("Sensors/" + name, inputs);
  }

  /**
   * Refreshes and returns this encoder's inputs, logging them as a side effect.
   *
   * @return the logged encoder inputs object
   */
  public EncoderIO.EncoderInputs getInputs() {
    updateInputs();
    return inputs;
  }

  /**
   * Returns the tooth count of the gear this encoder rides on.
   *
   * @return the tooth count
   */
  public int getToothCount() {
    return io.getToothCount();
  }
}
