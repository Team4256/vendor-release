package org.cyborgcats.component;



import org.littletonrobotics.junction.Logger;

import org.cyborgcats.io.vision.VisionCameraIO;
import org.cyborgcats.io.vision.VisionCameraInputsAutoLogged;

/**
 * Component wrapper for a vision camera hardware interface, handling input updates and
 * AdvantageKit logging.
 */
public class VisionCamera {
  private final VisionCameraIO io;
  private final String name;
  private final VisionCameraInputsAutoLogged inputs = new VisionCameraInputsAutoLogged();

  /**
   * Constructs a VisionCamera component.
   *
   * @param name unique name used as the AdvantageKit logging key under "Vision/"
   * @param io   hardware interface providing camera readings
   */
  public VisionCamera(String name, VisionCameraIO io) {
    this.name = name;
    this.io = io;
  }

  /**
   * Reads and logs vision camera data via AdvantageKit.
   * Inputs are logged under {@code "Vision/<name>"}.
   */
  public void updateInputs() {
    io.updateInputs(inputs);
    Logger.processInputs("Vision/" + name, inputs);
  }

  /**
   * Refreshes and returns this camera's inputs, logging them as a side effect.
   *
   * @return the logged vision camera inputs object
   */
  public VisionCameraIO.VisionCameraInputs getInputs() {
    updateInputs();
    return inputs;
  }
}
