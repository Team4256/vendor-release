package org.cyborgcats.componentViz;

import edu.wpi.first.math.geometry.Pose3d;
import edu.wpi.first.math.geometry.Rotation3d;
import edu.wpi.first.math.geometry.Transform3d;
import edu.wpi.first.math.geometry.Translation3d;

import java.util.Optional;
import java.util.function.Supplier;

import org.cyborgcats.util.Tunable;

/**
 * Represents a single visualizable robot component, encapsulating its name, 3D pose supplier,
 * optional parent component (for kinematic chaining), and rendering order.
 */
public class ComponentViz {

  private final String name;
  private final Supplier<Pose3d> pose;
  private final Optional<ComponentViz> parent;
  private final int order;

  /**
   * Constructs a ComponentViz with a parent for kinematic chaining.
   *
   * @param name   unique display name
   * @param pose   supplier returning the component's local-space pose
   * @param parent the parent component this pose is expressed relative to
   * @param order  rendering order index used to sort components before logging
   */
  public ComponentViz(
    String name,
    Supplier<Pose3d> pose,
    ComponentViz parent,
    int order
  ) {
    this.name = name;
    this.pose = pose;
    this.parent = Optional.ofNullable(parent);
    this.order = order;
  }

  /**
   * Constructs a root ComponentViz with no parent.
   *
   * @param name  unique display name
   * @param pose  supplier returning the component's world-space pose
   * @param order rendering order index used to sort components before logging
   */
  public ComponentViz(
    String name,
    Supplier<Pose3d> pose,
    int order
  ) {
    this(name, pose, null, order);
  }

  /**
   * Creates a ComponentViz with a parent whose pose is wired to live NetworkTable-tunable
   * x/y/z/roll/pitch/yaw values, enabling adjustment without redeployment.
   *
   * @param name   unique display name, also used as the NetworkTable key prefix
   * @param parent the parent component this pose is expressed relative to
   * @param order  rendering order index used to sort components before logging
   * @return the newly created ComponentViz
   */
  public static ComponentViz tunable(String name, ComponentViz parent, int order) {
    return new ComponentViz(name, tunablePose(name), parent, order);
  }

  /**
   * Creates a root ComponentViz whose pose is wired to live NetworkTable-tunable
   * x/y/z/roll/pitch/yaw values, enabling adjustment without redeployment.
   *
   * @param name  unique display name, also used as the NetworkTable key prefix
   * @param order rendering order index used to sort components before logging
   * @return the newly created ComponentViz
   */
  public static ComponentViz tunable(String name, int order) {
    return new ComponentViz(name, tunablePose(name), order);
  }

  private static Supplier<Pose3d> tunablePose(String name) {
    var x = Tunable.ofDouble("ComponentViz/" + name + "/x", 0.0);
    var y = Tunable.ofDouble("ComponentViz/" + name + "/y", 0.0);
    var z = Tunable.ofDouble("ComponentViz/" + name + "/z", 0.0);
    var roll = Tunable.ofDouble("ComponentViz/" + name + "/roll", 0.0);
    var pitch = Tunable.ofDouble("ComponentViz/" + name + "/pitch", 0.0);
    var yaw = Tunable.ofDouble("ComponentViz/" + name + "/yaw", 0.0);
    return () -> new Pose3d(
        new Translation3d(x.getValue(), y.getValue(), z.getValue()),
        new Rotation3d(roll.getValue(), pitch.getValue(), yaw.getValue())
    );
  }

  /**
   * Returns the unique display name of this component.
   *
   * @return the component name
   */
  public String getName() {
    return name;
  }

  /**
   * Returns a supplier that evaluates this component's world-space {@link Pose3d}.
   * If a parent component is set, the returned pose is expressed relative to the parent's pose.
   *
   * @return supplier of this component's world-space pose
   */
  public Supplier<Pose3d> getPose() {
    if (parent.isEmpty()) {
      return pose;
    }
    return () -> {
      Pose3d local = pose.get();
      return parent
        .get()
        .getPose()
        .get()
        .transformBy(
          new Transform3d(local.getTranslation(), local.getRotation())
        );
    };
  }

  /**
   * Returns the optional parent component whose pose this component's pose is relative to.
   *
   * @return an {@link Optional} containing the parent, or empty if this is a root component
   */
  public Optional<ComponentViz> getParent() {
    return parent;
  }

  /**
   * Returns the rendering order index; lower values are logged first in the pose array.
   *
   * @return the rendering order
   */
  public int getOrder() {
    return order;
  }
}
