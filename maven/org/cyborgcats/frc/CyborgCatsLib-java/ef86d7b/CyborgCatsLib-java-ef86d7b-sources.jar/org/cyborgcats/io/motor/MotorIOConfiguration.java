package org.cyborgcats.io.motor;

import org.cyborgcats.io.IOConfiguration;

/**
 * Shared shape for configs that build a {@link MotorIO}.
 */
public interface MotorIOConfiguration extends IOConfiguration<MotorIO> {
}
