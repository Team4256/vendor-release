package org.cyborgcats.component;

import org.cyborgcats.io.motor.MotorIOConfiguration;
import org.cyborgcats.ssm.State;

/**
 * Extension of {@link VelocityComponent} for flywheel-style shooters that blends open-loop spin-up
 * with closed-loop velocity holding.
 *
 * <p>While the wheel is still below its commanded speed the component runs full duty cycle to reach
 * the setpoint as quickly as possible, then hands off to the motor's closed-loop velocity control
 * once the wheel is at (or above) speed. See {@link #getControlType(double, double)} for the exact
 * switching rule.
 */
public class Flywheel extends VelocityComponent {

  /** Control strategies this shooter can select between while running. */
  public enum ControlType {
    /** Open-loop full duty cycle, used to spin the wheel up to speed. */
    BANGBANG,
    /** Closed-loop velocity control, used to hold the wheel at speed. */
    VELOCITY,
  }

  private final double bangbangThreshold;
  private final Setpoint.Mode mode;

  /**
   * Constructs a Flywheel.
   *
   * @param name              unique name used as the AdvantageKit logging key under "mechanisms/"
   * @param threshold         velocity tolerance used to determine whether the shooter is at a target speed
   * @param bangbangThreshold velocity tolerance used to decide when to switch from open-loop
   *                          spin-up to closed-loop velocity holding; see
   *                          {@link #getControlType(double, double)}
   * @param debounceTime      how long (in seconds) the shooter must continuously be within threshold
   *                          before the at-velocity check returns {@code true}
   * @param mode              control mode used to hold velocity once the wheel is at speed
   * @param leader            hardware interface for this motor
   * @param followers         hardware interfaces driven with the same control request as the leader; may be
   *                          omitted for a single-motor shooter
   */
  public Flywheel(
    String name,
    double threshold,
    double bangbangThreshold,
    double debounceTime,
    Setpoint.Mode mode,
    MotorIOConfiguration leader,
    MotorIOConfiguration... followers
  ) {
    super(name, threshold, debounceTime, leader, followers);
    this.bangbangThreshold = bangbangThreshold;
    this.mode = mode;
  }

  /**
   * Chooses the control strategy for the current loop.
   *
   * <p>Returns {@link ControlType#VELOCITY} when the shooter is already debounced-at-setpoint, or
   * when the measured velocity has reached or passed the setpoint; otherwise returns
   * {@link ControlType#BANGBANG} so the wheel keeps spinning up at full output.
   *
   * <p><b>Note:</b> this advances the shared {@link VelocityComponent} debouncer via
   * {@link VelocityComponent#nearVelocity(double, double)}, so calling it more than once per robot
   * loop distorts the debounce timing.
   *
   * @param target  intended target velocity
   * @param bangbangThreshold velocity tolerance used for the at-setpoint check
   * @return the control type to use this loop
   */
  public ControlType getControlType(
    double target,
    double bangbangThreshold
  ) {
    double diff =
      target - getInputs().velocity;
    if (nearVelocity(target, bangbangThreshold) || diff <= 0) {
      return ControlType.VELOCITY;
    } else {
      return ControlType.BANGBANG;
    }
  }

  /**
   * Chooses the control strategy for the current loop using the epsilon supplied at construction.
   *
   * @param target intended target velocity
   * @return the control type to use this loop
   */
  public ControlType getControlType(Double target) {
    return getControlType(target, bangbangThreshold);
  }

  /**
   * Builds the setpoint that should be applied to reach or hold the given velocity, selecting
   * between full duty cycle and closed-loop velocity control based on
   * {@link #getControlType(Double)}.
   *
   * @param velocity desired shooter velocity
   * @return a duty-cycle setpoint of 1.0 while spinning up, otherwise a velocity setpoint
   */
  public Setpoint getTargetSetpoint(double velocity) {
    ControlType controlType = getControlType(velocity);

    if (controlType == ControlType.BANGBANG) {
      return Setpoint.withDutyCycle(1.0);
    } else {
      return Setpoint.withMode(velocity, mode);
    }
  }

  /**
   * Computes and immediately applies the setpoint for the given velocity.
   *
   * <p>Intended to be called every loop: the control type is re-evaluated each call, so repeated
   * calls carry the shooter from spin-up through steady-state velocity holding.
   *
   * @param velocity desired shooter velocity
   */
  public void applyTargetSetpoint(double velocity) {
    Setpoint targetSetpoint = getTargetSetpoint(velocity);
    applySetpoint(targetSetpoint);
  }

  /**
   * Creates a one-shot {@link State} that applies the setpoint for the given velocity when
   * scheduled.
   *
   * <p>The state runs a single step, so it performs one spin-up/hold decision rather than driving
   * the shooter to speed on its own; schedule it repeatedly (or wrap it) to keep the shooter
   * commanded.
   *
   * @param velocity desired shooter velocity
   * @return the newly created state
   */
  public State applyTargetSetpointState(double velocity) {
    return State.withStep(() -> {
      applyTargetSetpoint(velocity);
    })
      .withName(this.name + " Target Setpoint")
      .isInterruptible(true)
      .withIgnoreDisable(false);
  }
}