package org.cyborgcats.io.sensor.encoder;

import org.littletonrobotics.junction.AutoLog;

/**
 * Interface defining how to communicate with absolute encoder hardware.
 */
public interface EncoderIO {
  /**
   * Updates the reported encoder inputs.
   *
   * @param inputs loggable encoder inputs to populate
   */
  void updateInputs(EncoderInputs inputs);

  int getToothCount();

  /**
   * AdvantageKit-loggable container of encoder telemetry fields.
   */
  @AutoLog
  class EncoderInputs {
    /**
     * Relative position of the encoder shaft (in rotations).
     */
    public double position = 0.0;
    /** Absolute position of the encoder shaft (in rotations, range [0, 1)). */
    public double absPosition = 0.0;
    /** Whether the encoder is detected on the bus. */
    public boolean connected = false;
  }
}
