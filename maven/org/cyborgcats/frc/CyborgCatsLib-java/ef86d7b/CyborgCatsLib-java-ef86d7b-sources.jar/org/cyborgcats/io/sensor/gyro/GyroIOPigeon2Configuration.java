package org.cyborgcats.io.sensor.gyro;

import java.util.function.Supplier;

import edu.wpi.first.math.kinematics.ChassisSpeeds;

/**
 * Configuration for a Pigeon2-backed {@link GyroIO}.
 */
public class GyroIOPigeon2Configuration implements GyroIOConfiguration {
    private final int canID;
    private final Supplier<ChassisSpeeds> chassisSpeeds;

    /**
     * Constructs a GyroIOPigeon2Configuration.
     *
     * @param canID         device ID of the Pigeon2
     * @param chassisSpeeds supplier of the robot's field-relative chassis speeds, used by the
     *                      simulated gyro to integrate heading
     */
    public GyroIOPigeon2Configuration(int canID, Supplier<ChassisSpeeds> chassisSpeeds) {
        this.canID = canID;
        this.chassisSpeeds = chassisSpeeds;
    }

    @Override
    public GyroIO buildReal() {
        return new GyroIOPigeon2(canID);
    }

    @Override
    public GyroIO buildSim() {
        return new GyroIOSim(chassisSpeeds);
    }
}
