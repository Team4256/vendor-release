package org.cyborgcats.subsystem;

import java.util.ArrayList;
import java.util.List;

import org.cyborgcats.component.VisionCamera;

/**
 * Subsystem that owns one or more {@link VisionCamera} components and calls
 * {@link VisionCamera#updateInputs()} on each every loop iteration.
 */
public class VisionSubsystem extends Subsystem {
  private final ArrayList<VisionCamera> visionCameras = new ArrayList<>();

  /**
   * Constructs a VisionSubsystem managing the provided cameras.
   *
   * @param visionCameras one or more cameras to update each periodic cycle
   */
  public VisionSubsystem(VisionCamera... visionCameras) {
    this.visionCameras.addAll(List.of(visionCameras));
  }

  /**
   * Reads and logs inputs from all registered vision cameras.
   */
  @Override
  public void periodic() {
    visionCameras.forEach(VisionCamera::updateInputs);
  }
}
