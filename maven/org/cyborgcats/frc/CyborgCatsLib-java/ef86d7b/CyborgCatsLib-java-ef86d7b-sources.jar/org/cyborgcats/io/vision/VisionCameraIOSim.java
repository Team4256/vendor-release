package org.cyborgcats.io.vision;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

import org.photonvision.PhotonCamera;
import org.photonvision.simulation.PhotonCameraSim;
import org.photonvision.simulation.SimCameraProperties;
import org.photonvision.simulation.VisionSystemSim;
import org.photonvision.targeting.TargetCorner;

import edu.wpi.first.apriltag.AprilTagFieldLayout;
import edu.wpi.first.apriltag.AprilTagFields;
import edu.wpi.first.math.MatBuilder;
import edu.wpi.first.math.Nat;
import edu.wpi.first.math.geometry.Pose3d;
import edu.wpi.first.math.geometry.Transform3d;

/**
 * Vision camera IO implementation using PhotonVision simulation.
 */
public class VisionCameraIOSim implements VisionCameraIO {
  private static final VisionSystemSim visionSim = new VisionSystemSim("main");
  private static boolean tagsLoaded = false;
  private final PhotonCamera photonCamera;
  private final Supplier<Transform3d> robotToCamera;
  private final Supplier<Pose3d> robotPose;

  /**
   * Constructs a VisionCameraIOSim, setting up a PhotonVision simulation camera with the
   * provided intrinsics and attaching it to the shared {@link VisionSystemSim}.
   *
   * @param cfg       camera configuration (name, resolution, intrinsics, robot-to-camera transform)
   * @param robotPose supplier returning the current simulated robot pose
   */
  public VisionCameraIOSim(
      VisionCfg cfg,
      Supplier<Pose3d> robotPose) {

    this.robotToCamera = cfg.robotToCamera();
    this.robotPose = robotPose;

    photonCamera = new PhotonCamera(cfg.name());

    double[] paddedDist = new double[8];
    System.arraycopy(cfg.distCoeffs(), 0, paddedDist, 0, Math.min(cfg.distCoeffs().length, 8));

    var camProps = new SimCameraProperties();
    camProps.setCalibration(
        cfg.width(), cfg.height(),
        MatBuilder.fill(Nat.N3(), Nat.N3(), cfg.cameraMatrix()),
        MatBuilder.fill(Nat.N8(), Nat.N1(), paddedDist)
    );
    camProps.setCalibError(0.0, 0.0);
    camProps.setFPS(120.0);
    camProps.setAvgLatencyMs(0.0);
    camProps.setLatencyStdDevMs(0.0);

    var cameraSim = new PhotonCameraSim(photonCamera, camProps);
    cameraSim.enableRawStream(true);
    cameraSim.enableProcessedStream(true);
    cameraSim.enableDrawWireframe(true);

    visionSim.addCamera(cameraSim, robotToCamera.get());

    if (!tagsLoaded) {
      visionSim.addAprilTags(AprilTagFieldLayout.loadField(AprilTagFields.kDefaultField));
      tagsLoaded = true;
    }
  }

  @Override
  public void updateInputs(VisionCameraInputs inputs) {
    inputs.connected = photonCamera.isConnected();
    visionSim.update(robotPose.get().toPose2d());

    var results = photonCamera.getAllUnreadResults();
    if (results.isEmpty()) return;

    var result = results.get(results.size() - 1);
    if (!result.hasTargets()) return;

    var targets = result.getTargets();
    int[] ids = new int[targets.size()];
    List<Float> cornerList = new ArrayList<>();

    for (int i = 0; i < targets.size(); i++) {
      var target = targets.get(i);
      ids[i] = target.getFiducialId();
      for (TargetCorner corner : target.getDetectedCorners()) {
        cornerList.add((float) corner.x);
        cornerList.add((float) corner.y);
      }
    }

    float[] corners = new float[cornerList.size()];
    for (int i = 0; i < corners.length; i++) corners[i] = cornerList.get(i);

    inputs.ids = ids;
    inputs.corners = corners;

  }
}
