package org.cyborgcats.ssm;

import edu.wpi.first.wpilibj.DriverStation;
import java.util.*;

/**
 * Singleton scheduler for the state-machine system (SSM) that manages the lifecycle of active
 * {@link State} objects and drives the button-polling loop each robot cycle.
 */
public class Scheduler {

  private static final Scheduler instance = new Scheduler();
  private static final Collection<Runnable> buttonLoop = new HashSet<>();
  private final List<State> activeStates = new ArrayList<>();

  private Scheduler() {}

  /**
   * Returns the singleton Scheduler instance.
   *
   * @return the global scheduler
   */
  public static synchronized Scheduler getInstance() {
    return instance;
  }

  /**
   * Returns the shared button-polling loop collection.
   * {@link StateTrigger} instances register their {@code poll()} callbacks here.
   *
   * @return the mutable button loop collection
   */
  public static synchronized Collection<Runnable> getButtonLoop() {
    return buttonLoop;
  }

  /**
   * Schedules a new state for execution.
   * If the state conflicts with a currently active state whose requirements overlap and that state
   * is not interruptible, the new state is silently dropped. Otherwise, conflicting states have
   * their {@link State#onInterrupt(Runnable)} callback invoked and their cleanup states (if any)
   * scheduled. {@link State#onEnd(Runnable)} is not invoked on this path.
   *
   * <p>While the robot is disabled, only states exempted via
   * {@link State#withIgnoreDisable(boolean)} are accepted; anything else is silently dropped
   * before any conflict is resolved, so a rejected state never interrupts a running one.
   *
   * @param newState the state to schedule; a {@code null} value is silently ignored
   */
  public final void schedule(State newState) {
    if (newState == null) return;
    if (activeStates.contains(newState)) return;

    if (DriverStation.isDisabled() && !newState.getIgnoreDisable()) return;

    // lists conflicts
    List<State> conflicts = activeStates
      .stream()
      .filter(
        state ->
          !Collections.disjoint(
            state.getRequirements(),
            newState.getRequirements()
          )
      )
      .toList();

    //checks if conflicts can be interrupted
    if (conflicts.stream().anyMatch(state -> !state.isInterruptible())) {
      return;
    }

    //
    List<State> cleanups = new ArrayList<>();
    conflicts.forEach(state -> {
      state.getInterrupt().ifPresent(Runnable::run);
      state.getCleanup().ifPresent(cleanups::add); // interrupted → cleanup
      state.end();
      state.reset();
    });
    activeStates.removeAll(conflicts);
    activeStates.add(newState);
    cleanups.forEach(this::schedule);
  }

  /**
   * Forcibly ends the given state and schedules its cleanup state (if any).
   * Has no effect if the state is not currently active.
   *
   * <p>Neither the state's {@link State#onEnd(Runnable)} nor its {@link State#onInterrupt(Runnable)}
   * callback is invoked; attach teardown logic to the cleanup state instead.
   *
   * <p>The cleanup state is scheduled through {@link #schedule(State)}, so while the robot is
   * disabled it runs only if it is itself exempt via {@link State#withIgnoreDisable(boolean)}.
   *
   * @param state the state to end
   */
  public final void end(State state) {
    if (activeStates.contains(state)) {
      Optional<State> cleanup = state.getCleanup(); // interrupted → cleanup
      state.end();
      state.reset();
      activeStates.remove(state);
      cleanup.ifPresent(this::schedule);
    }
  }

  /**
   * Advances all active states by one loop iteration, removes finished states (invoking their
   * {@link State#onEnd(Runnable)} callback and scheduling their finish states if defined), and then
   * runs every registered button-polling callback.
   * Should be called once per robot loop from {@code robotPeriodic}.
   *
   * <p>While the robot is disabled, every active state that is not
   * {@link State#withIgnoreDisable(boolean) exempt} is ended as if interrupted: its
   * {@link State#onInterrupt(Runnable)} callback runs and its cleanup state is offered to
   * {@link #schedule(State)}, which accepts the cleanup only if that cleanup is itself exempt.
   * Teardown that must survive a disable therefore has to be marked exempt as well.
   *
   * <p>The button loop still polls while disabled, so triggers keep their edge state in sync and
   * a condition held across the disable boundary does not fire a spurious edge on re-enable.
   *
   * <p>A step body may safely call {@link #schedule(State)} or {@link #end(State)} while this
   * method is running; a state scheduled that way first runs on the following loop.
   */
  public final void run() {
    List<State> finishes = new ArrayList<>();
    List<State> cleanups = new ArrayList<>();
    // sampled once so every state this loop sees the same enable status
    boolean disabled = DriverStation.isDisabled();

    // iterate a snapshot so a step body may call schedule() or end() without invalidating the loop
    // not inteded behavoir but prevents invalidating the loop while a step body is running
    for (State state : List.copyOf(activeStates)) {
      // an earlier body this loop may have interrupted or ended this state; don't restart it
      if (!activeStates.contains(state)) continue;

      if (disabled && !state.getIgnoreDisable()) {
        // treated as an interrupt so onInterrupt-based bookkeeping (e.g. StateTrigger toggles)
        // stays in sync across the disable boundary
        state.getInterrupt().ifPresent(Runnable::run);
        state.getCleanup().ifPresent(cleanups::add);
        state.end();
        state.reset();
        activeStates.remove(state);
        continue;
      }

      state.run();
      if (state.isFinished()) {
        state.getOnEnd().ifPresent(Runnable::run);
        state.getFinish().ifPresent(finishes::add); // finished naturally → onFinish
        state.end();
        state.reset();
        activeStates.remove(state);
      }
    }

    finishes.forEach(this::schedule);
    cleanups.forEach(this::schedule);
    buttonLoop.forEach(Runnable::run);
  }

  /**
   * Ends all currently active states without running cleanup or finish states, and without
   * invoking any {@link State#onEnd(Runnable)} or {@link State#onInterrupt(Runnable)} callbacks.
   */
  public final void endAll() {
    activeStates.forEach(state -> {
      state.end();
      state.reset();
    });
    activeStates.clear();
  }

  /**
   * Returns an unmodifiable view of all currently active states.
   *
   * @return an unmodifiable list of active states
   */
  public final List<State> getActiveStates() {
    return Collections.unmodifiableList(activeStates);
  }
}
