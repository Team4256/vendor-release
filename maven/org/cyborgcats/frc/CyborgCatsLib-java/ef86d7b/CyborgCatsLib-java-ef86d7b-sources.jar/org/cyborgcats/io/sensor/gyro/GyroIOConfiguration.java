package org.cyborgcats.io.sensor.gyro;

import org.cyborgcats.io.IOConfiguration;

/**
 * Shared shape for configs that build a {@link GyroIO}.
 */
public interface GyroIOConfiguration extends IOConfiguration<GyroIO> {
}
