package org.cyborgcats.util;

import edu.wpi.first.wpilibj.RobotController;
import org.littletonrobotics.junction.Logger;

import java.util.ArrayList;

import static edu.wpi.first.units.Units.*;

/**
 * Singleton that accumulates per-subsystem power and energy consumption estimates and logs
 * them to AdvantageKit each loop iteration.
 */
public class EnergyTracker {
  private static final EnergyTracker instance = new EnergyTracker();
  private final double loopTime = 0.02;
  private final ArrayList<EnergyObject> objects = new ArrayList<>();
  private double totalCurrent = 0;
  private double totalPower = 0;
  private double totalEnergy = 0;

  private EnergyTracker() {

  }

  /**
   * Returns the singleton EnergyTracker instance.
   *
   * @return the global energy tracker
   */
  public static EnergyTracker getInstance() {
    return instance;
  }

  /**
   * Registers one or more subsystems whose supply current will be tracked.
   * Each object must implement {@link EnergyIO} to provide its current reading.
   *
   * @param IOs the subsystem energy interfaces to track
   */
  public void addSubsystems(EnergyIO... IOs) {
    for (var io : IOs) {
      this.objects.add(new EnergyObject(io));
    }
  }

  /**
   * call to update the energy tracking of all subsystems added
   */
  public void periodic() {
    totalCurrent = 0;
    totalPower = 0;
    objects.forEach(object -> {
      var subsystem = object.subsystem;
      String name = subsystem.getClass().getSimpleName();
      String powerPath = "EnergyTracker/" + name + "/Power";
      String energyPath = "EnergyTracker/" + name + "/Energy";
      var current = subsystem.getSupplyCurrent();
      var busVoltage = RobotController.getBatteryVoltage();
      var power = current * busVoltage;
      object.energy += power * loopTime;
      totalCurrent += current;
      totalPower += power;
      totalEnergy += object.energy;
      Logger.recordOutput(powerPath, Watts.of(power));
      Logger.recordOutput(energyPath, Joules.of(object.energy));
    });

    Logger.recordOutput("EnergyTracker/TotalCurrent", Amps.of(totalCurrent));
    Logger.recordOutput("EnergyTracker/TotalPower", Watts.of(totalPower));
    Logger.recordOutput("EnergyTracker/TotalEnergy", Joules.of(totalEnergy));
  }

  /**
   * Interface implemented by subsystems or motor components that wish to contribute to energy
   * tracking.
   */
  public interface EnergyIO {
    /**
     * Returns the current supply current draw of this object in amps.
     *
     * @return supply current in amps
     */
    double getSupplyCurrent();
  }

  /** Pairs a tracked object with the energy it has accumulated so far. */
  protected static class EnergyObject {

    /** Running total of energy drawn by {@link #subsystem}, in joules. */
    protected double energy = 0;

    /** The object whose supply current is being integrated. */
    protected EnergyIO subsystem;

    /**
     * Begins tracking a new object with zero accumulated energy.
     *
     * @param subsystem the object whose supply current will be integrated
     */
    protected EnergyObject(EnergyIO subsystem) {
      this.subsystem = subsystem;
    }
  }
}
