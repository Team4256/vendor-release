package org.cyborgcats.ssm;

import edu.wpi.first.wpilibj.XboxController;

/**
 * An Xbox controller whose buttons are pre-wired to {@link StateTrigger} instances, enabling
 * direct state scheduling from controller input without boilerplate polling code.
 */
public class StateXboxController extends XboxController {
  private final StateTrigger a = new StateTrigger(this::getAButton);
  private final StateTrigger b = new StateTrigger(this::getBButton);
  private final StateTrigger x = new StateTrigger(this::getXButton);
  private final StateTrigger y = new StateTrigger(this::getYButton);
  private final StateTrigger leftBumper = new StateTrigger(this::getLeftBumperButton);
  private final StateTrigger rightBumper = new StateTrigger(this::getRightBumperButton);
  private final StateTrigger start = new StateTrigger(this::getStartButton);
  private final StateTrigger back = new StateTrigger(this::getBackButton);
  private final StateTrigger povUp = new StateTrigger(() -> getPOV() == 0);
  private final StateTrigger povRight = new StateTrigger(() -> getPOV() == 90);
  private final StateTrigger povDown = new StateTrigger(() -> getPOV() == 180);
  private final StateTrigger povLeft = new StateTrigger(() -> getPOV() == 270);
  private final double triggerAxisThreshold = 0.5;
  private final StateTrigger leftTrigger = new StateTrigger(() -> getLeftTriggerAxis() >= triggerAxisThreshold);
  private final StateTrigger rightTrigger = new StateTrigger(() -> getRightTriggerAxis() >= triggerAxisThreshold);

  /**
   * Constructs a StateXboxController bound to the specified HID port.
   *
   * @param port USB/HID port number of the controller (0-indexed)
   */
  public StateXboxController(int port) {
    super(port);
  }

  /**
   * @return the {@link StateTrigger} for the A button.
   */
  public StateTrigger a() {
    return a;
  }

  /** @return the {@link StateTrigger} for the B button. */
  public StateTrigger b() {
    return b;
  }

  /** @return the {@link StateTrigger} for the X button. */
  public StateTrigger x() {
    return x;
  }

  /** @return the {@link StateTrigger} for the Y button. */
  public StateTrigger y() {
    return y;
  }

  /** @return the {@link StateTrigger} for the left bumper button. */
  public StateTrigger leftBumper() {
    return leftBumper;
  }

  /** @return the {@link StateTrigger} for the right bumper button. */
  public StateTrigger rightBumper() {
    return rightBumper;
  }

  /** @return the {@link StateTrigger} for the left trigger (active when axis &ge; 0.5). */
  public StateTrigger leftTrigger() {
    return leftTrigger;
  }

  /** @return the {@link StateTrigger} for the right trigger (active when axis &ge; 0.5). */
  public StateTrigger rightTrigger() {
    return rightTrigger;
  }

  /** @return the {@link StateTrigger} for the Start button. */
  public StateTrigger start() {
    return start;
  }

  /** @return the {@link StateTrigger} for the Back/Select button. */
  public StateTrigger back() {
    return back;
  }

  /** @return the {@link StateTrigger} for POV up (0°). */
  public StateTrigger povUp() {
    return povUp;
  }

  /** @return the {@link StateTrigger} for POV right (90°). */
  public StateTrigger povRight() {
    return povRight;
  }

  /** @return the {@link StateTrigger} for POV down (180°). */
  public StateTrigger povDown() {
    return povDown;
  }

  /** @return the {@link StateTrigger} for POV left (270°). */
  public StateTrigger povLeft() {
    return povLeft;
  }
}