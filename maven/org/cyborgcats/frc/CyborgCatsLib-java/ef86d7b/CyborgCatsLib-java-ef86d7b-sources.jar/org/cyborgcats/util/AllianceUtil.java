package org.cyborgcats.util;

import edu.wpi.first.apriltag.AprilTagFieldLayout;
import edu.wpi.first.apriltag.AprilTagFields;
import edu.wpi.first.math.geometry.Pose2d;
import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.math.geometry.Translation2d;
import edu.wpi.first.units.measure.Distance;

import static edu.wpi.first.units.Units.Meters;

/**
 * Utility class for alliance-aware coordinate transformations.
 * When the active alliance is {@link AllianceType#RED}, coordinates are mirrored about the
 * centre of the field so that game pieces and field elements can be defined once from the
 * blue-alliance perspective.
 */
public class AllianceUtil {
  private static final Tunable<Boolean> isRed = Tunable.ofBoolean("AllianceUtil/IsRed", true);
  /**
   * The current season's AprilTag field layout, used for field dimension lookups.
   */
  public static AprilTagFieldLayout layout = AprilTagFieldLayout.loadField(AprilTagFields.kDefaultField);

  /**
   * Flips an X coordinate to the red-alliance side when {@link #shouldFlip()} is {@code true}.
   *
   * @param x blue-alliance X coordinate in meters
   * @return the coordinate after alliance flipping
   */
  public static double flipX(double x) {
    return shouldFlip() ? layout.getFieldWidth() - x : x;
  }

  /**
   * Flips an X distance to the red-alliance side when {@link #shouldFlip()} is {@code true}.
   *
   * @param x blue-alliance X distance
   * @return the distance after alliance flipping
   */
  public static Distance flipX(Distance x) {
    return shouldFlip() ? Meters.of(layout.getFieldWidth()).minus(x) : x;
  }

  /**
   * Flips a Y coordinate to the red-alliance side when {@link #shouldFlip()} is {@code true}.
   *
   * @param y blue-alliance Y coordinate in meters
   * @return the coordinate after alliance flipping
   */
  public static double flipY(double y) {
    return shouldFlip() ? layout.getFieldLength() - y : y;
  }

  /**
   * Flips a Y distance to the red-alliance side when {@link #shouldFlip()} is {@code true}.
   *
   * @param y blue-alliance Y distance
   * @return the distance after alliance flipping
   */
  public static Distance flipY(Distance y) {
    return shouldFlip() ? Meters.of(layout.getFieldLength()).minus(y) : y;
  }

  /**
   * Applies the current alliance flip to a 2D translation.
   *
   * @param translation blue-alliance translation
   * @return the translation after alliance flipping
   */
  public static Translation2d apply(Translation2d translation) {
    return new Translation2d(flipX(translation.getX()), flipY(translation.getY()));
  }

  /**
   * Applies the current alliance flip to a rotation (180° rotation for red alliance).
   *
   * @param rotation blue-alliance rotation
   * @return the rotation after alliance flipping
   */
  public static Rotation2d apply(Rotation2d rotation) {
    return shouldFlip() ? rotation.rotateBy(Rotation2d.kPi) : rotation;
  }

  /**
   * Applies the current alliance flip to a 2D pose.
   *
   * @param pose blue-alliance pose
   * @return the pose after alliance flipping
   */
  public static Pose2d apply(Pose2d pose) {
    return shouldFlip() ? new Pose2d(apply(pose.getTranslation()), apply(pose.getRotation())) : pose;
  }

  /**
   * Applies the current alliance flip to a {@link Bounds} region.
   *
   * @param bounds blue-alliance bounding region
   * @return the bounds after alliance flipping
   */
  public static Bounds apply(Bounds bounds) {
    if (shouldFlip()) {
      return new Bounds(
          flipX(bounds.maxX()),
          flipX(bounds.minX()),
          flipY(bounds.maxY()),
          flipY(bounds.minY()));
    } else {
      return bounds;
    }
  }

  /**
   * Returns {@code true} when coordinates should be mirrored for the red alliance.
   *
   * @return {@code true} if the active alliance is {@link AllianceType#RED}
   */
  public static boolean shouldFlip() {
    return getAllianceType() == AllianceType.RED;
  }

  /**
   * Returns the currently configured alliance type.
   *
   * @return {@link AllianceType#RED} or {@link AllianceType#BLUE}
   */
  public static AllianceType getAllianceType() {
    if (isRed.getValue()) {
      return AllianceType.RED;
    } else {
      return AllianceType.BLUE;
    }
  }

  /**
   * Enumeration of FRC alliance colors.
   */
  public enum AllianceType {
    /** Red alliance — field coordinates are mirrored. */
    RED,
    /** Blue alliance — field coordinates are used as-is. */
    BLUE,
  }
}
