package org.cyborgcats.ssm;

import edu.wpi.first.wpilibj.Timer;
import org.littletonrobotics.junction.Logger;

/**
 * Utility class that logs the activity, duration, and requirements of a {@link State}.
 */
public class Telemetry {
  private final Timer timer = new Timer();
  private final State state;

  /**
   * Creates a Telemetry logger for the given state.
   *
   * @param state state whose telemetry will be recorded
   */
  public Telemetry(State state) {
    this.state = state;
  }

  /**
   * Starts the timer and records the state as active.
   */
  public void start() {
    timer.stop();
    timer.reset();
    timer.start();
    Logger.recordOutput("States/" + state.getName() + "/active", true);
  }

  /**
   * Updates duration and active requirements in AdvantageKit.
   */
  public void log() {
    Logger.recordOutput("States/" + state.getName() + "/duration", timer.get());
    Logger.recordOutput("States/" + state.getName() + "/requirements",
        state.getRequirements().stream()
            .map(s -> s.getClass().getSimpleName())
            .toArray(String[]::new));
  }

  /**
   * Stops the timer and records the state as inactive.
   */
  public void stop() {
    timer.stop();
    Logger.recordOutput("States/" + state.getName() + "/duration", timer.get());
    Logger.recordOutput("States/" + state.getName() + "/active", false);
  }
}
