package org.cyborgcats.componentViz;

import edu.wpi.first.math.geometry.Pose3d;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.function.Supplier;

import org.cyborgcats.subsystem.Subsystem;
import org.littletonrobotics.junction.Logger;

/**
 * Global registry that collects {@link ComponentViz} instances, sorts them by render order,
 * and publishes their poses to AdvantageKit each loop iteration.
 */
public class ComponentVizRegistry extends Subsystem {

  private static final ArrayList<ComponentViz> componentViz = new ArrayList<>();
  private static final ArrayList<Supplier<Pose3d>> componentPoses =
    new ArrayList<>();

  /**
   * Registers a {@link ComponentViz} instance to be included in the next {@link #build()} call.
   *
   * @param viz the component visualization to register
   */
  public static void register(ComponentViz viz) {
    componentViz.add(viz);
  }

  /**
   * Sorts all registered components by their render order and caches their pose suppliers.
   * Must be called once after all components are registered (e.g., in {@code robotInit}).
   */
  public static void build() {
    componentViz.sort(Comparator.comparingInt(ComponentViz::getOrder));
    componentPoses.clear();
    for (ComponentViz viz : componentViz) {
      componentPoses.add(viz.getPose());
    }
  }

  /**
   * Evaluates all cached pose suppliers and logs the resulting array to AdvantageKit under
   * {@code "ComponentViz/Poses"}. Should be called every robot loop iteration.
   */
  @Override
  public void periodic() {
    Pose3d[] poses = componentPoses
      .stream()
      .map(Supplier::get)
      .toArray(Pose3d[]::new);
    Logger.recordOutput("ComponentViz/Poses", poses);
  }
}
