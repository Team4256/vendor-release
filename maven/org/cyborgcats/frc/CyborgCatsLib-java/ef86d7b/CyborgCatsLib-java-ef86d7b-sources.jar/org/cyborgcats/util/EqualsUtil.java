package org.cyborgcats.util;

/**
 * Utility class providing floating-point comparison helpers.
 */
public class EqualsUtil {
  /**
   * Returns {@code true} if {@code a} and {@code b} differ by no more than {@code threshold}.
   *
   * @param a         first value
   * @param b         second value
   * @param threshold maximum allowable difference (must be non-negative)
   * @return {@code true} if {@code |a - b| <= threshold}
   */
  public static boolean thresholdEquals(double a, double b, double threshold) {
    return (a - threshold <= b) && (a + threshold >= b);
  }
}
