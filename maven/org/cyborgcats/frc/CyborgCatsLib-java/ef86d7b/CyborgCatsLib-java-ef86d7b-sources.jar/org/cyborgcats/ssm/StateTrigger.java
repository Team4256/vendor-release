package org.cyborgcats.ssm;

import edu.wpi.first.wpilibj.DriverStation;
import java.util.function.BooleanSupplier;

/**
 * Binds a boolean condition to one or more {@link State} scheduling actions, evaluated each
 * robot loop via the {@link Scheduler} button-polling loop.
 */
public class StateTrigger {

  private final BooleanSupplier conditional;
  private final Scheduler scheduler = Scheduler.getInstance();
  private boolean lastValue;
  private State onTrueState;
  private State onFalseState;
  private State whileTrueState;
  private State onToggleState;
  private boolean toggleFlag = true;

  /**
   * Constructs a StateTrigger and registers its poll callback with the scheduler's button loop.
   *
   * @param conditional the condition to evaluate each loop iteration
   */
  public StateTrigger(BooleanSupplier conditional) {
    this.conditional = conditional;
    this.lastValue = conditional.getAsBoolean();
    Scheduler.getButtonLoop().add(this::poll);
  }

  /**
   * Schedules the given state on the rising edge of the condition (false → true).
   *
   * @param state the state to schedule when the condition becomes true
   * @return this trigger for chaining
   */
  public StateTrigger onTrue(State state) {
    this.onTrueState = state;
    return this;
  }

  /**
   * Schedules the given state on the falling edge of the condition (true → false).
   *
   * @param state the state to schedule when the condition becomes false
   * @return this trigger for chaining
   */
  public StateTrigger onFalse(State state) {
    this.onFalseState = state;
    return this;
  }

  /**
   * Schedules the given state while the condition is true and ends it when the condition
   * becomes false.
   *
   * @param state the state to schedule on rising edge and end on falling edge
   * @return this trigger for chaining
   */
  public StateTrigger whileTrue(State state) {
    this.whileTrueState = state;
    return this;
  }

  /**
   * Alternately schedules and ends the given state on successive rising edges of the condition
   * (toggle behavior). Resets the toggle flag when the state is interrupted or ends naturally.
   *
   * @param state the state to toggle on each rising edge
   * @return this trigger for chaining
   */
  public StateTrigger onToggle(State state) {
    this.onToggleState = state;
    state.onInterrupt(() -> toggleFlag = true);
    state.onEnd(() -> toggleFlag = true);
    return this;
  }

  /**
   * Whether the given state may be scheduled right now. While the robot is disabled only states
   * exempted via {@link State#withIgnoreDisable(boolean)} may start; anything else would be ended
   * by the scheduler on the same loop.
   */
  private static boolean schedulable(State state) {
    return !DriverStation.isDisabled() || state.getIgnoreDisable();
  }

  private void poll() {
    boolean currentValue = conditional.getAsBoolean();
    boolean risingEdge = currentValue && !lastValue;
    boolean fallingEdge = !currentValue && lastValue;

    // edges are tracked whether or not they are acted on, so a condition held across the
    // disable boundary does not read as a fresh edge on re-enable
    lastValue = currentValue;

    if (risingEdge && onTrueState != null && schedulable(onTrueState)) {
      scheduler.schedule(onTrueState);
    }

    if (fallingEdge && onFalseState != null && schedulable(onFalseState)) {
      scheduler.schedule(onFalseState);
    }

    if (whileTrueState != null) {
      // ending is always allowed; a disabled non-exempt state is already gone, making this a no-op
      if (risingEdge && schedulable(whileTrueState)) scheduler.schedule(whileTrueState);
      else if (fallingEdge) scheduler.end(whileTrueState);
    }

    // the toggle flag flips only when the action is actually applied, otherwise a suppressed
    // press would invert the toggle for every press after it
    if (risingEdge && onToggleState != null && schedulable(onToggleState)) {
      if (toggleFlag) scheduler.schedule(onToggleState);
      else scheduler.end(onToggleState);
      toggleFlag = !toggleFlag;
    }
  }
}
