package org.cyborgcats.io.vision;

import org.littletonrobotics.junction.AutoLog;

import edu.wpi.first.math.Matrix;
import edu.wpi.first.math.geometry.Pose3d;
import edu.wpi.first.math.geometry.Transform3d;
import edu.wpi.first.math.numbers.N1;
import edu.wpi.first.math.numbers.N4;

import java.util.function.Supplier;

/**
 * Interface defining how to communicate with a vision camera to obtain AprilTag detections
 * and pose estimates.
 */
public interface VisionCameraIO {
  /**
   * updates recorded vision camera inputs
   *
   * @param inputs loggable vision camera inputs
   */
  void updateInputs(VisionCameraInputs inputs);

  /**
   * AdvantageKit-loggable container of vision camera telemetry fields.
   */
  @AutoLog
  class VisionCameraInputs {
    /**
     * Fiducial IDs of all detected AprilTags.
     */
    public int[] ids = new int[]{};
    /**
     * Detected corner coordinates for all tags, interleaved as [x0, y0, x1, y1, ...] with
     * 8 values (4 corners × 2 coordinates) per tag.
     */
    public float[] corners = new float[]{};
    /** Whether the current frame produced a valid pose estimate. */
    public boolean isValid = false;
    /** Mean reprojection error of the pose solve (pixels). */
    public double reprojectionError = 0.0;
    /** Pose ambiguity ratio; lower values indicate a more unambiguous solution. */
    public double ambiguity = 0.0;
    /** Total on-screen area of detected tags as a fraction of the image area. */
    public double tagArea = 0.0;
    /** Number of AprilTags used in the pose estimate. */
    public int tagCount = 0;
    /** Whether the camera is reachable on the network. */
    public boolean connected = false;
    /** Camera-space pose estimate for the most recent valid frame. */
    public Pose3d estimate = new Pose3d();
  }

  /**
   * A raw vision measurement before standard deviation weighting is applied.
   *
   * @param visionPose field-relative robot pose estimated by the camera
   * @param timestamp  FPGA timestamp of the frame (seconds)
   * @param tagCount   number of tags used in this estimate
   * @param tagArea    total fractional tag area visible to the camera
   */
  record VisionMeasurement(
      Pose3d visionPose,
      double timestamp,
      int tagCount,
      double tagArea
  ) {
  }

  /**
   * A vision measurement paired with its measurement standard deviations for pose estimation.
   *
   * @param visionPose field-relative robot pose estimated by the camera
   * @param timestamp  FPGA timestamp of the frame (seconds)
   * @param stdDevs    4×1 standard deviation vector used to weight this observation
   */
  record VisionObservation(
      Pose3d visionPose,
      double timestamp,
      Matrix<N4, N1> stdDevs
  ) {
  }

  /**
   * Configuration record for a vision camera instance.
   *
   * @param name          unique camera name (must match the PhotonVision camera name)
   * @param width         image width in pixels
   * @param height        image height in pixels
   * @param cameraMatrix  3×3 intrinsic camera matrix as a flat 9-element row-major array
   * @param distCoeffs    lens distortion coefficients (length 4 or 5)
   * @param robotToCamera supplier returning the transform from robot origin to camera lens
   */
  record VisionCfg(
      String name,
      int width,
      int height,
      double[] cameraMatrix,
      double[] distCoeffs,
      Supplier<Transform3d> robotToCamera
  ) {
  }
}
