package org.cyborgcats.util;

import edu.wpi.first.math.MathUtil;

/**
 * A simple exponential (first-order IIR) low-pass filter.
 * Each call to {@link #calculate(double)} blends the new input toward the previous output
 * by a smoothing factor {@code k}: {@code output = lastOutput + k * (input - lastOutput)}.
 */
public class LowPassFilter {
  private double lastValue = 0;
  private double k = 0;

  /**
   * Constructs a LowPassFilter with an initial output of zero.
   *
   * @param k smoothing factor in the range [0.0, 1.0]; 0 = no change, 1 = no filtering
   */
  public LowPassFilter(double k) {
    setK(k);
  }

  /**
   * Constructs a LowPassFilter with a specified initial output value.
   *
   * @param k         smoothing factor in the range [0.0, 1.0]
   * @param lastValue the initial output seed value
   */
  public LowPassFilter(double k, double lastValue) {
    setK(k);
    this.lastValue = lastValue;
  }

  /**
   * Filters the input value and returns the smoothed output.
   *
   * @param input the new raw input sample
   * @return the filtered output
   */
  public double calculate(double input) {
    double out = lastValue + k * (input - lastValue);
    lastValue = out;
    return out;
  }

  /**
   * Updates the smoothing factor, clamped to [0.0, 1.0].
   *
   * @param k new smoothing factor
   */
  public void setK(double k) {
    this.k = MathUtil.clamp(k, 0.0, 1.0);
  }

  /**
   * Resets the filter state to the given value without producing output.
   *
   * @param lastValue the value to seed the filter with
   */
  public void reset(double lastValue) {
    this.lastValue = lastValue;
  }
}
