package org.cyborgcats.component;

import edu.wpi.first.units.measure.Angle;

import org.littletonrobotics.junction.Logger;
import org.cyborgcats.io.sensor.gyro.GyroInputsAutoLogged;
import org.cyborgcats.io.sensor.gyro.GyroIO;
import org.cyborgcats.io.sensor.gyro.GyroIOConfiguration;

import static edu.wpi.first.units.Units.Radians;

/**
 * Component wrapper for a gyro hardware interface, handling input updates, logging, and heading resets.
 */
public class Gyro implements Component {
  private final GyroIO io;
  private final String name;
  private final GyroInputsAutoLogged inputs = new GyroInputsAutoLogged();

  /**
   * Constructs a Gyro component.
   *
   * @param name unique name used as the AdvantageKit logging key under "Sensors/"
   * @param conf configuration used to build this gyro's hardware interface
   */
  public Gyro(String name, GyroIOConfiguration conf) {
    this.name = name;
    this.io = conf.build();
  }

  /**
   * Reads and logs gyro data via AdvantageKit.
   * Inputs are logged under {@code "Sensors/<name>"}.
   */
  @Override
  public void updateInputs() {
    io.updateInputs(inputs);
    Logger.processInputs("Sensors/" + name, inputs);
  }

  /**
   * Refreshes and returns this gyro's inputs, logging them as a side effect.
   *
   * @return the logged gyro inputs object
   */
  public GyroIO.GyroInputs getInputs() {
    updateInputs();
    return inputs;
  }

  /**
   * Resets the gyro heading to zero.
   */
  public void reset() {
    io.reset(Radians.of(0.0));
  }

  /**
   * Resets the gyro heading to the specified angle.
   *
   * @param heading the desired heading to reset to
   */
  public void reset(Angle heading) {
    io.reset(heading);
  }
}
