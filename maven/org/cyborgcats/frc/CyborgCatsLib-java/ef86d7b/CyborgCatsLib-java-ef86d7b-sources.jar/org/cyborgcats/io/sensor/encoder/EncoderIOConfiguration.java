package org.cyborgcats.io.sensor.encoder;

import java.util.function.DoubleSupplier;
import org.cyborgcats.io.IOConfiguration;

/**
 * Shared shape for configs that build an {@link EncoderIO}; defaults to {@link EncoderIOSim} in
 * simulation.
 */
public interface EncoderIOConfiguration extends IOConfiguration<EncoderIO> {
  /**
   * Returns a copy of this configuration whose simulated implementation is driven by the given
   * rotation source, for encoders geared off another mechanism rather than reading their own
   * motor. Configurations that don't need this (e.g. an encoder simulated independently) may
   * leave the default no-op in place.
   *
   * @param rotations supplies the driving mechanism's rotation count, used only in simulation
   * @return a configuration wired to the given rotation source
   */
  default EncoderIOConfiguration withRotations(DoubleSupplier rotations) {
    return this;
  }
}
