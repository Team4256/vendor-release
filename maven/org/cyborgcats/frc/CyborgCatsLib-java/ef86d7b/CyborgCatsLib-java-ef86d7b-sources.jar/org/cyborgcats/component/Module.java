package org.cyborgcats.component;

import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.math.kinematics.SwerveModulePosition;
import edu.wpi.first.math.kinematics.SwerveModuleState;
import org.littletonrobotics.junction.Logger;

import org.cyborgcats.io.motor.MotorIO;
import org.cyborgcats.io.motor.MotorIOConfiguration;
import org.cyborgcats.io.motor.MotorInputsAutoLogged;

/**
 * Swerve module component encapsulating a drive motor, azimuth (steer) motor, and encoder,
 * with methods to apply desired states and read current state/position.
 */
public class Module implements Component {
  private final MotorIO drive;
  private final MotorIO steer;
  private final Encoder encoder;
  private final String name;

  private final MotorInputsAutoLogged driveInputs = new MotorInputsAutoLogged();
  private final MotorInputsAutoLogged azimuthInputs = new MotorInputsAutoLogged();

  /**
   * Constructs a swerve Module component.
   *
   * @param drive   configuration used to build the drive wheel's motor
   * @param azimuth configuration used to build the azimuth (steering) mechanism's motor
   * @param encoder encoder whose absolute position seeds the azimuth motor's starting position
   * @param name    unique name used as the AdvantageKit logging key under "Modules/"
   */
  public Module(MotorIOConfiguration drive, MotorIOConfiguration azimuth, Encoder encoder, String name) {
    this.drive = drive.build();
    this.steer = azimuth.build();
    this.encoder = encoder;
    this.name = name;

    this.steer.setCurrentPosition(encoder.getInputs().absPosition);
  }

  /**
   * Optimizes and applies the given {@link SwerveModuleState} to the drive and azimuth motors.
   *
   * @param desiredState the target swerve module state to apply
   */
  public void setDesiredState(SwerveModuleState desiredState) {
    desiredState.optimize(new Rotation2d(azimuthInputs.position));
    Setpoint driveSetpoint = Setpoint.withVelocity(desiredState.speedMetersPerSecond);
    Setpoint steerSetpoint = Setpoint.withPosition(desiredState.angle.getRadians());

    driveSetpoint.apply(drive);
    steerSetpoint.apply(steer);
  }

  /**
   * Returns the current swerve module state constructed from drive velocity and azimuth angle.
   *
   * @return the current {@link SwerveModuleState}
   */
  public SwerveModuleState getModuleState() {
    return new SwerveModuleState(driveInputs.velocity, new Rotation2d(azimuthInputs.position));
  }

  /**
   * Returns the current swerve module position constructed from drive position and azimuth angle.
   *
   * @return the current {@link SwerveModulePosition}
   */
  public SwerveModulePosition getModulePosition() {
    return new SwerveModulePosition(driveInputs.position, new Rotation2d(azimuthInputs.position));
  }

  /**
   * Reads and logs drive and azimuth motor inputs via AdvantageKit.
   * Drive inputs are logged under {@code "Modules/<name>/DriveInputs"} and azimuth inputs
   * under {@code "Modules/<name>/AzimuthInputs"}.
   */
  public void updateInputs() {
    drive.updateInputs(driveInputs);
    Logger.processInputs("Modules/" + name + "/DriveInputs", driveInputs);

    steer.updateInputs(azimuthInputs);
    Logger.processInputs("Modules/" + name + "/AzimuthInputs", azimuthInputs);

    encoder.updateInputs();
  }
}
