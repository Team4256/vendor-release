package org.cyborgcats.component;

import static org.cyborgcats.util.EqualsUtil.thresholdEquals;

import edu.wpi.first.math.filter.Debouncer;
import org.cyborgcats.io.motor.MotorIOConfiguration;

/**
 * Extension of {@link MotorComponent} that adds debounced proximity checks for position setpoints.
 */
public class PositionComponent extends MotorComponent {

  private final double threshold;
  private final Debouncer debouncer;

  /**
   * Constructs a PositionComponent.
   *
   * @param name         unique name used as the AdvantageKit logging key under "mechanisms/"
   * @param threshold    angular tolerance used to determine whether the component is at a target position
   * @param debounceTime how long (in seconds) the component must continuously be within threshold before
   *                     the at-position check returns {@code true}
   * @param leader       configuration used to build the hardware interface for this motor
   * @param followers    configurations for hardware interfaces driven with the same control request as
   *                     the leader; may be omitted for a single-motor mechanism
   */
  public PositionComponent(
    String name,
    double threshold,
    double debounceTime,
    MotorIOConfiguration leader,
    MotorIOConfiguration... followers
  ) {
    super(name, leader, followers);
    this.threshold = threshold;
    this.debouncer = new Debouncer(
      debounceTime,
      Debouncer.DebounceType.kRising
    );
  }

  /**
   * Returns {@code true} when the motor has been within threshold of the given position for the
   * configured debounce time.
   *
   * @param position target position to check against
   * @return {@code true} if the debounce window has elapsed and the motor is within threshold
   */
  public boolean nearPosition(double position) {
    return debouncer.calculate(
      thresholdEquals(
        getInputs().position,
        position,
        threshold
      )
    );
  }

  /**
   * Returns {@code true} when the motor has been within the custom threshold of the given position
   * for the configured debounce time.
   *
   * @param position target position to check against
   * @param threshold  custom angular tolerance (in radians) overriding the constructor value
   * @return {@code true} if the debounce window has elapsed and the motor is within threshold
   */
  public boolean nearPosition(double position, double threshold) {
    return debouncer.calculate(
      thresholdEquals(
        getInputs().position,
        position,
        threshold
      )
    );
  }

  /**
   * Returns {@code true} when the motor has been within threshold of the given setpoint's position
   * for the configured debounce time.
   *
   * @param setpoint position setpoint to check against
   * @return {@code true} if the debounce window has elapsed and the motor is within threshold
   */
  public boolean nearSetpoint(Setpoint setpoint) {
    return nearPosition(setpoint.getBaseUnits());
  }

  /**
   * Returns {@code true} when the motor has been within the custom threshold of the given setpoint's
   * position for the configured debounce time.
   *
   * @param setpoint position setpoint to check against
   * @param threshold  custom angular tolerance (in radians) overriding the constructor value
   * @return {@code true} if the debounce window has elapsed and the motor is within threshold
   */
  public boolean nearSetpoint(Setpoint setpoint, double threshold) {
    return nearPosition(setpoint.getBaseUnits(), threshold);
  }

  /**
   * Returns {@code true} when the motor has been within threshold of the most recently applied
   * setpoint for the configured debounce time.
   *
   * @return {@code true} if the debounce window has elapsed and the motor is within threshold
   */
  public boolean atSetpoint() {
    return nearSetpoint(this.setpoint);
  }

  /**
   * Returns {@code true} when the motor has been within the custom threshold of the most recently
   * applied setpoint for the configured debounce time.
   *
   * @param threshold custom angular tolerance (in radians) overriding the constructor value
   * @return {@code true} if the debounce window has elapsed and the motor is within threshold
   */
  public boolean atSetpoint(double threshold) {
    return nearSetpoint(this.setpoint, threshold);
  }
}
