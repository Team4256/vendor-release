package org.cyborgcats.io.sensor.gyro;

import java.util.function.Supplier;
import edu.wpi.first.math.geometry.Rotation3d;
import edu.wpi.first.math.kinematics.ChassisSpeeds;
import edu.wpi.first.units.Units;
import edu.wpi.first.units.measure.Angle;


/**
 * Gyro IO implementation that integrates chassis speeds to simulate heading.
 */
public class GyroIOSim implements GyroIO {
  private static final double DT = 0.02;
  private final Supplier<ChassisSpeeds> speeds;
  private double yawRad = 0.0;

  /**
   * class constructor for a simulated gyro
   *
   * @param speeds robot relative chassis speeds used to update yaw angle
   */
  public GyroIOSim(Supplier<ChassisSpeeds> speeds) {
    this.speeds = speeds;
  }

  @Override
  public void reset(Angle headingRad) {
    yawRad = headingRad.in(Units.Radian);
  }

  @Override
  public void updateInputs(GyroInputs inputs) {
    double omega = speeds.get().omegaRadiansPerSecond;
    yawRad += omega * DT;
    inputs.rotation = new Rotation3d(0.0, 0.0, yawRad);
    inputs.angularVelocityRadPerSec = new Rotation3d(0.0, 0.0, omega);
    inputs.connected = true;
  }
}
