package org.cyborgcats.io.motor;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.StatusSignal;
import com.ctre.phoenix6.StatusSignalCollection;
import com.ctre.phoenix6.configs.TalonFXConfiguration;
import com.ctre.phoenix6.controls.ControlRequest;
import com.ctre.phoenix6.controls.DutyCycleOut;
import com.ctre.phoenix6.controls.MotionMagicVelocityVoltage;
import com.ctre.phoenix6.controls.MotionMagicVoltage;
import com.ctre.phoenix6.controls.NeutralOut;
import com.ctre.phoenix6.controls.PositionVoltage;
import com.ctre.phoenix6.controls.VelocityTorqueCurrentFOC;
import com.ctre.phoenix6.controls.VelocityVoltage;
import com.ctre.phoenix6.controls.VoltageOut;
import com.ctre.phoenix6.hardware.TalonFX;

import edu.wpi.first.units.measure.Angle;
import edu.wpi.first.units.measure.AngularAcceleration;
import edu.wpi.first.units.measure.AngularVelocity;
import edu.wpi.first.units.measure.Current;
import edu.wpi.first.units.measure.Temperature;
import edu.wpi.first.units.measure.Voltage;
import edu.wpi.first.wpilibj.Alert;
import edu.wpi.first.wpilibj.Alert.AlertType;

import org.cyborgcats.component.Setpoint;

/**
 * Hardware abstraction for a single TalonFX motor controller.
 */
public class MotorIOTalonFX implements MotorIO {

  private final TalonFX motor;
  private final String name;

  private final StatusSignal<Voltage> motorVoltage;
  private final StatusSignal<Voltage> suppyVoltage;
  private final StatusSignal<Current> statorCurrent;
  private final StatusSignal<Current> supplyCurrent;
  private final StatusSignal<Angle> position;
  private final StatusSignal<AngularVelocity> velocity;
  private final StatusSignal<AngularAcceleration> acceleration;
  private final StatusSignal<Temperature> temperature;
  private final StatusSignalCollection collection;

  // try changing update frequency of requests
  private final NeutralOut neutralRequest = new NeutralOut();
  private final VoltageOut voltageRequest = new VoltageOut(0);
  private final DutyCycleOut dutyCycleRequest = new DutyCycleOut(0);
  private final PositionVoltage positionRequest = new PositionVoltage(0);
  private final MotionMagicVoltage positionMotionProfileRequest = new MotionMagicVoltage(0);
  private final VelocityVoltage velocityRequest = new VelocityVoltage(0);
  private final VelocityTorqueCurrentFOC torqueRequest = new VelocityTorqueCurrentFOC(0.0);
  private final MotionMagicVelocityVoltage velocityMotionMagic = new MotionMagicVelocityVoltage(0.0);

  private double setpoint = 0;
  private Setpoint.Mode mode = Setpoint.Mode.Neutral;

  /**
   * constructor for a talonFX MotorIO
   * SuppressWarnings("removal") for the talon fx constructor using the "rio" canbus
   * @param canID device ID of the motor controller
   * @param cfg configuration for the motor controller
   * @param name name of the motor controller
   */
  public MotorIOTalonFX(int canID, TalonFXConfiguration cfg, String name) {
    this.motor = new TalonFX(canID, "rio");
    this.name = name;
    StatusCode code = motor.getConfigurator().apply(cfg);
    
    if (code.isError()) {
      @SuppressWarnings("resource")
      Alert alert = new Alert(
        "Config Error: " + name, AlertType.kWarning);

      alert.set(true);
    }

    motorVoltage = motor.getMotorVoltage();
    suppyVoltage = motor.getSupplyVoltage();
    statorCurrent = motor.getStatorCurrent();
    supplyCurrent = motor.getSupplyCurrent();
    position = motor.getPosition();
    velocity = motor.getVelocity();
    acceleration = motor.getAcceleration();
    temperature = motor.getDeviceTemp();

    collection = new StatusSignalCollection(
      motorVoltage,
      suppyVoltage,
      statorCurrent,
      supplyCurrent,
      position,
      velocity,
      acceleration,
      temperature
    );
  }

  @Override
  public void updateInputs(MotorInputs inputs) {
    collection.refreshAll();
    inputs.motorVoltage = motorVoltage.getValueAsDouble();
    inputs.supplyVoltage = suppyVoltage.getValueAsDouble();
    inputs.statorCurrent = statorCurrent.getValueAsDouble();
    inputs.supplyCurrent = supplyCurrent.getValueAsDouble();
    inputs.position = position.getValueAsDouble();
    inputs.velocity = velocity.getValueAsDouble();
    inputs.acceleration = acceleration.getValueAsDouble();
    inputs.temperature = temperature.getValueAsDouble();
    inputs.connected = motor.isConnected();
    inputs.setpoint = setpoint;
    inputs.mode = mode;
  }

  @Override
  public void setCurrentPosition(double position) {
    motor.setPosition(position);
  }

  @Override
  public void applyNetural() {
    setpoint = 0;
    mode = Setpoint.Mode.Neutral;
    setControl(neutralRequest);
  }

  @Override
  public void applyVoltageSetpoint(double voltage) {
    setpoint = voltage;
    mode = Setpoint.Mode.Voltage;
    setControl(voltageRequest.withOutput(voltage));
  }

  @Override
  public void applyDutyCycleSetpoint(double dutyCycle) {
    setpoint = dutyCycle;
    mode = Setpoint.Mode.DutyCycle;
    setControl(dutyCycleRequest.withOutput(dutyCycle));
  }

  @Override
  public void applyVelocitySetpoint(double velocity) {
    setpoint = velocity;
    mode = Setpoint.Mode.Velocity;
    setControl(velocityRequest.withVelocity(velocity));
  }

  @Override
  public void applyPositionSetpoint(double position) {
    setpoint = position;
    mode = Setpoint.Mode.Position;
    setControl(positionRequest.withPosition(position));
  }

  @Override
  public void applyPositionMotionProfile(double position) {
      setpoint = position;
      mode = Setpoint.Mode.PositionMotionProfile;
      setControl(positionMotionProfileRequest.withPosition(position));
  }

  @Override
  public void applyVelocityTorqueCurrent(double velocity) {
      setpoint = velocity;
      mode = Setpoint.Mode.VelocityTorqueCurrent;
      setControl(torqueRequest.withVelocity(velocity));
  }

  @Override
  public void applyVelocityMotionProfile(double velocity) {
      setpoint = velocity;
      mode = Setpoint.Mode.VelocityMotionProfile;
      setControl(velocityMotionMagic.withVelocity(velocity));
  }

  /**
   * helper function to appyl a control request to the motor
   * @param request the control request to apply
   */
  public void setControl(ControlRequest request) {
    motor.setControl(request);
  }

  @Override
  public String getName() {
    return name;
  }
}
