package org.cyborgcats.util;

/**
 * An inclusive minimum/maximum bound.
 *
 * @param min the lower bound
 * @param max the upper bound
 */
public record Range(double min, double max) {
}
