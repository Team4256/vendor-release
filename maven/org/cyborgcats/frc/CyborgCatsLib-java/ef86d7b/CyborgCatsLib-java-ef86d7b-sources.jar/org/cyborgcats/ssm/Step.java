package org.cyborgcats.ssm;

import edu.wpi.first.wpilibj.Timer;

import java.util.concurrent.Semaphore;
import java.util.function.BooleanSupplier;

/**
 * A single executable unit within a {@link State}, running its body on a dedicated daemon thread.
 * The body cooperatively yields control back to the scheduler each robot loop by calling
 * {@link #pause()}, {@link #waitSeconds(double)}, or {@link #await(BooleanSupplier)}.
 *
 * <p>Steps are not subclassable and are created for you by
 * {@link State#withStep(CheckedRunnable)}; the public surface here is the set of static helpers a
 * body calls to suspend itself.
 */
public final class Step {
  /** How long {@link #end()} waits for an interrupted body thread to unwind before giving up. */
  private static final long endJoinTimeoutMillis = 20;
  private static final ThreadLocal<Handoff> currentHandoff = new ThreadLocal<>();
  private final CheckedRunnable body;
  private Thread thread;
  private volatile Handoff handoff;
  private volatile boolean done = false;
  private volatile boolean started = false;

  /**
   * Suspends execution of the current step body for one scheduler loop iteration.
   * Must only be called from within a step body.
   *
   * @throws InterruptedException if the step's thread is interrupted (e.g., because the step
   *                              was ended externally)
   * @throws IllegalStateException if called from a thread that is not running a step body
   */
  public static void pause() throws InterruptedException {
    Handoff current = currentHandoff.get();
    if (current == null) {
      throw new IllegalStateException("pause() may only be called from within a step body");
    }
    current.yieldToScheduler();
  }

  private Step(CheckedRunnable body) {
    this.body = body;
  }

  /**
   * Creates a step whose body is the provided runnable.
   *
   * @param body the code to execute as the step body
   * @return a new {@link Step}
   */
  static Step run(CheckedRunnable body) {
    return new Step(body);
  }

  /**
   * Executes the provided body in an infinite loop, yielding to the scheduler between each
   * iteration. This method never returns normally; the step ends only when interrupted.
   *
   * @param body the code to execute each iteration
   * @throws InterruptedException if the step's thread is interrupted
   */
  public static void loop(CheckedRunnable body) throws InterruptedException {
    while (true) {
      body.run();
      pause();
    }
  }

  /**
   * Suspends the current step body until the specified duration has elapsed.
   *
   * <p>Named {@code waitSeconds} rather than {@code wait} so it cannot be confused with
   * {@link Object#wait(long)}, which would block the calling thread without yielding to the
   * scheduler.
   *
   * @param seconds the minimum time to wait in seconds
   * @throws InterruptedException if the step's thread is interrupted
   */
  public static void waitSeconds(double seconds) throws InterruptedException {
    var timer = new Timer();
    timer.start();
    while (!timer.hasElapsed(seconds)) {
      pause();
    }
  }

  /**
   * Suspends the current step body, yielding each loop until the condition returns {@code true}.
   *
   * @param condition the condition to poll each loop iteration
   * @throws InterruptedException if the step's thread is interrupted
   */
  public static void await(BooleanSupplier condition) throws InterruptedException {
    while (!condition.getAsBoolean()) {
      pause();
    }
  }

  /**
   * Starts the step by launching its body on a new daemon thread and waiting for the first yield.
   */
  void start() {
    done = false;
    started = true;
    Handoff current = new Handoff();
    handoff = current;
    thread = new Thread(() -> {
      currentHandoff.set(current);
      try {
        body.run();
      } catch (InterruptedException e) {
        Thread.currentThread().interrupt();
      } finally {
        // only the live generation may mark this step done; a thread left over from a previous
        // start() must not resurrect the flag after reset() cleared it
        if (handoff == current) done = true;
        current.ready.release();
      }
    });
    thread.setDaemon(true);
    thread.setPriority(Thread.NORM_PRIORITY);
    thread.start();
    current.ready.acquireUninterruptibly();
  }

  /**
   * Resumes the step body after a yield, allowing it to run until the next yield or until
   * the body completes.
   */
  void resume() {
    if (done) return;
    Handoff current = handoff;
    if (current == null) return;
    current.resume.release();
    current.ready.acquireUninterruptibly();
  }

  /**
   * Ends this step by interrupting its thread and marking it as done. Waits briefly for the body
   * to unwind so it is no longer executing when this method returns.
   */
  void end() {
    Thread current = thread;
    if (current != null) {
      current.interrupt();
      try {
        current.join(endJoinTimeoutMillis);
      } catch (InterruptedException e) {
        Thread.currentThread().interrupt();
      }
    }
    done = true;
  }

  /**
   * Returns whether this step's body has completed (or been ended externally).
   *
   * @return {@code true} if the step is finished
   */
  boolean isFinished() {
    return done;
  }

  /**
   * Returns whether this step has been started at least once since the last reset.
   *
   * @return {@code true} if {@link #start()} has been called
   */
  boolean isStarted() {
    return started;
  }

  final void reset() {
    // dropping the handoff retires the current generation outright, so no permit draining is
    // needed and a thread that outlived end() cannot interfere with the next start()
    handoff = null;
    thread = null;
    done = false;
    started = false;
  }

  /**
   * The semaphore pair coordinating one run of a step body with the scheduler. A fresh instance is
   * created per {@link #start()} so that a body thread which outlives its step cannot corrupt the
   * handoff of a subsequent run.
   */
  private static final class Handoff {
    private final Semaphore ready = new Semaphore(0);
    private final Semaphore resume = new Semaphore(0);

    void yieldToScheduler() throws InterruptedException {
      ready.release();
      resume.acquire();
    }
  }

  /**
   * A {@link Runnable}-like functional interface that may throw {@link InterruptedException},
   * used to define step bodies that can be suspended.
   */
  @FunctionalInterface
  public interface CheckedRunnable {
    /**
     * Executes the body; may throw {@link InterruptedException} to allow cooperative cancellation.
     *
     * @throws InterruptedException if execution is interrupted
     */
    void run() throws InterruptedException;
  }
}
