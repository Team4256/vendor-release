package org.cyborgcats.component;

/**
 * Base interface for all robot components that wrap hardware IO objects.
 */
public interface Component {
  /**
   * Reads hardware inputs from the underlying IO layer and processes them for logging.
   */
  void updateInputs();
}
