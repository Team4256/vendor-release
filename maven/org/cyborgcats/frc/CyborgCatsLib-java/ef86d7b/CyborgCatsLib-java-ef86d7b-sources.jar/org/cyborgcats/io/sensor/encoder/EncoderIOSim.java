package org.cyborgcats.io.sensor.encoder;

import java.util.function.DoubleSupplier;

/**
 * {@link EncoderIO} implementation for simulation; reports a stationary, connected encoder.
 */
public class EncoderIOSim implements EncoderIO {
  private final DoubleSupplier rotations;
  private final int toothCount;

  public EncoderIOSim(DoubleSupplier rotations, int toothCount) {
    this.rotations = rotations;
    this.toothCount = toothCount;
  }

  @Override
  public void updateInputs(EncoderInputs inputs) {
    inputs.connected = true;
    inputs.position = rotations.getAsDouble() / toothCount;
    inputs.absPosition = inputs.position - Math.floor(inputs.position);
  }

  @Override
  public int getToothCount() {
      return toothCount;
  }
}
