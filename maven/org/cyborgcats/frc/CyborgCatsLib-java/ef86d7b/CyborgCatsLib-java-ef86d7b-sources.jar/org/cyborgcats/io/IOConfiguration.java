package org.cyborgcats.io;

import edu.wpi.first.wpilibj.RobotBase;

/**
 * Shared shape for hardware configs that can build either a real or a simulated IO
 * implementation, selected by {@link RobotBase#isReal()}.
 */
public interface IOConfiguration<T> {
    /**
     * Builds the real hardware IO implementation for this configuration.
     *
     * @return the real IO implementation
     */
    T buildReal();

    /**
     * Builds the simulated IO implementation for this configuration.
     *
     * @return the simulated IO implementation
     */
    T buildSim();

    /**
     * Builds either the real or simulated IO implementation, depending on {@link RobotBase#isReal()}.
     *
     * @return the appropriate IO implementation for the current runtime
     */
    default T build() {
        return RobotBase.isReal() ? buildReal() : buildSim();
    }
}
