package org.cyborgcats.util;

import org.littletonrobotics.junction.Logger;

import edu.wpi.first.math.MathUtil;
import edu.wpi.first.math.geometry.Pose2d;
import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.math.geometry.Translation2d;
import static edu.wpi.first.units.Units.Meter;
import edu.wpi.first.units.measure.Distance;

/**
 * An axis-aligned 2D bounding rectangle defined by minimum and maximum X and Y distances.
 *
 * @param minX left boundary
 * @param maxX right boundary
 * @param minY bottom boundary
 * @param maxY top boundary
 */
public record Bounds(Distance minX, Distance maxX, Distance minY, Distance maxY) {
  /**
   * Returns {@code true} if the given translation falls within this bounding region (inclusive).
   *
   * @param translation the 2D point to test
   * @return {@code true} if the point is inside the bounds
   */
  public boolean contains(Translation2d translation) {
    return translation.getX() >= minX().in(Meter)
        && translation.getX() <= maxX().in(Meter)
        && translation.getY() >= minY().in(Meter)
        && translation.getY() <= maxY().in(Meter);
  }

  /**
   * Returns {@code true} if the translation component of the given pose falls within this
   * bounding region (inclusive).
   *
   * @param pose the pose whose translation is tested
   * @return {@code true} if the pose's translation is inside the bounds
   */
  public boolean contains(Pose2d pose) {
    return pose.getTranslation().getX() >= minX().in(Meter)
        && pose.getTranslation().getX() <= maxX().in(Meter)
        && pose.getTranslation().getY() >= minY().in(Meter)
        && pose.getTranslation().getY() <= maxY().in(Meter);
  }

  /**
   * Clamps the given translation to the nearest point inside this bounding region.
   *
   * @param translation the point to clamp
   * @return a new translation clamped to the bounds
   */
  public Translation2d clamp(Translation2d translation) {
    return new Translation2d(
        MathUtil.clamp(translation.getX(), minX().in(Meter), maxX().in(Meter)),
        MathUtil.clamp(translation.getY(), minY().in(Meter), maxY().in(Meter)));
  }

  /**
   * Returns the four corners of this bounding region as a closed polygon (first point repeated
   * at the end for rendering purposes).
   *
   * @return array of five {@link Translation2d} points forming the rectangle outline
   */
  public Translation2d[] sides() {
    return new Translation2d[]{
        new Translation2d(minX(), minY()),
        new Translation2d(minX(), maxY()),
        new Translation2d(maxX(), maxY()),
        new Translation2d(maxX(), minY()),
        new Translation2d(minX(), minY())
    };
  }

  /**
   * Logs the bounding region outline as an array of {@link edu.wpi.first.math.geometry.Pose2d}
   * values to AdvantageKit under the given key.
   *
   * @param key the AdvantageKit logging key
   */
  public void log(String key) {
    Translation2d[] corners = sides();
    Pose2d[] poses = new Pose2d[corners.length];
    for (int i = 0; i < corners.length; i++) {
      poses[i] = new Pose2d(corners[i], new Rotation2d());
    }
    Logger.recordOutput(key, poses);
  }
}
