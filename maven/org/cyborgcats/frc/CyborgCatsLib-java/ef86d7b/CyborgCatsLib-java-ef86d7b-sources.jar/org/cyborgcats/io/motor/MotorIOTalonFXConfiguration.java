package org.cyborgcats.io.motor;

import com.ctre.phoenix6.configs.TalonFXConfiguration;
import com.ctre.phoenix6.signals.InvertedValue;

/**
 * Configuration for a TalonFX-backed {@link MotorIO}.
 */
public class MotorIOTalonFXConfiguration implements MotorIOConfiguration {
    private final String name;
    private final int canID;
    private final TalonFXConfiguration conf;
    private final double settlingTime;

    /**
     * Constructs a MotorIOTalonFXConfiguration.
     *
     * @param name             name of the motor controller
     * @param canID            device ID of the TalonFX
     * @param conf             configuration applied to the TalonFX
     * @param simSettlingTime  time constant used by the simulated motor to settle at a commanded
     *                         setpoint
     */
    public MotorIOTalonFXConfiguration(String name, int canID, TalonFXConfiguration conf, double simSettlingTime) {
        this.name = name;
        this.canID = canID;
        this.conf = conf;
        this.settlingTime = simSettlingTime;
    }

    /**
     * Returns a copy of this configuration with {@code MotorOutput.Inverted} flipped, leaving
     * everything else (including the leader's config it was built from) untouched. Useful for a
     * follower motor mounted opposite the leader, e.g. {@code new MotorIOTalonFXConfiguration(
     * "Front", canID, LauncherConstants.flywheelConf, 0.1).inverted()}.
     *
     * @return a new configuration identical to this one with inversion flipped
     */
    public MotorIOTalonFXConfiguration inverted() {
        TalonFXConfiguration flipped = conf.clone();
        flipped.MotorOutput.Inverted = flipped.MotorOutput.Inverted == InvertedValue.Clockwise_Positive
            ? InvertedValue.CounterClockwise_Positive
            : InvertedValue.Clockwise_Positive;
        return new MotorIOTalonFXConfiguration(name, canID, flipped, settlingTime);
    }

    @Override
    public MotorIO buildReal() {
        return new MotorIOTalonFX(canID, conf, name);
    }

    @Override
    public MotorIO buildSim() {
        return new MotorIOSim(settlingTime, name);
    }
}
