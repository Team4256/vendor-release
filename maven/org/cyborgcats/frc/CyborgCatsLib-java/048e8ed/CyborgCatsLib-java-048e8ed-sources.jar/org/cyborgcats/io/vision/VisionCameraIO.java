package org.cyborgcats.io.vision;

import org.cyborgcats.vision.AprilTagEstimate;
import org.cyborgcats.vision.VisionResult;
import org.littletonrobotics.junction.AutoLog;

import edu.wpi.first.math.geometry.Pose3d;

/**
 * Interface defining how to communicate with a vision camera to obtain AprilTag detections
 * and pose estimates.
 */
public interface VisionCameraIO {
  /**
   * updates recorded vision camera inputs
   *
   * @param inputs loggable vision camera inputs
   */
  public void updateInputs(VisionCameraInputs inputs);

  /**
   * @return all vision pose estimates accumulated since the last call, in capture order
   */
  public AprilTagEstimate[] getAllUnreadVisionEstimates();

  /**
   * @return all vision pose measurements accumulated since the last call, in capture order
   */
  public VisionResult[] getVisionResults();

  /**
   * AdvantageKit-loggable container of vision camera telemetry fields.
   */
  @AutoLog
  public class VisionCameraInputs {
    /**
     * Fiducial IDs of all detected AprilTags.
     */
    public int[] ids = new int[]{};
    /**
     * Detected corner coordinates for all tags, interleaved as [x0, y0, x1, y1, ...] with
     * 8 values (4 corners × 2 coordinates) per tag.
     */
    public float[] corners = new float[]{};

    /** Capture timestamp of the frame, in seconds (FPGA/local time base). */
    public double timestamp = 0;
    /** Mean reprojection error of the pose solve (pixels). */
    public double reprojectionError = 0.0;
    /** Pose ambiguity ratio; lower values indicate a more unambiguous solution. */
    public double ambiguity = 0.0;
    /** Total on-screen area of detected tags as a fraction of the image area. */
    public double tagArea = 0.0;
    /** Number of AprilTags used in the pose estimate. */
    public int tagCount = 0;
    /** Whether the camera is reachable on the network. */
    public boolean connected = false;
    /** Camera-space pose estimate for the most recent valid frame. */
    public Pose3d estimate = new Pose3d();

    /** Field poses of the tags that contributed to the most recent valid estimate. */
    public Pose3d[] tagTargets = new Pose3d[0];
  }
}
